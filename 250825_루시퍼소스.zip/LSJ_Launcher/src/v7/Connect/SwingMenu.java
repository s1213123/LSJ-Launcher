package v7.Connect;

import java.awt.Component;
import java.awt.Desktop;
import java.awt.Font;
import java.net.URI;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

import v7.Config.Designs;
import v7.Config.LSJ_Paths;
import v7.Config.Registry;
import v7.Dimensions.LSJ_Frame.LSJ_Frame;
import v7.Dimensions.Network_Frame.Client;
import v7.Dimensions.Network_Frame.Server;

public class SwingMenu extends JPanel {

    private JPopupMenu popupMenu; // 우클릭 팝업 메뉴
    private List<LSJ_Paths.M> menu_parser = LSJ_Paths.M.Menu_Parser(); // 메뉴 항목 리스트
    //private final Map<String, Runnable> commandMap = new HashMap<>();
    private LSJ_Paths.M selectedItem; // 현재 선택된 항목


    
    
    
    
    // ✅ 메뉴를 생성하고 화면에 표시
    public void function(Component parent, int x, int y) {
        popupMenu = new JPopupMenu();
        popupMenu.removeAll();

        // 🔥 메뉴 항목을 실시간 반영
        menu_parser = LSJ_Paths.M.Menu_Parser(); 

        // ✅ 고정 메뉴 항목
        popupMenu.add(createMenuItem("LSJ 런처", () -> new LSJ_Frame("LSJ_Launcher").setVisible(true)));
       // popupMenu.add(createMenuItem("루시퍼 설정", () -> new LSJ_Frame("Control_L").setVisible(true)));
       // popupMenu.add(createMenuItem("루시퍼 숨기기", () -> Designs.controlFrame("hide")));

        popupMenu.addSeparator();

        for (LSJ_Paths.M item : menu_parser) {
            if (item.name.startsWith("#")) continue;
            popupMenu.add(createMenuItem(item.name, () -> OpenByText(item)));
        }

        popupMenu.show(parent, x, y);
    }

    private JMenuItem createMenuItem(String title, Runnable action) {
        JMenuItem m = new JMenuItem(title);
        m.setFont(new Font("맑은 고딕", Font.BOLD, 20));
        m.addActionListener(e -> action.run());
        return m;
    }
    

    // ✅ 명령 실행 진입점
    private void OpenByText(LSJ_Paths.M item) {
        this.selectedItem = item;
        System.out.println("▶ [" + getClass().getSimpleName() + "] " + item.name + " | " + item.type + " | " + item.action);

        JFrame frame = null;

        switch (item.type) {
            case "LSJ_Frame":
                frame = new LSJ_Frame(item.action);
                break;

            case "Lucid_Frame":
                if ("Canlian".equals(item.action)) {
                    JFrame canlianFrame = new JFrame("Canlian");
                   // canlianFrame.setContentPane(new Canlian(canlianFrame));
                    canlianFrame.pack();
                    canlianFrame.setVisible(true);
                    return;
                }
                frame = new LSJ_Frame(item.action);
                break;
            
   /*         case "Network_Frame": {
                this.selectedItem = item;
                if ("Server".equalsIgnoreCase(item.action)) {
                	  JFrame f1 = new JFrame("Server");

                	
                	   f1.setContentPane(new Server());
                	   
				        f1.setSize(Registry.chatting_width, Registry.chatting_height);
				        f1.setVisible(true);     
				        
                    return;
                }

                if ("Client".equalsIgnoreCase(item.action)) {

                	JFrame f2 = new JFrame("Client");
               
                	   f2.setContentPane(new Client());
					
			        f2.setSize(Registry.chatting_width, Registry.chatting_height);
			        f2.setVisible(true);     
                    return;
                }
         
                
               break;
            }
              
*/
                
                //// 중복 실행 막는 함수... 
                
                
            case "Network_Frame": {
                this.selectedItem = item;

                if ("Server".equalsIgnoreCase(item.action)) {
                    JFrame f1 = new JFrame("Server");
                    Server panel = new Server();

                    f1.setContentPane(panel);
                    f1.setSize(Registry.chatting_width, Registry.chatting_height);

                    // ★ EDT를 막지 않기 위해 닫기 동작은 직접 처리
                    f1.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
                    f1.addWindowListener(new java.awt.event.WindowAdapter() {
                        @Override public void windowClosing(java.awt.event.WindowEvent e) {
                            // 백그라운드에서 정리 → 정리 끝나면 dispose
                            new Thread(() -> {
                                try { panel.shutdown(); /* 내부에서 stopServer() */ } catch (Exception ignore) {}
                                SwingUtilities.invokeLater(f1::dispose);
                            }, "ServerShutdown").start();
                        }
                    });

                    f1.setLocationRelativeTo(null);
                    f1.setVisible(true);
                    return;
                }

                if ("Client".equalsIgnoreCase(item.action)) {
                 /*   JFrame f2 = new JFrame("Client");
                    Client panel = new Client();

                    f2.setContentPane(panel);
                    f2.setSize(Registry.chatting_width, Registry.chatting_height);

                    f2.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
                    f2.addWindowListener(new java.awt.event.WindowAdapter() {
                        @Override public void windowClosing(java.awt.event.WindowEvent e) {
                            new Thread(() -> {
                                try { panel.shutdown();  내부에서 closeQuietly()  } catch (Exception ignore) {}
                                SwingUtilities.invokeLater(f2::dispose);
                            }, "ClientShutdown").start();
                        }
                    });

                    f2.setLocationRelativeTo(null);
                    f2.setVisible(true);*/
                	JFrame f2 = new JFrame("Client");
                	Client panel = new Client();

                	f2.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE); // ★중요
                	
                	
                	f2.setContentPane(panel);
                	f2.setSize(Registry.chatting_width, Registry.chatting_height);
                	f2.setLocationRelativeTo(null);
                	f2.setVisible(true);



                    return;
                }


                break;
            }
                
            case "Earth_Frame":
                if (item.action.startsWith("url:")) {
                    openURL(item.action.substring(4).trim());
                    return;
                }
                if (item.action.startsWith("open:")) {
                    runCommand("cmd /c start \"\" \"" + item.action.substring(5).trim() + "\"");
                    return;
                }
                if (item.action.startsWith("Lucifer_")) {
                    String cmd = item.action.substring("Lucifer_".length()).toLowerCase();
                    Designs.controlFrame(cmd);
                    return;
                }
                break;
        }

        if (frame != null) frame.setVisible(true);
    }


    private void openURL(String rawUrl) {
        try {
            URI uri = new URI(rawUrl);
            Desktop.getDesktop().browse(uri);
        } catch (Exception e) {
            Designs.showMessage(null, "URL 열기 실패", rawUrl);
        }
    }

    private void runCommand(String cmd) {
        try {
            Runtime.getRuntime().exec(cmd);
        } catch (Exception e) {
            Designs.showMessage(null, "CMD 실행 실패", cmd);
        }
    }
}
