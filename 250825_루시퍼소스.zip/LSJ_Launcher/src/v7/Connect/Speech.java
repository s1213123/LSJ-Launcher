package v7.Connect;

import java.awt.Color;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

import v7.Config.Registry;

/** 최소설정 Speech: HEX 문자열 JSON만 읽는 초간단판 */
public final class Speech {

    private static final Gson gson = new Gson();

    // === 실사용 팔레트/대사 (기본값) ===
    public static volatile Color[] availableColors = new Color[]{
        new Color(120,255,180),  // 민트그린
        Color.PINK 
    };

    
  /*  public static volatile String[] greetings = {
        "안녕! 좋은 하루 보내자 :)", "반가워!", "또 만났네!"
    };
    public static volatile String[] foods = {
        "밥 먹었어?", "오늘은 뭐가 땡겨?", "간단하게라도 먹자!"
    };
    public static volatile String[] times = {
        "지금은 쉬어갈 시간.", "한 모금 물 마시자.", "스트레칭~"
    };
    public static volatile String[] focus = {
        "25분 집중, 5분 휴식!", "PR 하나 마무리하자.", "작은 커밋이라도 좋아."
    };
    public static volatile String[] relax = {
        "어깨 한번 돌리고 가자.", "눈 잠깐 감고 심호흡.", "물 마시기 체크!"
    };
*/
   
    public static volatile String[] samples1 = {
    	    "좋은 아침이에요! 오늘 하루도 화이팅 ☀️",
    	    "가볍게 시작해볼까요?",
    	    "오늘은 분명 좋은 일이 있을 거예요 :)",
    	    "커피 한 잔과 함께 상쾌하게 출발해요!",
    	    "웃으면서 하루를 열어봐요!"
    	};

  
    public static volatile String[] samples2 = {
    	    "일은 잘 풀리고 있나요?",
    	    "잠깐 눈을 쉬게 해주는 것도 좋아요 👀",
    	    "점심은 든든하게 챙기셨죠?",
    	    "오늘 해야 할 건 차근차근 하면 돼요.",
    	    "리듬을 타고 가면 훨씬 쉬워질 거예요."
    	};

   
    public static volatile String[] samples3 = {
    	    "살짝 늘어질 땐 스트레칭이 최고예요!",
    	    "조금만 더 가면 끝이 보여요 💪",
    	    "한 템포 천천히, 그래도 꾸준히!",
    	    "지금도 충분히 잘하고 있으니 걱정 말아요.",
    	    "집중의 흐름, 끊기지 않게 이어가봐요."
    	};

  
    public static volatile String[] samples4 = {
    	    "오늘 하루도 수고 많았어요!",
    	    "저녁은 맛있게 드셨나요? 🍽️",
    	    "천천히 하루를 정리해도 괜찮아요.",
    	    "작은 일이라도 잘 해낸 거예요 👏",
    	    "남은 저녁은 편안하게 즐겨요."
    	};

 
    public static volatile String[] samples5 = {
    	    "오늘도 수고 많았어요. 이제 푹 쉬어요 🌙",
    	    "늦은 밤, 고요함도 좋은 친구예요.",
    	    "내일을 위해 에너지 충전하세요 ⚡",
    	    "야식은 가볍게, 잠은 푹!",
    	    "좋은 꿈 꾸고 다시 만나요 :)"
    	};


    
    static {
        // 처음에 한 번만 읽기 (없어도 기본값으로 동작)
        reloadFromJson(Registry.JSON_PATH);
    }

    /** 외부에서 수동 리로드 */
    public static void reloadFromJson(String path) {
        try {
            if (!java.nio.file.Files.exists(java.nio.file.Paths.get(path))) return;
            String json = new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
            SpeechJson sj = gson.fromJson(json, SpeechJson.class);
            if (sj == null) return;

            // 색상: HEX 문자열 배열만 지원 (#RGB / #RRGGBB 모두 허용)
            if (sj.colors != null && !sj.colors.isEmpty()) {
                java.util.List<Color> list = new java.util.ArrayList<Color>();
                for (String s : sj.colors) {
                    Color c = parseHex(s);
                    if (c != null) list.add(c);
                }
                if (!list.isEmpty()) availableColors = list.toArray(new Color[0]);
            }

    /*        if (nonEmpty(sj.greetings)) greetings = sj.greetings.toArray(new String[0]);
            if (nonEmpty(sj.foods))     foods     = sj.foods.toArray(new String[0]);
            if (nonEmpty(sj.times))     times     = sj.times.toArray(new String[0]);
            if (nonEmpty(sj.focus))     focus     = sj.focus.toArray(new String[0]);
            if (nonEmpty(sj.relax))     relax     = sj.relax.toArray(new String[0]);
            */
            if (nonEmpty(sj.samples1))     samples1     = sj.samples1.toArray(new String[0]);
            if (nonEmpty(sj.samples2))     samples2     = sj.samples2.toArray(new String[0]);
            if (nonEmpty(sj.samples3))     samples3     = sj.samples3.toArray(new String[0]);
            if (nonEmpty(sj.samples4))     samples4     = sj.samples4.toArray(new String[0]);
            if (nonEmpty(sj.samples5))     samples5     = sj.samples5.toArray(new String[0]);
            
        } catch (IOException ignore) { /* 기본값 유지 */ }
    }

    // === 5구간 스마트 시간 로직 ===
    public static String smartLine() {
        return smartLine(LocalTime.now().getHour());
    }
    public static String smartLine(int hour) {
        if (hour >= 6  && hour <= 11) return pick(samples1); // 아침
        if (hour >= 12 && hour <= 14) return pick(samples2);     // 점심/이른 오후
        if (hour >= 15 && hour <= 18) return pick(samples3);     // 작업 타임
        if (hour >= 19 && hour <= 22) return pick(samples4);     // 정리/휴식
        return pick(samples5);                                   // 야간/새벽
    }

 // ===== 그룹 전체 배열 반환 =====
    public static String[] getGroupLines(String group) {
        if (group == null) return new String[0];
        switch (group.toLowerCase()) {

/*
            case "greetings": return greetings;
      
            case "foods":     return foods;
     
            case "times":     return times;
            case "focus":     return focus;
            case "relax":     return relax;*/
            
            case "samples1":     return samples1;
            case "samples2":     return samples2;
            case "samples3":     return samples3;
            case "samples4":     return samples4;
            case "samples5":     return samples5;
            
            default:          return new String[0];
        }
    }

    
    
    // === 내부 유틸 ===
    private static boolean nonEmpty(List<String> l){ return l!=null && !l.isEmpty(); }

    private static String pick(String[] arr){
        if (arr==null || arr.length==0) return "";
        int i = java.util.concurrent.ThreadLocalRandom.current().nextInt(arr.length);
        return arr[i];
    }

    /** #RGB 또는 #RRGGBB 모두 허용 */
    private static Color parseHex(String s) {
        if (s == null) return null;
        String hex = s.trim();
        if (hex.startsWith("#")) hex = hex.substring(1);
        if (hex.length() == 3) {
            char r=hex.charAt(0), g=hex.charAt(1), b=hex.charAt(2);
            hex = ""+r+r+g+g+b+b;
        }
        if (hex.length()!=6) return null;
        try{
            int r=Integer.parseInt(hex.substring(0,2),16);
            int g=Integer.parseInt(hex.substring(2,4),16);
            int b=Integer.parseInt(hex.substring(4,6),16);
            return new Color(r,g,b);
        }catch(Exception e){ return null; }
    }

    private Speech(){}
    /** JSON DTO — 정말 단순하게 */
    private static final class SpeechJson {
    	  @SerializedName("colors")   List<String> colors;
    	    @SerializedName("samples1") List<String> samples1;
    	    @SerializedName("samples2") List<String> samples2;
    	    @SerializedName("samples3") List<String> samples3;
    	    @SerializedName("samples4") List<String> samples4;
    	    @SerializedName("samples5") List<String> samples5;
    }
}
