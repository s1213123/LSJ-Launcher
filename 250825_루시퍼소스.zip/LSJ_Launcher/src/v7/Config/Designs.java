package v7.Config;

import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Insets;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import v7.LSJ_Starter;
import v7.Avatars.Lucifer_Function;

public class Designs {


    public static final Font PLUGIN_FONT = new Font("맑은고딕", Font.BOLD, 18);   // 플러그인폰트
    public static final Font BIG_FONT = new Font("맑은고딕", Font.BOLD, 16);   // 빅폰트
    public static final Font MIDDLE_FONT  = new Font("맑은고딕", Font.BOLD, 14);   // 중간폰트
    public static final Font SMALL_FONT   = new Font("맑은고딕", Font.BOLD, 12);  // 스몰폰트


    
 // 투명 프레임 함수
       public static void Transparent_Frame(JFrame frame) {
           try {
               frame.setVisible(false);
               frame.dispose();
               frame.setAlwaysOnTop(Registry.AlwaysOnTop);
               frame.setUndecorated(Registry.SetUndecorated);
               frame.setBackground(new Color(0, 0, 0, 0)); // 완전 투명
               frame.setType(JFrame.Type.UTILITY);
               frame.setVisible(true);

           } catch (Exception e) {
               System.out.println("투명 프레임 적용 실패" + e.getMessage());
           }
       }
       
        
       // 프레임 제어 함수
       public static void controlFrame(String command) {
    	    JPanel avatar = null;

    	    if (Registry.globalPortal != null) {
    	        avatar = Registry.globalPortal;
    	    } else if (Registry.globalLucifer != null) {
    	        avatar = Registry.globalLucifer;
    	    } else if (Registry.globalCanlian != null) {
    	        avatar = Registry.globalCanlian;
    	    } else if (Registry.globalLSJ != null) {
    	        avatar = Registry.globalLSJ;
    	    }

    	    else if (avatar == null) return;

    	    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(avatar);
    	    if (frame == null) return;

    	    switch (command) {
    	        case "hide":
    	            frame.setVisible(false);
    	            break;
    	        case "show":
    	            frame.setVisible(true);
    	            frame.toFront();
    	            break;
    	        case "close":
    	            System.exit(0);
    	            break;
    	    }
    	}


       
       
       
    // 트레이 등록 함수
       
       private static TrayIcon currentTrayIcon = null; // Designs 내부에 static으로 유지

       public static void registerTray(JFrame frame) {
           if (!SystemTray.isSupported()) {
        	   System.out.println("이 시스템은 SystemTray를 지원하지 않습니다.");
               return;
           }

           // 기존 트레이 아이콘 제거
           if (currentTrayIcon != null) {
               SystemTray.getSystemTray().remove(currentTrayIcon);
               currentTrayIcon = null;
           }

           Image image = LSJ_Paths.loadImage("/" + Registry.IMAGE_ICON_PORTAL);

           PopupMenu menu = new PopupMenu();

           MenuItem showItem = new MenuItem("Restore Frame");
           showItem.addActionListener(e -> {
               frame.setVisible(true);
               frame.setState(JFrame.NORMAL);
           });

           MenuItem hideItem = new MenuItem("Minimize Frame");
           hideItem.addActionListener(e -> frame.setVisible(false));

           MenuItem portalForm = new MenuItem("Portal Form");
           portalForm.addActionListener(e -> {
               frame.dispose();
               new LSJ_Starter("portal").setVisible(true);
           });

           MenuItem luciferForm = new MenuItem("Lucifer Form");
           luciferForm.addActionListener(e -> {
               frame.dispose();
               new LSJ_Starter("lucifer").setVisible(true);
           });

           MenuItem customForm = new MenuItem("Custom Form");
           customForm.addActionListener(e -> {
               if (Registry.globalLucifer != null) {
                   Lucifer_Function.ChangeImage(Registry.globalLucifer, null);
                   Designs.showMessage(null, "루시퍼 변신", "30초만 변신 가능합니다. 그 이상은 유료버전을 받아주세요... www.dgmayor.com");
               } else {
                   Designs.showMessage(null, "에러 발생", "에러발생.");
               }
           });


           MenuItem exitItem = new MenuItem("Exit");
           exitItem.addActionListener(e -> System.exit(0));

           menu.add(showItem);
           menu.add(hideItem);
           menu.addSeparator();
           menu.add(portalForm);
           menu.add(luciferForm);
           menu.add(customForm);
           menu.addSeparator();
           menu.add(exitItem);

           TrayIcon trayIcon = new TrayIcon(image, "루시퍼 트레이", menu);
           trayIcon.setImageAutoSize(true);


           try {
               SystemTray.getSystemTray().add(trayIcon);
               currentTrayIcon = trayIcon; // �쐟 �깉濡� �벑濡앸맂 �듃�젅�씠 湲곗뼲
               System.out.println("트레이 등록 성공");
           } catch (AWTException e) {
               e.printStackTrace();
           }
       }

       
       
       
      
    

    // 메시지 다이얼로그
    public static void showMessage(Component parent, String title, String message) {
        Frame owner = parent != null ? (Frame) SwingUtilities.getWindowAncestor(parent) : null;
        JDialog dialog = new JDialog(owner, title, true);
        dialog.setUndecorated(true);
        dialog.setLayout(new BorderLayout());
        dialog.setBackground(new Color(255, 250, 240));

        ImageIcon icon = LSJ_Paths.loadIcon("/" + Registry.IMAGE_ICON_PORTAL);
        Image rawImage = icon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        JLabel iconLabel = new JLabel(new ImageIcon(rawImage));
        iconLabel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 10));
        iconLabel.setFont(MIDDLE_FONT);

        JLabel messageLabel = new JLabel(message, SwingConstants.LEFT);
        messageLabel.setFont(MIDDLE_FONT);
        messageLabel.setForeground(Color.BLACK);

        JPanel messagePanel = new JPanel(new BorderLayout());
        messagePanel.setBackground(new Color(255, 250, 240));
        messagePanel.add(iconLabel, BorderLayout.WEST);
        messagePanel.add(messageLabel, BorderLayout.CENTER);
        messagePanel.setBorder(BorderFactory.createEmptyBorder(20, 10, 10, 20));

        JButton okBtn = new JButton("확인");
        okBtn.setFont(MIDDLE_FONT);
        okBtn.setFocusPainted(false);
        okBtn.setPreferredSize(new Dimension(80, 30));
        okBtn.addActionListener(e -> dialog.dispose());

        dialog.getRootPane().setDefaultButton(okBtn);
        dialog.getRootPane().registerKeyboardAction(e -> {
            dialog.dispose();
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(new Color(255, 250, 240));
        btnPanel.add(okBtn);

        dialog.add(messagePanel, BorderLayout.CENTER);
        dialog.add(btnPanel, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(parent);
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);
    }

    
    // 인풋다이알로그
    public static String showInputDialog(Component parent, String title, String guideText) {
        Frame owner = parent != null ? (Frame) SwingUtilities.getWindowAncestor(parent) : null;
        JDialog dialog = new JDialog(owner, title, true);
        dialog.setUndecorated(true);
        dialog.setLayout(new BorderLayout());
        dialog.setBackground(new Color(255, 250, 240));

        JLabel label = new JLabel(guideText);
        label.setFont(MIDDLE_FONT);
        label.setForeground(Color.BLACK);
        label.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        JTextField inputField = new JTextField();
        inputField.setFont(MIDDLE_FONT);
        inputField.setPreferredSize(new Dimension(250, 35));

        JPanel centerPanel = new JPanel(new BorderLayout(5, 5));
        centerPanel.setBackground(new Color(255, 250, 240));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        centerPanel.add(label, BorderLayout.NORTH);
        centerPanel.add(inputField, BorderLayout.CENTER);

        JButton okBtn = new JButton("확인");
        JButton cancelBtn = new JButton("취소");

        okBtn.setFont(MIDDLE_FONT);
        cancelBtn.setFont(MIDDLE_FONT);
        okBtn.setPreferredSize(new Dimension(80, 30));
        cancelBtn.setPreferredSize(new Dimension(80, 30));
        okBtn.setFocusPainted(false);
        cancelBtn.setFocusPainted(false);

        final String[] result = new String[1];

        okBtn.addActionListener(e -> {
            result[0] = inputField.getText();
            dialog.dispose();
        });

        cancelBtn.addActionListener(e -> {
            result[0] = null;
            dialog.dispose();
        });

        // 엔터 = 확인 / ESC = 취소 단축키
        dialog.getRootPane().setDefaultButton(okBtn); // Enter 키 연결
        dialog.getRootPane().registerKeyboardAction(e -> {
            result[0] = null;
            dialog.dispose();
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
           JComponent.WHEN_IN_FOCUSED_WINDOW);

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(new Color(255, 250, 240));
        btnPanel.add(okBtn);
        btnPanel.add(cancelBtn);

        dialog.add(centerPanel, BorderLayout.CENTER);
        dialog.add(btnPanel, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(parent);
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);

        return result[0];
    }


 // 비밀번호 입력 다이얼로그
    public static String promptPassword(Component parent, String title, String guideText) {
        Frame owner = parent != null ? (Frame) SwingUtilities.getWindowAncestor(parent) : null;
        JDialog dialog = new JDialog(owner, title, true);
        dialog.setUndecorated(true);
        dialog.setLayout(new BorderLayout());
        dialog.setBackground(Color.WHITE);

        JLabel guideLabel = new JLabel(guideText);
        guideLabel.setFont(MIDDLE_FONT);
        guideLabel.setForeground(Color.BLACK);
        guideLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));

        JPasswordField pwd = new JPasswordField();
        pwd.setFont(MIDDLE_FONT);
        pwd.setPreferredSize(new Dimension(240, 35));

        JPanel centerPanel = new JPanel(new BorderLayout(5, 5));
        centerPanel.setBackground(new Color(255, 250, 240));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        centerPanel.add(guideLabel, BorderLayout.NORTH);
        centerPanel.add(pwd, BorderLayout.CENTER);

        JButton okBtn = new JButton("확인");
        JButton cancelBtn = new JButton("취소");

        Font btnFont = MIDDLE_FONT;
        Dimension btnSize = new Dimension(80, 30);

        okBtn.setFont(btnFont);
        cancelBtn.setFont(btnFont);
        okBtn.setPreferredSize(btnSize);
        cancelBtn.setPreferredSize(btnSize);
        okBtn.setFocusPainted(false);
        cancelBtn.setFocusPainted(false);

        final String[] result = new String[1];

        okBtn.addActionListener(e -> {
            result[0] = new String(pwd.getPassword());
            dialog.dispose();
        });

        cancelBtn.addActionListener(e -> {
            result[0] = null;
            dialog.dispose();
        });

        dialog.getRootPane().setDefaultButton(okBtn);
        dialog.getRootPane().registerKeyboardAction(e -> {
            result[0] = null;
            dialog.dispose();
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(new Color(255, 250, 240));
        btnPanel.add(okBtn);
        btnPanel.add(cancelBtn);

        dialog.add(centerPanel, BorderLayout.CENTER);
        dialog.add(btnPanel, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(parent);
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);

        return result[0];
    }

 // 텍스트 파일 열기 및 편집 다이얼로그
    public static void showTextEditor(Component parent, File file) {
        JFrame editor = new JFrame(file.getName());
        editor.setSize(800, 550);
        editor.setLocationRelativeTo(parent);
        editor.setAlwaysOnTop(true);
        editor.setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB));
        editor.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JTextArea textArea = new JTextArea();
        textArea.setFont(MIDDLE_FONT);
        textArea.setMargin(new Insets(15, 20, 15, 20));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            textArea.read(reader, null);
        } catch (IOException e) {
            textArea.setText("해당 파일을 읽을 수 없습니다.");
        }

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        JButton saveBtn = new JButton("저장");
        saveBtn.setFont(MIDDLE_FONT);
        saveBtn.addActionListener(e -> {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write(textArea.getText());
                showMessage(editor, "성공", "저장되었습니다.");
                editor.dispose();
            } catch (IOException ex) {
                showMessage(editor, "오류", "파일 저장 실패");
            }
        });

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.setBackground(Color.DARK_GRAY);
        bottomPanel.add(saveBtn);

        editor.add(scrollPane, BorderLayout.CENTER);
        editor.add(bottomPanel, BorderLayout.SOUTH);
        editor.setVisible(true);
    }


}
