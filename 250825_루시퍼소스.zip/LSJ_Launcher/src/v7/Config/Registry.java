package v7.Config;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import v7.Avatars.Canlian;
import v7.Avatars.LSJ;
import v7.Avatars.Lucifer_Core;
import v7.Avatars.Portal;

public class Registry {

	public static int SCHEMA_VERSION = 1;
	
	// 절대 경로 설정
		public static final String BASE_PATH = Paths.get("LucidSystem").toAbsolutePath().toString();

		// 폴더 경로 설정 & ini 파일 경로
		public static final String APP_PATH = BASE_PATH + "/APP/";
		public static final String TXT_PATH = BASE_PATH + "/DIARY/";
		public static final String PNG_PATH = BASE_PATH + "/IMAGES/";
		public static final String TEMP_PATH = BASE_PATH + "/TEMP/";
		public static final String LOCK_PATH = BASE_PATH + "/LOCK/";

		public static final String REGI_PATH = BASE_PATH + "/registry.ini";
		public static final String MENU_PATH = BASE_PATH + "/menu.ini";
		public static final String SCALE_PATH = BASE_PATH + "/scale.ini";
		public static final String JSON_PATH = BASE_PATH + "/speech_data.json";
		
				// 락 함수
				
		   public static volatile boolean LOCK_ENABLED = true;

		    private static final Map<String, FileLock> PROC_LOCKS = new HashMap<>();
		    private static final Map<String, RandomAccessFile> PROC_LOCK_RAF = new HashMap<>();
		
		 public static void loadScaleIniForLock() {
		        Properties p = new Properties();
		        Path sp = Paths.get(LOCK_PATH + "/temp_lock.ini");
		        try (InputStream in = Files.newInputStream(sp);
		             InputStreamReader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
		            p.load(r);
		        } catch (IOException ignored) {}
		        String v = p.getProperty("lock.enabled", "true").trim();
		        LOCK_ENABLED = "true".equalsIgnoreCase(v);
		    }

		    public static void saveScaleIniForLock() {
		        Properties p = new Properties();
		        p.setProperty("lock.enabled", String.valueOf(LOCK_ENABLED));
		        Path sp = Paths.get(LOCK_PATH + "/temp_lock.ini");
		        try (OutputStream out = Files.newOutputStream(sp);
		             OutputStreamWriter w = new OutputStreamWriter(out, StandardCharsets.UTF_8)) {
		            p.store(w, "LSJ scale settings");
		        } catch (IOException ignored) {}
		    }

		    // 프로세스 단일 인스턴스 락 (모드별 등)
		    public static synchronized boolean tryProcessFileLock(String name) throws IOException {
		        if (!LOCK_ENABLED) return true;
		        File lockFile = new File(LOCK_PATH, name);
		        lockFile.getParentFile().mkdirs();
		        RandomAccessFile raf = new RandomAccessFile(lockFile, "rw");
		        FileChannel ch = raf.getChannel();
		        FileLock lock = ch.tryLock();
		        if (lock == null) {
		            ch.close();
		            raf.close();
		            return false;
		        }
		        PROC_LOCKS.put(name, lock);
		        PROC_LOCK_RAF.put(name, raf); // 채널 닫기 위해 보관
		        return true;
		    }

		    public static synchronized void releaseProcessFileLock(String name) {
		        FileLock lock = PROC_LOCKS.remove(name);
		        RandomAccessFile raf = PROC_LOCK_RAF.remove(name);
		        try {
		            if (lock != null) {
		                FileChannel ch = lock.channel();
		                lock.release();
		                if (ch != null) ch.close();
		            }
		        } catch (IOException ignored) {}
		        try {
		            if (raf != null) raf.close();
		        } catch (IOException ignored) {}
		    }
		

		    
		    
		 // speech_data.json 생성
			public static void make_Speech_JSON(boolean force) {
			    Path make_json_Path = Paths.get(JSON_PATH);
			    if (force || Files.notExists(make_json_Path)) {
			        try {
			            List<String> lines = Arrays.asList(
			                "{",
			                "  \"colors\": [",
			                "    \"#FFFFFF\", \"#F5F5F5\", \"#CCCCCC\",",
			                "    \"#78FFB4\", \"#A0B4F0\", \"#FF9AA2\", \"#B5EAD7\", \"#C7CEEA\", \"#FFD166\",",
			                "    \"#FFE5B4\", \"#E0BBE4\", \"#FFDAC1\", \"#E2F0CB\",",
			                "    \"#FF80B4\", \"#8CB9D7\", \"#FFC878\", \"#B478FF\", \"#FF6464\", \"#6464FF\",",
			                "    \"#FFFF96\", \"#B4FF78\", \"#FFA000\", \"#5AC8E6\", \"#C896FF\", \"#FFDCC8\",",
			                "    \"#C8FFFF\"",
			                "  ],",
			                "  \"samples1\": [",
			                "    \"좋은 아침입니다! ☀️\",",
			                "    \"오늘은 가볍게 시동 걸기 🚀\",",
			                "    \"리듬부터 찾자—작게 시작, 크게 가자!\"",
			                "  ],",
			                "  \"samples2\": [",
			                "    \"점심 뭐 먹을까? 🍜\",",
			                "    \"커피 리필 타임 ☕\",",
			                "    \"간단하게 과일도 괜찮지?\",",
			                "    \"2번 대사 그룹\"",
			                "  ],",
			                "  \"samples3\": [",
			                "    \"지금은 점심 시간 그룹3번 대사️\",",
			                "    \"치킨 3만원 광고 시간\",",
			                "    \"옷 1만 9900원 광고 시간\",",
			                "    \"돈 버는 것도 중요하니까....\"",
			                "  ],",
			                "  \"samples4\": [",
			                "    \"티셔츠 단돈 10,000원! 👕\",",
			                "    \"가볍게 사는 가격, 무겁게 다가오는 스타일.\",",
			                "    \"1만원이면 당신의 무대가 달라집니다!\"",
			                "  ],",
			                "  \"samples5\": [",
			                "    \"럭셔리 피자 한 판, 30,000원 🍕\",",
			                "    \"3만원으로 즐기는 특별한 저녁.\",",
			                "    \"가치 있는 한 끼, 투자할 만하지 않습니까?\"",
			                "  ]",
			                "}"
			            );
			            Files.write(make_json_Path, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE);
			            System.out.println("✔ speech_data.json 파일 생성 성공: " + make_json_Path.toString());
			        } catch (IOException e) {
			            System.err.println("⚠ speech_data.json 생성 실패: " + e.getMessage());
			        }
			    }
			}
 
		    
		    
		    
		    
		    
		
		// 디렉토리 만들기
		public static void initPaths() {
			try {
				Files.createDirectories(Paths.get(APP_PATH));
				Files.createDirectories(Paths.get(TXT_PATH));
				Files.createDirectories(Paths.get(PNG_PATH));
				Files.createDirectories(Paths.get(TEMP_PATH));
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		
		
		
		/// 락 함수

		public static final Properties props = new Properties();

		public static <T> void set(String key, T value) {
			props.setProperty(key, String.valueOf(value));
		}


		
		// 새로 추가한 scale.ini 네트워크 및 해상도 담당...

		// Default scale.ini values
		public static String ip = "127.0.0.1";
		public static int port = 3815;
		// 에러 상태... 숫자 초기가 0이면 안됨;;
		public static int chatting_width = 800;
		public static int chatting_height = 500;
		public static double uiScale = 1.0;
		public static String username = "LSJ";

		public static final String IMAGE_ICON_APPLE_RED = "images/apple_red.png";
		public static final String IMAGE_ICON_APPLE_GREEN = "images/apple_green.png";

		static {
			
		    load_Scale_ini(); 
			
		}

		 public static void load_Scale_ini() {
		        Path iniPath = Paths.get(SCALE_PATH);
		        if (Files.exists(iniPath)) {
		            try {
		                List<String> lines = Files.readAllLines(iniPath, StandardCharsets.UTF_8);
		                for (String line : lines) {
		                    line = line.trim();
		                    if (line.startsWith("#") || line.isEmpty()) continue;
		                    String[] parts = line.split("=");
		                    if (parts.length == 2) {
		                        String key = parts[0].trim();
		                        String value = parts[1].trim();
		                        switch (key) {
		                            case "uiScale": uiScale = Double.parseDouble(value); break;
		                            case "ip": ip = value; break;
		                            case "port": port = Integer.parseInt(value); break;
		                            case "chatting_width": chatting_width = Integer.parseInt(value); break;
		                            case "chatting_height": chatting_height = Integer.parseInt(value); break;
		                            case "username": username = value; break;
		                        }
		                    }
		                }
		                System.out.println("✔ scale.ini 로드 완료!");
		            } catch (IOException e) {
		                System.err.println("⚠ scale.ini 읽기 실패: " + e.getMessage());
		            }
		        } else {
		            make_Scale_ini(true);
		        }
		    }
		  public static void save_Scale_ini() {
		        Path iniPath = Paths.get(SCALE_PATH);
		        try {
		            List<String> lines = Arrays.asList(
		                "uiScale=" + uiScale,
		                "ip=" + ip,
		                "port=" + port,
		                "chatting_width=" + chatting_width,
		                "chatting_height=" + chatting_height,
		                "username=" + username
		            );
		            Files.write(iniPath, lines, StandardCharsets.UTF_8,
		                        StandardOpenOption.CREATE,
		                        StandardOpenOption.TRUNCATE_EXISTING);
		            System.out.println("✔ scale.ini 저장 완료!");
		        } catch (IOException e) {
		            System.err.println("⚠ scale.ini 저장 실패: " + e.getMessage());
		        }
		    }

		  
	
			     
		


		// 모드선택 - LSJ_Starter
		public static String START_MODE = "portal";

		public static int FRAME_WIDTH = 200;
		public static int FRAME_HEIGHT = 200;

		// Portal 모드
		public static Portal globalPortal;
		public static final String IMAGE_ICON_PORTAL = "images/portal.png";
		

		
		public static int PORTAL_TIMER_HEIGHT = 50;
		public static int PORTAL_SPEECH_HEIGHT = 25;
																			// 誘몄셿

		// Lucifer Core 모드
		public static Lucifer_Core globalLucifer;
		public static int[] Lucifer_dx = { 0 };
		public static int[] Lucifer_dy = { 0 };

																										// 誘몄셿
		public static final String IMAGE_ICON_LUCIFER = "images/lucifer.png";
		public static int Lucifer_ColorIndex = 0;
		public static boolean ShowSpeechLabel = true;
		public static boolean ShowInputLabel = true;
		public static int ClickCount = 0;

		// Canlian  모드
		public static Canlian globalCanlian;
		public static final String IMAGE_ICON_CANLIAN = "images/canlian.png";
		public static final int CANLIAN_IMAGE_WIDTH = 350;
		public static final int CANLIAN_IMAGE_HEIGHT = 600;

		// LSJ 모드
		public static LSJ globalLSJ;
		public static final String IMAGE_ICON_LSJ = "images/LSJ.png";
		public static final int LSJ_IMAGE_WIDTH = 350;
		public static final int LSJ_IMAGE_HEIGHT = 600;
		
		@Deprecated
		public static Color[] availableColors = new Color[]{
			    new Color(120, 255, 180),  // 민트그린
			    new Color(255, 128, 180),  // 핑크
			    new Color(140, 185, 215),  // 하늘색
			    new Color(255, 200, 120),  // 살구색
			    new Color(180, 120, 255),  // 보라
			    new Color(255, 100, 100),  // 레드

			    // 추가 색상
			    new Color(100, 100, 255),  // 블루
			    new Color(255, 255, 150),  // 연노랑
			    new Color(180, 255, 120),  // 연초록
			    new Color(255, 160, 0),    // 오렌지
			    new Color(90, 200, 230),   // 시안톤
			    new Color(200, 150, 255),  // 연보라
			    new Color(255, 220, 200),  // 피부톤
			    new Color(200, 255, 255),  // 아주 연한 하늘
			    new Color(255, 255, 255)   // 화이트 (희귀)
			};

		// 루시퍼 관련 설정
		static {
			START_MODE = LSJ_Paths.get("START_MODE", START_MODE);
			FRAME_WIDTH = LSJ_Paths.get("FRAME_WIDTH", FRAME_WIDTH);
			FRAME_HEIGHT = LSJ_Paths.get("FRAME_HEIGHT", FRAME_HEIGHT);
			PORTAL_TIMER_HEIGHT = LSJ_Paths.get("PORTAL_TIMER_HEIGHT", PORTAL_TIMER_HEIGHT);
			PORTAL_SPEECH_HEIGHT = LSJ_Paths.get("PORTAL_SPEECH_HEIGHT", PORTAL_SPEECH_HEIGHT);
			Lucifer_dx[0] = LSJ_Paths.get("Lucifer_dx", 0);
			Lucifer_dy[0] = LSJ_Paths.get("Lucifer_dy", 0);
			Lucifer_ColorIndex = LSJ_Paths.get("Lucifer_ColorIndex", Lucifer_ColorIndex);
			ShowSpeechLabel = LSJ_Paths.get("ShowSpeechLabel", ShowSpeechLabel);
			ShowInputLabel = LSJ_Paths.get("ShowInputLabel", ShowInputLabel);
			ClickCount = LSJ_Paths.get("ClickCount", ClickCount);

		}

		// LSJ Frame 유틸리티 관련 설정

		public static String LSJ_TITLE_COLOR = "#64B478";
		public static int LSJ_WIDTH = 800;
		public static int LSJ_HEIGHT = 800;

		public static boolean AlwaysOnTop = true;
		public static boolean SetUndecorated = true;

		public static int MIN_WIDTH = 400;
		public static int MIN_HEIGHT = 300;
		public static int MAX_WIDTH = MIN_WIDTH * 4;
		public static int MAX_HEIGHT = MIN_HEIGHT * 4;

		public static Dimension LSJ_Launcher_SIZE = new Dimension(1000, 800);
		public static Point LSJ_Launcher_LOC = new Point(710, 10);
		public static Dimension LSJ_Diary_SIZE = new Dimension(700, 550);
		public static Point LSJ_Diary_LOC = new Point(10, 10);
		public static Dimension LSJ_Drawing_SIZE = new Dimension(700, 550);
		public static Point LSJ_Drawing_LOC = new Point(10, 560);

		public static Dimension LSJ_Viewer_SIZE = new Dimension(700, 550);
		public static Point LSJ_Viewer_LOC = new Point(10, 1110);
		public static Dimension LSJ_Status_SIZE = new Dimension(700, 500);
		public static Point LSJ_Status_LOC = new Point(710, 250);
		public static Dimension LSJ_Control_SIZE = new Dimension(1000, 800);
		public static Point LSJ_Control_LOC = new Point(710, 810);

		public static final String DIARY_PLACEHOLDER =     "www.dgmayor.com LSJ 루시퍼와 함께 기억을 담다\n\n" +  "Canlian, 캔리안, 위버 모든 제작자들과 함께합니다.\n\n";  // ini
																																													

		public static Color DIARY_BG_COLOR = new Color(30, 60, 90); // 위버의 색
		public static Color DIARY_FONT_COLOR = Color.WHITE; // 다이어리 폰트 컬러
		public static Color UI_BG_COLOR = new Color(240, 240, 240); // UI 배경 색

		static {

			LSJ_TITLE_COLOR = LSJ_Paths.get("LSJ_TITLE_COLOR", LSJ_TITLE_COLOR);
			LSJ_WIDTH = LSJ_Paths.get("LSJ_WIDTH", LSJ_WIDTH);
			LSJ_HEIGHT = LSJ_Paths.get("LSJ_HEIGHT", LSJ_HEIGHT);

			AlwaysOnTop = LSJ_Paths.get("AlwaysOnTop", AlwaysOnTop);
			// SetUndecorated = RegistryLoader.get("SetUndecorated",
			// SetUndecorated);

			MIN_WIDTH = LSJ_Paths.get("MIN_WIDTH", MIN_WIDTH);
			MIN_HEIGHT = LSJ_Paths.get("MIN_HEIGHT", MIN_HEIGHT);
			MAX_WIDTH = LSJ_Paths.get("MAX_WIDTH", MAX_WIDTH);
			MAX_HEIGHT = LSJ_Paths.get("MAX_HEIGHT", MAX_HEIGHT);

			LSJ_Launcher_SIZE = LSJ_Paths.parseDimension(LSJ_Paths.get("LSJ_Launcher_SIZE", "600,400"), LSJ_Launcher_SIZE);
			LSJ_Launcher_LOC = LSJ_Paths.parsePoint(LSJ_Paths.get("LSJ_Launcher_LOC", "10,10"), LSJ_Launcher_LOC);
			LSJ_Diary_SIZE = LSJ_Paths.parseDimension(LSJ_Paths.get("LSJ_Diary_SIZE", "600,400"), LSJ_Diary_SIZE);
			LSJ_Diary_LOC = LSJ_Paths.parsePoint(LSJ_Paths.get("LSJ_Diary_LOC", "10,10"), LSJ_Diary_LOC);
			LSJ_Drawing_SIZE = LSJ_Paths.parseDimension(LSJ_Paths.get("LSJ_Drawing_SIZE", "600,400"), LSJ_Drawing_SIZE);
			LSJ_Drawing_LOC = LSJ_Paths.parsePoint(LSJ_Paths.get("LSJ_Drawing_LOC", "10,10"), LSJ_Drawing_LOC);

			LSJ_Viewer_SIZE = LSJ_Paths.parseDimension(LSJ_Paths.get("LSJ_Viewer_SIZE", "600,400"), LSJ_Viewer_SIZE);
			LSJ_Viewer_LOC = LSJ_Paths.parsePoint(LSJ_Paths.get("LSJ_Viewer_LOC", "10,10"), LSJ_Viewer_LOC);
			LSJ_Status_SIZE = LSJ_Paths.parseDimension(LSJ_Paths.get("LSJ_Status_SIZE", "600,400"), LSJ_Status_SIZE);
			LSJ_Status_LOC = LSJ_Paths.parsePoint(LSJ_Paths.get("LSJ_Status_LOC", "10,10"), LSJ_Status_LOC);
			LSJ_Control_SIZE = LSJ_Paths.parseDimension(LSJ_Paths.get("LSJ_Control_SIZE", "600,400"), LSJ_Control_SIZE);
			LSJ_Control_LOC = LSJ_Paths.parsePoint(LSJ_Paths.get("LSJ_Control_LOC", "10,10"), LSJ_Control_LOC);

			DIARY_BG_COLOR = LSJ_Paths.fromHex(LSJ_Paths.get("DIARY_BG_COLOR", "#306090"), DIARY_BG_COLOR);
			DIARY_FONT_COLOR = LSJ_Paths.fromHex(LSJ_Paths.get("DIARY_FONT_COLOR", "#FFFFFF"), DIARY_FONT_COLOR);
			UI_BG_COLOR = LSJ_Paths.fromHex(LSJ_Paths.get("UI_BG_COLOR", "#C0C0C0"), UI_BG_COLOR);

		}

		// scale.ini 생성
			public static void make_Scale_ini(boolean force) {
			    Path make_txt_Path = Paths.get(SCALE_PATH);
			    if (force || Files.notExists(make_txt_Path)) {
			        try {
			            List<String> lines = Arrays.asList(
			                    "uiScale=" + uiScale,
				            	"ip =" + ip,
				            	"port =" + port,
				            	"chatting_width =" + chatting_width,
				            	"chatting_height =" + chatting_height,
				            	"username =" + username
			            );
			            Files.write(make_txt_Path, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE);
			            System.out.println("✔ scale.ini 파일 생성 성공: " + make_txt_Path.toString());
			        } catch (IOException e) {
			            System.err.println("⚠ scale.ini 생성 실패: " + e.getMessage());
			        }
			    }
			}
		
		// menu.ini 생성
		public static void make_Menu_ini(boolean force) {
		    Path make_txt_Path = Paths.get(MENU_PATH);
		    if (force || Files.notExists(make_txt_Path)) {
		        try {
		            List<String> lines = Arrays.asList(
		                "Nova 다이어리 , LSJ_Frame, Nova_Diary",
		                "Weaver 캔버스, LSJ_Frame, Weaver_Canvas",
		                "LSJ 뷰어, LSJ_Frame, LSJ_Viewer",
		                "환경 설정, LSJ_Frame, LSJ_Status",
		                "루시퍼 콘트롤, LSJ_Frame, Control_L",
		                "채팅 서버, Network_Frame, Server",
		                "채팅 클라이언트, Network_Frame, Client",
		                "포탈 숨기기, Earth_Frame, Lucifer_Hide",
		                "@포탈 보이기, Earth_Frame, Lucifer_Show",
		                "#포탈 종료하기, Earth_Frame, Lucifer_Close"
		            );
		            Files.write(make_txt_Path, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE);
		            System.out.println("✔ menu.ini 파일 생성 성공: " + make_txt_Path.toString());
		        } catch (IOException e) {
		            System.err.println("⚠ menu.ini 생성 실패: " + e.getMessage());
		        }
		    }
		}

		// registry.ini 생성
		public static void make_Registry_ini(boolean force) {
		    Path make_txt_Path = Paths.get(REGI_PATH);
		    if (force || Files.notExists(make_txt_Path)) {
		        try {
		            List<String> lines = Arrays.asList(
		                "START_MODE=" + "lucifer",
		                "FRAME_WIDTH=" + FRAME_WIDTH,
		                "FRAME_HEIGHT=" + FRAME_HEIGHT,
		                "PORTAL_TIMER_HEIGHT=" + PORTAL_TIMER_HEIGHT,
		                "PORTAL_SPEECH_HEIGHT=" + PORTAL_SPEECH_HEIGHT,
		                "Lucifer_dx=1",
		                "Lucifer_dy=0",
		                "Lucifer_ColorIndex=" + Lucifer_ColorIndex,
		                "ShowSpeechLabel=" + ShowSpeechLabel,
		                "ShowInputLabel=" + ShowInputLabel,
		                "ClickCount=" + ClickCount,

		                "LSJ_TITLE_COLOR=#64B478",
		                "LSJ_WIDTH=800",
		                "LSJ_HEIGHT=800",
		                "AlwaysOnTop=true",
		                "SetUndecorated=true",

		                "MIN_WIDTH=400",
		                "MIN_HEIGHT=300",
		                "MAX_WIDTH=1600",
		                "MAX_HEIGHT=1200",

		                "LSJ_Launcher_SIZE=500,400",
		                "LSJ_Launcher_LOC=10,10",
		                "LSJ_Diary_SIZE=500,400",
		                "LSJ_Diary_LOC=10,10",
		                "LSJ_Drawing_SIZE=500,400",
		                "LSJ_Drawing_LOC=10,10",
		                "LSJ_Viewer_SIZE=500,400",
		                "LSJ_Viewer_LOC=10,10",
		                "LSJ_Status_SIZE=500,400",
		                "LSJ_Status_LOC=10,10",
		                "LSJ_Control_SIZE=500,400",
		                "LSJ_Control_LOC=10,10",

		                "DIARY_BG_COLOR=#306090",
		                "DIARY_FONT_COLOR=#FFFFFF",
		                "UI_BG_COLOR=#C0C0C0"
		            );
		            Files.write(make_txt_Path, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE);
		            System.out.println("✔ registry.ini 파일 생성 성공: " + make_txt_Path.toString());
		        } catch (IOException e) {
		            System.err.println("⚠ registry.ini 생성 실패: " + e.getMessage());
		        }
		    }
		}

		
		
		
		// 모든 레지스트리 저장
		public static void saveAllRegistry() {
			set("START_MODE", Registry.START_MODE);
			set("FRAME_WIDTH", Registry.FRAME_WIDTH);
			set("FRAME_HEIGHT", Registry.FRAME_HEIGHT);
			set("PORTAL_TIMER_HEIGHT", Registry.PORTAL_TIMER_HEIGHT);
			set("PORTAL_SPEECH_HEIGHT", Registry.PORTAL_SPEECH_HEIGHT);
			set("Lucifer_dx", Registry.Lucifer_dx[0]);
			set("Lucifer_dy", Registry.Lucifer_dy[0]);
			set("Lucifer_ColorIndex", Registry.Lucifer_ColorIndex);
			set("ShowSpeechLabel", Registry.ShowSpeechLabel);
			set("ShowInputLabel", Registry.ShowInputLabel);
			set("ClickCount", Registry.ClickCount);

			set("LSJ_TITLE_COLOR", Registry.LSJ_TITLE_COLOR);
			set("LSJ_WIDTH", Registry.LSJ_WIDTH);
			set("LSJ_HEIGHT", Registry.LSJ_HEIGHT);
			set("AlwaysOnTop", Registry.AlwaysOnTop);
			set("SetUndecorated", Registry.SetUndecorated);
			set("MIN_WIDTH", Registry.MIN_WIDTH);
			set("MIN_HEIGHT", Registry.MIN_HEIGHT);
			set("MAX_WIDTH", Registry.MAX_WIDTH);
			set("MAX_HEIGHT", Registry.MAX_HEIGHT);
			set("LSJ_Launcher_SIZE", Registry.LSJ_Launcher_SIZE.width + "," + Registry.LSJ_Launcher_SIZE.height);
			set("LSJ_Launcher_LOC", Registry.LSJ_Launcher_LOC.x + "," + Registry.LSJ_Launcher_LOC.y);
			set("LSJ_Diary_SIZE", Registry.LSJ_Diary_SIZE.width + "," + Registry.LSJ_Diary_SIZE.height);
			set("LSJ_Diary_LOC", Registry.LSJ_Diary_LOC.x + "," + Registry.LSJ_Diary_LOC.y);
			set("LSJ_Drawing_SIZE", Registry.LSJ_Drawing_SIZE.width + "," + Registry.LSJ_Drawing_SIZE.height);
			set("LSJ_Drawing_LOC", Registry.LSJ_Drawing_LOC.x + "," + Registry.LSJ_Drawing_LOC.y);
			set("LSJ_Viewer_SIZE", Registry.LSJ_Viewer_SIZE.width + "," + Registry.LSJ_Viewer_SIZE.height);
			set("LSJ_Viewer_LOC", Registry.LSJ_Viewer_LOC.x + "," + Registry.LSJ_Viewer_LOC.y);
			set("LSJ_Status_SIZE", Registry.LSJ_Status_SIZE.width + "," + Registry.LSJ_Status_SIZE.height);
			set("LSJ_Status_LOC", Registry.LSJ_Status_LOC.x + "," + Registry.LSJ_Status_LOC.y);
			set("LSJ_Control_SIZE", Registry.LSJ_Control_SIZE.width + "," + Registry.LSJ_Control_SIZE.height);
			set("LSJ_Control_LOC", Registry.LSJ_Control_LOC.x + "," + Registry.LSJ_Control_LOC.y);
			set("DIARY_BG_COLOR", String.format("#%02X%02X%02X", Registry.DIARY_BG_COLOR.getRed(),
					Registry.DIARY_BG_COLOR.getGreen(), Registry.DIARY_BG_COLOR.getBlue()));
			set("DIARY_FONT_COLOR", String.format("#%02X%02X%02X", Registry.DIARY_FONT_COLOR.getRed(),
					Registry.DIARY_FONT_COLOR.getGreen(), Registry.DIARY_FONT_COLOR.getBlue()));
			set("UI_BG_COLOR", String.format("#%02X%02X%02X", Registry.UI_BG_COLOR.getRed(),
					Registry.UI_BG_COLOR.getGreen(), Registry.UI_BG_COLOR.getBlue()));

			saveInDefinedOrder();
		}

		// 레지스트리 차례 대로 정렬
		public static void saveInDefinedOrder() {
			List<String> orderedKeys = Arrays.asList("START_MODE", "FRAME_WIDTH", "FRAME_HEIGHT", "PORTAL_TIMER_HEIGHT",
					"PORTAL_SPEECH_HEIGHT", "Lucifer_dx", "Lucifer_dy", "Lucifer_ColorIndex", "ShowSpeechLabel",
					"ShowInputLabel", "ClickCount",

					"LSJ_TITLE_COLOR", "LSJ_WIDTH", "LSJ_HEIGHT", "AlwaysOnTop", "SetUndecorated", "MIN_WIDTH",
					"MIN_HEIGHT", "MAX_WIDTH", "MAX_HEIGHT", "LSJ_Launcher_SIZE", "LSJ_Launcher_LOC", "LSJ_Diary_SIZE",
					"LSJ_Diary_LOC", "LSJ_Drawing_SIZE", "LSJ_Drawing_LOC", "LSJ_Viewer_SIZE", "LSJ_Viewer_LOC",
					"LSJ_Status_SIZE", "LSJ_Status_LOC", "LSJ_Control_SIZE", "LSJ_Control_LOC", "DIARY_BG_COLOR",
					"DIARY_FONT_COLOR", "UI_BG_COLOR");

			try {
				Path path = Paths.get(REGI_PATH);
				List<String> lines = new ArrayList<>();
				for (String key : orderedKeys) {
					String value = props.getProperty(key);
					if (value != null) {
						lines.add(key + "=" + value);
					}
				}
				Files.write(path, lines, StandardCharsets.UTF_8);
				System.out.println("Registry.ini 를 순서대로 정렬 하였습니다.");
			} catch (IOException e) {
				System.err.println("에러 발생 : " + e.getMessage());
			}
		}

	}

	
	


