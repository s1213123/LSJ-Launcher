package v7.Dimensions.Network_Frame;

import java.awt.BorderLayout;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;

import v7.Config.Registry;

public class Server_old extends JPanel {
    private JTextPane messagePane;
    private JTextField inputField;

    // 메시지 로그는 단순 누적 리스트로 유지(동시 접근 적음)
    private final List<String> messageLog = new ArrayList<>();

    // 동시성 안전한 브로드캐스트 대상 목록
    private final CopyOnWriteArrayList<BufferedWriter> clientWriters = new CopyOnWriteArrayList<>();

    // ★ 필드 서버소켓 (실제 사용하는 소켓)
    private ServerSocket serverSocket;

    private final AtomicBoolean iconSet = new AtomicBoolean(false);
    private final AtomicBoolean running = new AtomicBoolean(false);

    public Server_old() {
        setLayout(new BorderLayout());

        JPanel panel = this;

        // 아이콘은 네가 쓰던 그대로
        addHierarchyListener(new HierarchyListener() {
            @Override public void hierarchyChanged(HierarchyEvent e) {
                if ((e.getChangeFlags() & HierarchyEvent.DISPLAYABILITY_CHANGED) != 0 && isDisplayable()) {
                    SwingUtilities.invokeLater(() ->
                        NetworkHelper.installWindowIconOnce(panel, iconSet, "/images/apple_red.png")
                    );
                }
            }
        });

        messagePane = new JTextPane();
        messagePane.setEditable(false);
        add(new JScrollPane(messagePane), BorderLayout.CENTER);

        inputField = new JTextField();
        JButton sendBtn = new JButton("서버 전송");
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.add(inputField, BorderLayout.CENTER);
        bottom.add(sendBtn, BorderLayout.EAST);
        add(bottom, BorderLayout.SOUTH);

        sendBtn.addActionListener(e -> sendFromServer());
        inputField.addActionListener(e -> sendFromServer());

        // 서버 시작
        new Thread(this::startServer, "LSJ-Server-Accept").start();

        // ★ 패널이 사라질 때 서버/소켓 정리 (간단·명확)
        NetworkHelper.onDispose(this, this::closeServer);
    }

    private void sendFromServer() {
        String msg = inputField.getText().trim();
        if (!msg.isEmpty()) {
            messageLog.add(msg);
            append("서버 : ", msg);
            broadcast(msg);
            inputField.setText("");
        }
    }

    private void broadcast(String msg) {
        for (BufferedWriter writer : clientWriters) {
            try {
                NetworkHelper.sendLine(writer, msg);
            } catch (IOException e) {
                // 전송 실패 시 대상 제거
                clientWriters.remove(writer);
                append("시스템", ": 전송 오류로 대상 제거");
            }
        }
    }

    private void append(String sender, String message) {
        SwingUtilities.invokeLater(() -> {
            try {
                messagePane.getDocument().insertString(
                    messagePane.getDocument().getLength(),
                    sender + message + "\n", null
                );
                messagePane.setCaretPosition(messagePane.getDocument().getLength());
            } catch (Exception ex) {
                // 필요하면 로그
            }
        });
    }
/*
    private void startServer() {
        try {
            // ★ 필드에 직접 할당 (지역변수로 새로 만들지 않음)
            serverSocket = new ServerSocket(Registry.port);
            running.set(true);
            append("시스템", ": 서버 시작됨 (포트 " + Registry.port + ")");

            while (running.get()) {
                Socket client = serverSocket.accept();

                // 새 클라이언트의 writer 등록
                BufferedWriter out = NetworkHelper.getWriter(client);
                clientWriters.add(out);

                // (옵션) 기존 로그 전송을 원하면 주석 해제
                
                for (String msg : messageLog) {
                    try { NetworkHelper.sendLine(out, msg); } catch (IOException ignore) {}
                }
                

                // 수신 스레드
                Thread t = new Thread(() -> handleClient(client), "LSJ-Server-Client");
                t.setDaemon(true);
                t.start();
            }
        } catch (IOException e) {
            // running 중에만 에러 메시지 표기 (정상 종료 중 accept 에러는 무시 가능)
            if (running.get()) append("시스템", ": 서버 오류: " + e.getMessage());
        }
    }
*/
    

private void startServer() {
    try {
        serverSocket = new ServerSocket(Registry.port);
        running.set(true);
        append("시스템", ": 서버 시작됨 (포트 " + Registry.port + ")");

        while (running.get()) {
            Socket client = serverSocket.accept();
            BufferedWriter out = NetworkHelper.getWriter(client);
            clientWriters.add(out);

            new Thread(() -> {
                try (BufferedReader in = NetworkHelper.getReader(client)) {
                    String line;
                    while ((line = in.readLine()) != null) {
                        messageLog.add(line);
                        append("", line);
                        broadcast(line);
                    }
                } catch (IOException e) {
                    append("시스템", ": 연결 종료됨");
                } finally {
                    // 이 클라 writer 제거
                    try {
                        BufferedWriter w = NetworkHelper.getWriter(client);
                        clientWriters.remove(w);
                    } catch (IOException ignore) {}
                    NetworkHelper.closeQuiet(client);
                }
            }, "LSJ-Server-Client").start();
        }
    } catch (IOException e) {
        if (running.get()) append("시스템", ": 서버 오류: " + e.getMessage());
    }
}
    
    /*
    private void handleClient(Socket client) {
        try (BufferedReader in = NetworkHelper.getReader(client)) {
            String line;
            while ((line = in.readLine()) != null) {
                messageLog.add(line);
                append("", line);
                broadcast(line);
            }
        } catch (IOException e) {
            append("시스템", ": 연결 종료됨");
        } finally {
            // 이 클라이언트의 writer 제거
            try {
                BufferedWriter out = NetworkHelper.getWriter(client);
                clientWriters.remove(out);
            } catch (IOException ignore) {}
            NetworkHelper.closeQuiet(client);
        }
    }*/

    // ★ 서버 종료(패널 dispose 시 호출)
    private void closeServer() {
        running.set(false);
        NetworkHelper.closeQuiet(serverSocket);
        serverSocket = null;
        append("시스템", ": 서버 종료됨");
    }
}


/*public class Server extends JPanel {
    private JTextPane messagePane;
    private JTextField inputField;
    private final List<String> messageLog = new ArrayList<>();
    private final List<BufferedWriter> clientWriters = new ArrayList<>();

    private ServerSocket serverSocket;
    
    private final AtomicBoolean iconSet = new AtomicBoolean(false);

	
    
    
    public Server() {
        setLayout(new BorderLayout());

 
        JPanel panel = this; // this가 JPanel일 경우

    	addHierarchyListener(new HierarchyListener() {
		    @Override public void hierarchyChanged(HierarchyEvent e) {
		        if ((e.getChangeFlags() & HierarchyEvent.DISPLAYABILITY_CHANGED) != 0 && isDisplayable()) {
		            SwingUtilities.invokeLater(() ->
		                NetworkHelper.installWindowIconOnce(panel, iconSet, "/images/apple_red.png")
		            );
		        }
		    }
		});

        
        messagePane = new JTextPane();
        messagePane.setEditable(false);
        add(new JScrollPane(messagePane), BorderLayout.CENTER);

        inputField = new JTextField();
        JButton sendBtn = new JButton("서버 전송");
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.add(inputField, BorderLayout.CENTER);
        bottom.add(sendBtn, BorderLayout.EAST);
        add(bottom, BorderLayout.SOUTH);

        sendBtn.addActionListener(e -> sendFromServer());
        inputField.addActionListener(e -> sendFromServer());

        // 서버 시작
        new Thread(this::startServer, "LSJ-Server-Accept").start();

        // ★ 패널이 사라질 때 서버/소켓 정리 (간단·명확)
        NetworkHelper.onDispose(this, this::closeServer);



        
    }

    
    
    
    private void sendFromServer() {
        String msg = inputField.getText().trim();
        if (!msg.isEmpty()) {
            String full = msg;
            messageLog.add(full);
            append("서버 : ", msg);
            broadcast(full);
            inputField.setText("");
        }
    }

    private void broadcast(String msg) {
        for (BufferedWriter writer : clientWriters) {
            try {
                NetworkHelper.sendLine(writer, msg);
            } catch (IOException e) {
                append("시스템", ": 전송 오류: " + e.getMessage());
            }
        }
    }

    private void append(String sender, String message) {
        try {
            messagePane.getDocument().insertString(
                messagePane.getDocument().getLength(),
                sender + message + "\n", null);
            messagePane.setCaretPosition(messagePane.getDocument().getLength());
        } catch (Exception ex) {
           // ex.printStackTrace();
        	// 나중 유저 수 늘어나면 추가하면 됨
        	
        }
    }

    private void startServer() {
        try (ServerSocket serverSocket = new ServerSocket(Registry.port)) {
            append("시스템", ": 서버 시작됨 (포트 " + Registry.port + ")");

            while (true) {
                Socket client = serverSocket.accept();
                BufferedWriter out = NetworkHelper.getWriter(client);
                clientWriters.add(out);

                // 로그 전송
                for (String msg : messageLog) {
                    NetworkHelper.sendMessage(out, msg);
                }

                // 메시지 수신 처리
                new Thread(() -> {
                    try (BufferedReader in = NetworkHelper.getReader(client)) {
                        String line;
                        while ((line = in.readLine()) != null) {
                            String full =  line;
                            messageLog.add(full);
                            append("", line);
                            broadcast(full);
                        }
                    } catch (IOException e) {
                        append("시스템", ": 연결 종료됨");
                    }
                }).start();
            }
        } catch (IOException e) {
            append("시스템", ": 서버 오류: " + e.getMessage());
        }
    }
}
*/
