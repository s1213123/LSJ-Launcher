package v7.Dimensions.Network_Frame;

import java.awt.BorderLayout;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import v7.Config.Registry;

public class Server extends JPanel {
	
	
    private final JTextArea log = new JTextArea(12, 60);
    private final JTextField input = new JTextField();
    private final JButton sendBtn = new JButton("전송");

    private final JLabel userCountLabel = new JLabel("접속자: 0");

    
    private volatile ServerSocket serverSocket;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private Thread acceptThread;

    private final CopyOnWriteArrayList<BufferedWriter> writers = new CopyOnWriteArrayList<>();

    //해쉬맵
    private final Set<String> knownUsers = ConcurrentHashMap.newKeySet();
    private final Map<Socket, String> userBySocket = new ConcurrentHashMap<>();
    

    private final AtomicBoolean iconSet = new AtomicBoolean(false);
    
	
	public Server() {
	super(new BorderLayout());
		
	  // 프레임에 실제로 붙었을 때 아이콘 1회 설정
    JPanel panel = this;
    addHierarchyListener(new HierarchyListener() {
        @Override public void hierarchyChanged(HierarchyEvent e) {
            if ((e.getChangeFlags() & HierarchyEvent.DISPLAYABILITY_CHANGED) != 0 && isDisplayable()) {
                SwingUtilities.invokeLater(() ->
                    NetworkHelper.installWindowIconOnce(panel, iconSet, "/images/apple_green.png")
                );
            }
        }
    });
	

    
	  log.setEditable(false);
      add(userCountLabel, BorderLayout.NORTH);

      add(new JScrollPane(log), BorderLayout.CENTER);

      JPanel south = new JPanel(new BorderLayout(6,6));
      south.add(input, BorderLayout.CENTER);
      south.add(sendBtn, BorderLayout.EAST);
      add(south, BorderLayout.SOUTH);

      sendBtn.addActionListener(e -> {
          String msg = input.getText().trim();
          if (msg.isEmpty()) return;
          broadcast("서버 : " + msg);
          append("서버 : " + msg);
          input.setText("");
      });
      input.addActionListener(e -> sendBtn.doClick());

      // 시작
      acceptThread = new Thread(this::startServer, "MiniServer-Accept");
      acceptThread.start();

      
      
     /* // 패널이 사라질 때 정리
      NetworkHelper.onDispose(this, this::stopServer);
	*/
      
    
   
      
	}
	
    private void updateUserCount() {
        SwingUtilities.invokeLater(() ->
            userCountLabel.setText("접속자: " + writers.size())
        );
        // ★ 클라이언트들에게도 알려주기
        broadcast("SYS USERS " + writers.size());
    }

    
    private void startServer() {
        if (!running.compareAndSet(false, true)) {
            append("시스템 : 이미 실행 중");
            return;
        }
        try {
            ServerSocket ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(Registry.port));
            serverSocket = ss;

            append("시스템 : 서버 시작 (포트 " + Registry.port + ")");
            while (running.get()) {
                Socket client = ss.accept();
                final BufferedWriter out = NetworkHelper.getWriter(client);
                writers.add(out);

             // 접속하자마자 자기한테도 현재 숫자 1회 전달 (초기 표시용)
             try { NetworkHelper.sendLine(out, "SYS USERS " + writers.size()); } catch (IOException ignore) {}

                updateUserCount();

                Thread t = new Thread(() -> handleClient(client, out), "MiniServer-Client");
                t.setDaemon(true);
                t.start();
            }
        } catch (IOException e) {
            append("시스템 : 서버 오류 - " + e.getClass().getSimpleName() + " : " + e.getMessage());
        } finally {
            running.set(false);
            NetworkHelper.closeQuiet(serverSocket);
            serverSocket = null;
            append("시스템 : 서버 쓰레드 종료");
        }
    }

    private void handleClient(Socket client, BufferedWriter out) {
        try (BufferedReader in = NetworkHelper.getReader(client)) {
            String line;
            while ((line = in.readLine()) != null) {
             
            	
             	// 해쉬맵
                int sep = line.indexOf(" : ");
                if (sep > 0) {
                    String nick = line.substring(0, sep).trim();
                    if (!nick.isEmpty() && knownUsers.add(nick)) {
                        append("시스템 : " + nick + " 접속");
                        broadcast(nick + "님이 접속 했습니다. 환영합니다.");
                        userBySocket.putIfAbsent(client, nick); 
                        // (선택) userCount도 갱신하고 싶으면 updateUserCount(); 호출
                    }
                }
            	//해쉬맵
            	
            	
            	
            	
            	append(line);
                broadcast(line);
            }
        } catch (IOException ignore) {
            append("시스템 : 연결 종료");
        } finally {
        	
        	/* String left = userBySocket.remove(client);
        	    if (left != null) {
        	        String msg = "시스템 : " + left + " 퇴장";
        	        append(msg);
        	        broadcast(msg);
        	        updateUserCount();
        	    }
        	    
        	
            writers.remove(out);*/
        	
        	  String left = userBySocket.remove(client);   // ★ 소켓→닉 제거
        	    if (left != null) {
        	        String msg = left + "유저님이 퇴장하셨습니다.";
        	        append(msg);
        	        broadcast(msg);
        	        updateUserCount();                       // (쓰고 있다면)
        	    }            
            
            updateUserCount();
            NetworkHelper.closeQuiet(client);
        }
    }

    private void broadcast(String line) {
        for (BufferedWriter w : writers) {
            try {
                NetworkHelper.sendLine(w, line);
            } catch (IOException ignore) {
                writers.remove(w);
               
            }
        }
    }

    private void append(String s) {
        SwingUtilities.invokeLater(() -> {
            log.append(s + "\n");
            log.setCaretPosition(log.getDocument().getLength());
        });
    }

    private void stopServer() {
        if (!running.get()) return;
        append("시스템 : 서버 종료 중…");
        running.set(false);
        NetworkHelper.closeQuiet(serverSocket); // accept 깨움
        try { if (acceptThread != null) acceptThread.join(1000); } catch (InterruptedException ignore) {}
        append("시스템 : 서버 종료됨");
    }
    
    public void shutdown() {  // 창 닫힐 때 호출용
        // 내부에서 stopServer() 호출하도록 되어 있다면 그거 부르면 됨
        try {  stopServer();  } catch (Exception ignore) {}
    }

    
/*
    // 단독 실행 확인용
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame f = new JFrame("ServerMini");
            f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            f.setContentPane(new ServerMini());
            f.pack();
            f.setLocationRelativeTo(null);
            f.setVisible(true);
        });


    }*/
/*
    JPanel serverPanel = new ServerMini();
    mainFrame.add(serverPanel, BorderLayout.CENTER);*/
}
