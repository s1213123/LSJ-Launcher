package v7.Dimensions.Network_Frame;

import java.awt.Frame;
import java.awt.Image;
import java.awt.Window;
import java.awt.event.HierarchyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class NetworkHelper {


    public static void installWindowIconOnce(JPanel panel, AtomicBoolean iconSetFlag, String icon) {
        if (iconSetFlag.get()) return;
        Window w = SwingUtilities.getWindowAncestor(panel);
        if (!(w instanceof Frame)) return;

        List<Image> icons = new ArrayList<>();
        URL u16 = panel.getClass().getResource("/images/icon16.png");
        URL u32 = panel.getClass().getResource("/images/icon32.png");
        URL u64 = panel.getClass().getResource("/images/icon64.png");

        if (u16 != null) icons.add(new ImageIcon(u16).getImage());
        if (u32 != null) icons.add(new ImageIcon(u32).getImage());
        if (u64 != null) icons.add(new ImageIcon(u64).getImage());

        if (icons.isEmpty()) {
            URL u = panel.getClass().getResource(icon);
            if (u != null) icons.add(new ImageIcon(u).getImage());
            else icons.add(new ImageIcon("src/resources" + icon).getImage()); // fallback
        }

        ((Frame) w).setIconImages(icons);
        iconSetFlag.set(true);
    }
	
    
    
    // --- 패널이 화면에서 사라질 때 한 번만 호출할 정리 훅(간단) ---
    public static void onDispose(JComponent comp, Runnable action) {
        comp.addHierarchyListener(e -> {
            if ((e.getChangeFlags() & HierarchyEvent.DISPLAYABILITY_CHANGED) != 0) {
                if (!comp.isDisplayable()) {
                    try { action.run(); } catch (Exception ignore) {}
                }
            }
        });
    }
    
    // --- I/O (UTF-8 고정) ---
    public static BufferedReader getReader(Socket s) throws IOException {
        return new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
    }
    public static BufferedWriter getWriter(Socket s) throws IOException {
        return new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), "UTF-8"));
    }
    public static void sendLine(BufferedWriter out, String msg) throws IOException {
        out.write(msg);
        out.newLine();
        out.flush();
    }

    // --- 안전 종료(조용히) ---
    public static void closeQuiet(Closeable c) { try { if (c!=null) c.close(); } catch (IOException ignore) {} }
    public static void closeQuiet(Socket s)     { try { if (s!=null) s.close(); } catch (IOException ignore) {} }
    public static void closeQuiet(ServerSocket s){ try { if (s!=null) s.close(); } catch (IOException ignore) {} }

}
