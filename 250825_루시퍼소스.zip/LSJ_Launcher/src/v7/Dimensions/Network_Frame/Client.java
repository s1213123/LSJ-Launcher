package v7.Dimensions.Network_Frame;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import v7.Config.Registry;

public class Client extends JPanel implements Closeable {
    private final JTextArea chat = new JTextArea(12, 48);
    private final JTextField input = new JTextField();
    private final JButton sendBtn = new JButton("전송");

    private final JTextField host = new JTextField(Registry.ip != null ? Registry.ip : "127.0.0.1", 12);
    private final JTextField port = new JTextField(String.valueOf(Registry.port), 5);
    private final JTextField name = new JTextField(Registry.username != null ? Registry.username : "User", 10);
    private final JButton connectBtn = new JButton("연결");
    private final JLabel status = new JLabel("🔴 미연결");
    
    private final JLabel userCount = new JLabel("접속자: -");

    
    private volatile Socket socket;
    private volatile BufferedReader in;
    private volatile BufferedWriter out;
    private Thread readerThread;
    
    private final AtomicBoolean running = new AtomicBoolean(false);
    
    private final AtomicBoolean iconSet = new AtomicBoolean(false);
    private final AtomicBoolean closing = new AtomicBoolean(false);


    public Client() {
        super(new BorderLayout(6,6));

        // 프레임에 실제로 붙었을 때 아이콘 1회 설정
        JPanel panel = this;
        addHierarchyListener(new HierarchyListener() {
            @Override public void hierarchyChanged(HierarchyEvent e) {
                if ((e.getChangeFlags() & HierarchyEvent.DISPLAYABILITY_CHANGED) != 0 && isDisplayable()) {
                    SwingUtilities.invokeLater(() ->
                        NetworkHelper.installWindowIconOnce(panel, iconSet, "/images/apple_green.png")
                    );
                }
            }
        });
        
        
        
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        top.add(new JLabel("Host")); top.add(host);
        top.add(new JLabel("Port")); top.add(port);
        top.add(new JLabel("Name")); top.add(name);
        
        
        host.setEditable(false); host.setFocusable(false);
        port.setEditable(false); port.setFocusable(false);
        name.setEditable(false); name.setFocusable(false);

        
        top.add(connectBtn);
        top.add(status);
        top.add(userCount);

        add(top, BorderLayout.NORTH);

        chat.setEditable(false);
        add(new JScrollPane(chat), BorderLayout.CENTER);

        JPanel south = new JPanel(new BorderLayout(6,6));
        south.add(input, BorderLayout.CENTER);
        south.add(sendBtn, BorderLayout.EAST);
        add(south, BorderLayout.SOUTH);

        connectBtn.addActionListener(e -> reconnect());
        sendBtn.addActionListener(e -> send());
        input.addActionListener(e -> send());


        
        new javax.swing.Timer(100, e -> {
            connectBtn.doClick();
            ((javax.swing.Timer)e.getSource()).stop();
        }).start();


    }
    
    @Override public void close() { closeQuietly(); }
    
    @Override public void removeNotify() {
        // EDT를 막지 않도록 백그라운드에서 정리
        if (closing.compareAndSet(false, true)) {
            new Thread(() -> {
                try { shutdown(); } finally { /* keep closing=true */ }
            }, "ClientCleanup").start();
        }
        super.removeNotify();
    }

    

    private void reconnect() {
        closeQuietly();
        try {
            int p = Integer.parseInt(port.getText().trim());
            connect(host.getText().trim(), p, name.getText().trim());
        } catch (Exception ex) {
            append("SYS: 연결 실패 - " + ex.getMessage());
            setStatus(false);
        }
    }
/*
    private void awaitReaderStop(long timeoutMs) {
        Thread t = readerThread;
        if (t != null && t != Thread.currentThread()) {
            try { t.join(timeoutMs); } catch (InterruptedException ignore) {}
        }
    }
*/
    
    public void connect(String h, int p, String nick) {
        if (!running.compareAndSet(false, true)) return;

        connectBtn.setEnabled(false);

        new Thread(() -> {
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(h, p), 3000); // 3초 타임아웃
                s.setSoTimeout(0); // 블록 읽기
                socket = s;

                in  = NetworkHelper.getReader(socket);
                out = NetworkHelper.getWriter(socket);

                SwingUtilities.invokeLater(() -> {
                    setStatus(true);
                    append("시스템 : 서버에 연결되었습니다.");
                });

                readerThread = new Thread(this::readLoop, "Client-Reader");
                readerThread.setDaemon(true);
                readerThread.start();

            } catch (IOException ex) {
                running.set(false);
                SwingUtilities.invokeLater(() -> {
                    setStatus(false);
                    append("시스템 : 연결 실패: " + ex.getMessage());
                    connectBtn.setEnabled(true);
                });
            }
        }, "Client-Connector").start();
    }


    private void readLoop() {
        try {
            String line;
            while (running.get() && (line = in.readLine()) != null) {
                if (line.startsWith("SYS USERS")) {
                    String n = line.replaceFirst("^SYS USERS\\s+", "").trim();
                    SwingUtilities.invokeLater(() -> userCount.setText("접속자: " + n));
                } else {
                    append(line);
                }
            }
        } catch (IOException ignore) {
        } finally {
            setStatus(false);
            append("시스 : 연결 종료됨");
            closeQuietly();
            SwingUtilities.invokeLater(() -> connectBtn.setEnabled(true));
        }
    }

    
    private void send() {
        String txt = input.getText().trim();
        if (txt.isEmpty()) return;
        if (out == null || !running.get()) {
            append("SYS: not connected");
            return;
        }
        try {
            String nick = name.getText().trim();
            NetworkHelper.sendLine(out, (nick.isEmpty() ? "User" : nick) + " : " + txt);
            input.setText("");
        } catch (IOException e) {
            append("SYS: send fail - " + e.getMessage());
            setStatus(false);
            closeQuietly();
        }
    }

    private void append(String s) {
        SwingUtilities.invokeLater(() -> {
            chat.append(s + "\n");
            chat.setCaretPosition(chat.getDocument().getLength());
        });
    }

    private void setStatus(boolean ok) {
        SwingUtilities.invokeLater(() -> status.setText(ok ? "🟢 연결됨" : "🔴 미연결"));
    }




 
    private void closeQuietly() {
   
    	
        running.set(false);
        try { if (socket != null) socket.setSoLinger(true, 0); } catch (Exception ignore) {}
        try { if (readerThread != null) readerThread.interrupt(); } catch (Exception ignore) {}
        NetworkHelper.closeQuiet(in);
        NetworkHelper.closeQuiet(out);
        NetworkHelper.closeQuiet(socket);

        in = null; out = null; socket = null;
        
        
    }

    private void sendByeQuiet() {
        try {
            if (out != null && running.get()) {
                String nick = name.getText().trim(); if (nick.isEmpty()) nick = "User";
                NetworkHelper.sendLine(out, "Bye " + nick + "님");
            }
        } catch (IOException ignore) {}
    }

    public void shutdown() {  // 창 닫힐 때 호출용
        try {  
        	
        
        	 sendByeQuiet(); 	
        	
        	closeQuietly(); 
        	
        
        } catch (Exception ignore) {}
    }
    
 
}
