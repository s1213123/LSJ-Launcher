package v7.Dimensions.Network_Frame;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;

import v7.Config.Registry;



public class Clientold extends JPanel {

    private JTextField nicknameField, messageField;
    private JTextPane messagePane;
    private JLabel statusLabel;

    private Socket socket;
    private BufferedReader in;
    private BufferedWriter out;
    private Thread readerThread;
    
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicBoolean iconSet = new AtomicBoolean(false);

    public Clientold() {
        setLayout(new BorderLayout());

        // 프레임에 실제로 붙었을 때 아이콘 1회 설정
        JPanel panel = this;
        addHierarchyListener(new HierarchyListener() {
            @Override public void hierarchyChanged(HierarchyEvent e) {
                if ((e.getChangeFlags() & HierarchyEvent.DISPLAYABILITY_CHANGED) != 0 && isDisplayable()) {
                    SwingUtilities.invokeLater(() ->
                        NetworkHelper.installWindowIconOnce(panel, iconSet, "/images/apple_green.png")
                    );
                }
            }
        });

        // 상단
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        nicknameField = new JTextField(Registry.username, 12);
        statusLabel = new JLabel("🔴 미연결");
        topPanel.add(new JLabel("닉네임:"));
        topPanel.add(nicknameField);
        topPanel.add(statusLabel);
        add(topPanel, BorderLayout.NORTH);

        // 메시지
        messagePane = new JTextPane();
        messagePane.setEditable(false);
        add(new JScrollPane(messagePane), BorderLayout.CENTER);

        // 하단
        JPanel bottomPanel = new JPanel(new BorderLayout());
        messageField = new JTextField();
        JButton sendBtn = new JButton("전송");
        bottomPanel.add(messageField, BorderLayout.CENTER);
        bottomPanel.add(sendBtn, BorderLayout.EAST);
        add(bottomPanel, BorderLayout.SOUTH);

        // 이벤트
        sendBtn.addActionListener(e -> sendMessage());
        messageField.addActionListener(e -> sendMessage());

        // 패널이 사라질 때 정리
        NetworkHelper.onDispose(this, this::closeQuietly);

        // 연결 시도
        new Thread(this::connect, "LSJ-Client-Connect").start();
    }

    private void connect() {
        // 중복 연결 방지
        if (!running.compareAndSet(false, true)) return;

        try {
            socket = new Socket(Registry.ip, Registry.port);
            in = NetworkHelper.getReader(socket);
            out = NetworkHelper.getWriter(socket);

            setStatus(true);
            appendMessage("시스템", ": 서버에 연결되었습니다.");

            // 수신 스레드
            readerThread = new Thread(() -> {
                try {
                    String line;
                    while (running.get() && (line = in.readLine()) != null) {
                        appendMessage("", line);
                    }
                } catch (IOException ignore) {
                    // 연결 종료/에러 시 조용히 종료
                } finally {
                    setStatus(false);
                    appendMessage("시스템", ": 연결 종료됨");
                    closeQuietly();                    // ★ 자원 정리(중복 호출 안전)
                }
            }, "LSJ-Client-Reader");
            readerThread.setDaemon(true);
            readerThread.start();

        } catch (IOException e) {
            setStatus(false);
            appendMessage("시스템", ": 연결 실패: " + e.getMessage());
            running.set(false);
            closeQuietly();
        }
    }

    private void sendMessage() {
        if (out == null || !running.get()) {
            appendMessage("시스템", ": 아직 연결되지 않았습니다.");
            return;
        }

        String nick = nicknameField.getText() != null ? nicknameField.getText().trim() : "";
        String msg = messageField.getText() != null ? messageField.getText().trim() : "";
        if (msg.isEmpty()) return;

        try {
            // 서버 쪽은 받은 라인을 그대로 브로드캐스트하므로, 현재 포맷 유지
            NetworkHelper.sendLine(out, nick + " : " + msg);
            // 로컬 에코는 서버에서 다시 돌아오므로 생략
            messageField.setText("");
        } catch (IOException e) {
            appendMessage("시스템", ": 전송 실패: " + e.getMessage());
            setStatus(false);          // ★ 상태 내림
            closeQuietly();            // ★ 자원 정리 (다음 연결 시 깔끔)
        }
    }
    private void appendMessage(String sender, String message) {
        SwingUtilities.invokeLater(() -> {
            try {
                messagePane.getDocument().insertString(
                    messagePane.getDocument().getLength(),
                    sender + message + "\n", null
                );
                messagePane.setCaretPosition(messagePane.getDocument().getLength());
            } catch (Exception ex) {
            	 appendMessage("시스템", ": 전송 실패: " + ex.getMessage());
                // 필요하면 로그
            }
        });
    }


    private void setStatus(boolean connected) {
        SwingUtilities.invokeLater(() -> statusLabel.setText(connected ? "🟢 연결됨" : "🔴 미연결"));
    }

    private void closeQuietly() {
        running.set(false);
        try { if (readerThread != null) readerThread.interrupt(); } catch (Exception ignore) {}
        NetworkHelper.closeQuiet(in);
        NetworkHelper.closeQuiet(out);
        NetworkHelper.closeQuiet(socket);
        in = null; out = null; socket = null;
    }
}

/*
public class Client extends JPanel {

    private JTextField nicknameField, messageField;
    private JTextPane messagePane;
    private JLabel statusLabel;
    private Socket socket;
    private BufferedWriter out;


private final AtomicBoolean iconSet = new AtomicBoolean(false);

    
    public Client() {
        setLayout(new BorderLayout());

       // 프레임에 실제로 붙었을 때 아이콘 1회 설정
		
		JPanel panel = this; // this가 JPanel일 경우
		
		addHierarchyListener(new HierarchyListener() {
		    @Override public void hierarchyChanged(HierarchyEvent e) {
		        if ((e.getChangeFlags() & HierarchyEvent.DISPLAYABILITY_CHANGED) != 0 && isDisplayable()) {
		            SwingUtilities.invokeLater(() ->
		                NetworkHelper.installWindowIconOnce(panel, iconSet, "/images/apple_green.png")
		            );
		        }
		    }
		});

       
      
        
        // 상단
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        
        
        nicknameField = new JTextField(Registry.username, 12);
        statusLabel = new JLabel("🔴 미연결");
        topPanel.add(new JLabel("닉네임:"));
        topPanel.add(nicknameField);
        topPanel.add(statusLabel);
        add(topPanel, BorderLayout.NORTH);

        // 메시지
        messagePane = new JTextPane();
        messagePane.setEditable(false);
        add(new JScrollPane(messagePane), BorderLayout.CENTER);

        // 하단
        JPanel bottomPanel = new JPanel(new BorderLayout());
        messageField = new JTextField();
        JButton sendBtn = new JButton("전송");
        bottomPanel.add(messageField, BorderLayout.CENTER);
        bottomPanel.add(sendBtn, BorderLayout.EAST);
        add(bottomPanel, BorderLayout.SOUTH);

        // 이벤트
        sendBtn.addActionListener(e -> sendMessage());
        messageField.addActionListener(e -> sendMessage());

        // 연결 시도
        new Thread(this::connect).start();
    }

    private void connect() {
        try {
            socket = new Socket(Registry.ip, Registry.port);
            out = NetworkHelper.getWriter(socket);
            BufferedReader in = NetworkHelper.getReader(socket);

            statusLabel.setText("🟢 연결됨");
            appendMessage("시스템", ": 서버에 연결되었습니다.");

            String line;
            while ((line = in.readLine()) != null) {
                appendMessage("", line);
            }
        } catch (IOException e) {
            statusLabel.setText("🔴 연결 실패");
            appendMessage("시스템", ": 연결 실패: " + e.getMessage());
        }
    }

    private void sendMessage() {
        if (out == null) return;

        String nick = nicknameField.getText().trim();
        String msg = messageField.getText().trim();
        if (!msg.isEmpty()) {
            try {
                NetworkHelper.sendLine(out, nick + " : " + msg);
              //  appendMessage(nick, msg);
                messageField.setText("");
            } catch (IOException e) {
                appendMessage("시스템", ": 전송 실패: " + e.getMessage());
            }
        }
    }

    private void appendMessage(String sender, String message) {
        try {
            messagePane.getDocument().insertString(
                messagePane.getDocument().getLength(),
                sender + message + "\n", null);
            messagePane.setCaretPosition(messagePane.getDocument().getLength());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}*/
