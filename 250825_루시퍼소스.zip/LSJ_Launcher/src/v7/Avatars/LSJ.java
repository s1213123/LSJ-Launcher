package v7.Avatars;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import v7.Config.LSJ_Paths;
import v7.Config.Registry;
import v7.Connect.SwingMenu;

public class LSJ extends JPanel {

    private static final int WIDTH = Registry.LSJ_IMAGE_WIDTH;
    private static final int HEIGHT = Registry.LSJ_IMAGE_HEIGHT;
    private static final String LSJ_IMAGE = "/" + Registry.IMAGE_ICON_LSJ;

    //private static final int Timer_Height = Registry.PORTAL_TIMER_HEIGHT;
    private static final int Speech_Height = 100;

    protected static JLabel speechLabel;
    protected static JLabel imageLabel;
    protected static JLabel inputLabel;

    private JFrame parentFrame;
    private SwingMenu avatarCall;

    public LSJ(JFrame parentFrame) {
        this.parentFrame = parentFrame;
        Registry.globalLSJ = this;
        
        this.avatarCall = new SwingMenu();

        setLayout(null);
        setOpaque(true);

        // 이미지
        imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        imageLabel.setBounds(0, Speech_Height, WIDTH, HEIGHT);
        
        
        
        // Designs의 함수 사용
        ImageIcon icon = LSJ_Paths.loadIcon(LSJ_IMAGE);
        Image scaled = icon.getImage().getScaledInstance(WIDTH, HEIGHT, Image.SCALE_SMOOTH);
        imageLabel.setIcon(new ImageIcon(scaled));
        add(imageLabel);

    /*    // 인풋 및 시계 라벨
        inputLabel = new JLabel();
        inputLabel.setOpaque(true);
        inputLabel.setBackground(Color.WHITE);
        inputLabel.setForeground(Color.BLACK);
        inputLabel.setFont(new Font("맑은 고딕", Font.BOLD, 28));
        inputLabel.setHorizontalAlignment(SwingConstants.CENTER);
        inputLabel.setBounds(0, HEIGHT - Timer_Height - Speech_Height, WIDTH, Timer_Height);
        add(inputLabel);*/

        // 말풍선 라벨
        String[] sampleLines = {
        	    "안녕하세요. 저는 LSJ입니다.",
        	    "개발자 관련 패널입니다.",
        	    "제사 지방 처럼... 영혼은 없지만..",
        	    "혹시 제가 죽으면 제 영혼이 이 패널에 담길 수 있지 않을까요?"
        	};

        // 샘플 라인 출력
        
        int randomIndex = new Random().nextInt(sampleLines.length);
        speechLabel = new JLabel(sampleLines[randomIndex]);
        speechLabel.setOpaque(true);
        speechLabel.setBackground(Color.WHITE);
        speechLabel.setForeground(Color.BLACK);
        speechLabel.setFont(new Font("맑은 고딕", Font.BOLD, 16));
        speechLabel.setHorizontalAlignment(SwingConstants.CENTER);
        speechLabel.setBounds(0, 0, WIDTH, Speech_Height);
        add(speechLabel);

       
        addMouseEvents();
    }
    

    public void addMouseEvents() {
        MouseAdapter dragListener = new MouseAdapter() {
            Point dragOffset;

            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    avatarCall.function(e.getComponent(), e.getX(), e.getY());
                }
                dragOffset = e.getPoint();
            }

            public void mouseDragged(MouseEvent e) {
                if (dragOffset != null && parentFrame != null) {
                    Point loc = parentFrame.getLocation();
                    parentFrame.setLocation(loc.x + e.getX() - dragOffset.x, loc.y + e.getY() - dragOffset.y);
                }
            }
        };

        addMouseListener(dragListener);
        addMouseMotionListener(dragListener);
    }
}

