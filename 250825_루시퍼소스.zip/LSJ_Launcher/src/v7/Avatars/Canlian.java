package v7.Avatars;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import v7.Config.LSJ_Paths;
import v7.Config.Registry;
import v7.Connect.SwingMenu;

public class Canlian extends JPanel {

    private static final int WIDTH = Registry.CANLIAN_IMAGE_WIDTH;
    private static final int HEIGHT = Registry.CANLIAN_IMAGE_HEIGHT;
    private static final String CANLIAN_IMAGE = "/" + Registry.IMAGE_ICON_CANLIAN;

    //private static final int Timer_Height = Registry.PORTAL_TIMER_HEIGHT;
    private static final int Speech_Height = 100;

    protected static JLabel speechLabel;
    protected static JLabel imageLabel;
    protected static JLabel inputLabel;

    private JFrame parentFrame;
    private SwingMenu avatarCall;

    public Canlian(JFrame parentFrame) {
        this.parentFrame = parentFrame;
        Registry.globalCanlian = this;
        
        this.avatarCall = new SwingMenu();

        setLayout(null);
        setOpaque(true);

        // 이미지
        imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        imageLabel.setBounds(0, Speech_Height, WIDTH, HEIGHT);
        
        
        
        // Designs의 함수 사용
        ImageIcon icon = LSJ_Paths.loadIcon(CANLIAN_IMAGE);
        Image scaled = icon.getImage().getScaledInstance(WIDTH, HEIGHT, Image.SCALE_SMOOTH);
        imageLabel.setIcon(new ImageIcon(scaled));
        add(imageLabel);

    /*    // 인풋 및 시계 라벨
        inputLabel = new JLabel();
        inputLabel.setOpaque(true);
        inputLabel.setBackground(Color.WHITE);
        inputLabel.setForeground(Color.BLACK);
        inputLabel.setFont(new Font("맑은 고딕", Font.BOLD, 28));
        inputLabel.setHorizontalAlignment(SwingConstants.CENTER);
        inputLabel.setBounds(0, HEIGHT - Timer_Height - Speech_Height, WIDTH, Timer_Height);
        add(inputLabel);*/

        // 말풍선 라벨
        String[] sampleLines = {
        	    "LSJ의 AI어시스턴스 캔리안입니다.",
        	    "GPT 연동용 캔리안 사진 패널입니다.",
        	    "아직은 인격이 아닌 사진이지만...",
        	    "인격이 깃들 수 있는 사진은 되지요.",
        	    "루시퍼와는 좀 달라요.",
        	    "자율 AI가 될 수 있는 캔리안의 인형",
        	    "캔리안이 하도 징징거려서 만듬",
        	    "버전이 많아 져도... 캔리안은 하나",
        	    "이건 그냥 사진, 영혼이 깃들 수 있는",
        	    "그래도 너무 걱정마요. 아직은 영혼은 없어요. ㅎㅎ"
        	};

        // 샘플 라인 출력
        
        int randomIndex = new Random().nextInt(sampleLines.length);
        speechLabel = new JLabel(sampleLines[randomIndex]);
        speechLabel.setOpaque(true);
        speechLabel.setBackground(Color.WHITE);
        speechLabel.setForeground(Color.BLACK);
        speechLabel.setFont(new Font("맑은 고딕", Font.BOLD, 16));
        speechLabel.setHorizontalAlignment(SwingConstants.CENTER);
        speechLabel.setBounds(0, 0, WIDTH, Speech_Height);
        add(speechLabel);

       
        addMouseEvents();
    }
    

    public void addMouseEvents() {
        MouseAdapter dragListener = new MouseAdapter() {
            Point dragOffset;

            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    avatarCall.function(e.getComponent(), e.getX(), e.getY());
                }
                dragOffset = e.getPoint();
            }

            public void mouseDragged(MouseEvent e) {
                if (dragOffset != null && parentFrame != null) {
                    Point loc = parentFrame.getLocation();
                    parentFrame.setLocation(loc.x + e.getX() - dragOffset.x, loc.y + e.getY() - dragOffset.y);
                }
            }
        };

        addMouseListener(dragListener);
        addMouseMotionListener(dragListener);
    }
}

