package v7;

import java.awt.Toolkit;
// WindowAdapter, WindowEvent
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import v7.Avatars.Canlian;
import v7.Avatars.Lucifer_Core;
import v7.Avatars.Portal;
import v7.Config.Designs;
import v7.Config.Registry;

public class LSJ_Starter extends JFrame {

    private String mode;

    public LSJ_Starter() {
        this.mode = Registry.START_MODE;
        init();
    }

    public LSJ_Starter(String overrideMode){
        this.mode = overrideMode;
        init();
    }

    private void init() {
        setTitle("LSJ Launcher");
  
        try {
            java.net.URL u = getClass().getResource("/images/apple.jpg");
            if (u != null) setIconImage(Toolkit.getDefaultToolkit().getImage(u));
        } catch (Exception ignore) {}

        

        // 설정 초기화
        Registry.initPaths();
        Registry.make_Registry_ini(false);
        Registry.make_Menu_ini(false);
        Registry.make_Scale_ini(false);
        Registry.make_Speech_JSON(false);
        
        setSize(Registry.FRAME_WIDTH, Registry.FRAME_HEIGHT);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // scale.ini에서 락 설정 로드
        Registry.loadScaleIniForLock();

        // 프로세스 단일 인스턴스 락
        String lockName = "lsj-" + mode + ".lock";
        try {
            if (!Registry.tryProcessFileLock(lockName)) {
                Designs.showMessage(this, "중복 호출 설정", mode + "중복 호출 금지 모드가 실행 중입니다: ");
                dispose();
                return;
            }
        } catch (Exception ex) {
            // 락 획득 실패 시 정책에 따라 진행/중단 선택 (여기선 경고 후 계속)
            System.err.println("process lock error: " + ex.getMessage());
        }


        JPanel panel;
        switch (mode) {
            case "portal":   panel = new Portal(this);   break;

            case "lucifer_red": panel = new Lucifer_Core(this, mode); break;
            case "lucifer_white": panel = new Lucifer_Core(this, mode); break;
            case "lucifer":  panel = new Lucifer_Core(this, mode); break;
           
            case "canlian":  panel = new Canlian(this);  break;
            default:         panel = new Portal(this);   break;
        }
        getContentPane().add(panel);

        // 창 닫힐 때 락 해제
        final String lockKeyFinal = lockName;
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosed(WindowEvent e) {
                Registry.releaseProcessFileLock(lockKeyFinal);
            }
            @Override public void windowClosing(WindowEvent e) {
                Registry.releaseProcessFileLock(lockKeyFinal);
            }
        });

      /*  
        for (Frame f : Frame.getFrames()) {
            System.out.println("[FRAME] title=" + f.getTitle() + " size=" + f.getWidth() + "x" + f.getHeight()
                + " visible=" + f.isVisible() + " class=" + f.getClass().getName());
        }
*/
        
        Designs.Transparent_Frame(this);
        Designs.registerTray(this);
    }

    public static void main(String[] args) {
        System.setProperty("sun.java2d.uiScale", String.valueOf(Registry.uiScale));
        SwingUtilities.invokeLater(() -> {
            LSJ_Starter app = new LSJ_Starter();  // init() 안에서 락 실패 시 dispose() 됨
            if (app.isDisplayable()) {            // ★ 이미 dispose 되었으면 false → 보이지 않음
                app.setVisible(true);
            }
        });
        		
    }
}
