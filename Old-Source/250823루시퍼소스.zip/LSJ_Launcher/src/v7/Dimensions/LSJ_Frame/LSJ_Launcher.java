package v7.Dimensions.LSJ_Frame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.Window;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import v7.Config.Designs;
import v7.Config.LSJ_Paths;
import v7.Config.Registry;

public class LSJ_Launcher extends JPanel {
    private static final String MENU_PATH = Registry.BASE_PATH + "/menu.ini";
    private static final String APP_PATH = Registry.APP_PATH;

 // imports 필요: java.awt.image.BufferedImage, java.awt.Graphics2D, javax.swing.JSplitPane
    private ImageDropPanel imagePanel;

    /*
    private static int Width = 350;
    private static int Height = 200;
*/
    
    private final DefaultListModel<String> pluginListModel = new DefaultListModel<>();
    private final JList<String> pluginList = new JList<>(pluginListModel);
    private final JTextField searchField = new JTextField();

    public LSJ_Launcher() {
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(600, 600));
        reloadMenu("");

        JLabel topBanner = new JLabel("LSJ Launcher v3.0 with Canlian (www.dgmayor.com)", SwingConstants.CENTER);
        topBanner.setFont(Designs.MIDDLE_FONT);
        topBanner.setOpaque(true);
        topBanner.setBackground(new Color(180, 220, 250));
        topBanner.setPreferredSize(new Dimension(600, 40));
        add(topBanner, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout());
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBorder(null);

       /* JPanel imageDropPanel = new JPanel(new BorderLayout());
        imageDropPanel.setPreferredSize(new Dimension(300, 400));
        imageDropPanel.setBackground(Color.WHITE);

        JLabel imageLabel = new JLabel();
        ImageIcon icon = LSJ_Paths.loadIcon("/" + Registry.IMAGE_ICON_PORTAL);
        Image img = icon.getImage().getScaledInstance(Width, Height, Image.SCALE_SMOOTH);
        imageLabel.setIcon(new ImageIcon(img));
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        imageLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        imageDropPanel.add(imageLabel, BorderLayout.CENTER);

        JLabel dropLabel = new JLabel("여기에 파일을 드래그하여 등록", SwingConstants.CENTER);
        dropLabel.setFont(Designs.BIG_FONT);
        dropLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        imageDropPanel.add(dropLabel, BorderLayout.SOUTH);*/

        JPanel imageDropPanel = new JPanel(new BorderLayout());
        imageDropPanel.setPreferredSize(new Dimension(300, 400));
        imageDropPanel.setBackground(Color.WHITE);

        // 1) 커스텀 드롭/뷰 패널 사용
        imagePanel = new ImageDropPanel();
        imageDropPanel.add(imagePanel, BorderLayout.CENTER);

        // 2) 기본 포털 아이콘을 BufferedImage로 변환해서 세팅
        try {
            ImageIcon icon = LSJ_Paths.loadIcon("/" + Registry.IMAGE_ICON_PORTAL);
            BufferedImage bi = new BufferedImage(icon.getIconWidth(), icon.getIconHeight(), BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2 = bi.createGraphics();
            icon.paintIcon(null, g2, 0, 0);
            g2.dispose();
            imagePanel.setImage(bi);
        } catch (Exception ignore) {}

        // 3) 드롭 안내 라벨은 그대로 유지 (원하면 제거 가능)
        
        JLabel dropLabel = new JLabel(
        	    "<html>"
        	  + "<div style='text-align:center;'>"
        	  + "여기에 파일을 드래그하여 등록"
        	/*  + "<div style='margin-top:6px; font-weight:bold;'>루시퍼 사용 방법</div>"
        	  + "<ul style='margin:4px 0; padding-left:22px; text-align:left;'>"
        	  + "  <li>우측 상단 영역에 파일 드래그</li>"
        	  + "  <li>menu.ini에 자동 추가</li>"
        	  + "</ul>"
        */
        	  + "</div>"
        	  + "</html>",
        	  SwingConstants.CENTER
        	);
        	dropLabel.setFont(Designs.BIG_FONT);
        	dropLabel.setBorder(BorderFactory.createEmptyBorder(8, 10, 10, 10));
        	dropLabel.setOpaque(true);
        	dropLabel.setBackground(new Color(245, 245, 245));
        	// 남는 공간이 너무 작아 잘리면 높이 지정
        	dropLabel.setPreferredSize(new Dimension(0, 100)); // 폭은 레이아웃에 맡기고, 높이만 고정
        	imageDropPanel.add(dropLabel, BorderLayout.SOUTH);


        

        
        /*
        new DropTarget(imageDropPanel, new DropTargetAdapter() {
            public void drop(DropTargetDropEvent dtde) {
                try {
                    dtde.acceptDrop(DnDConstants.ACTION_COPY);
                    List<File> droppedFiles = (List<File>) dtde.getTransferable().getTransferData(DataFlavor.javaFileListFlavor);
                    for (File file : droppedFiles) {
                        String name = file.getName();
                        String path = APP_PATH + name;
                        if (!pluginListModel.contains(name)) {
                            Files.copy(file.toPath(), Paths.get(path), StandardCopyOption.REPLACE_EXISTING);
                            String fullPath = new File(path).getAbsolutePath().replace("\\", "/");
                            String entry = "@" + name + ", Earth_Frame, open:" + fullPath;
                            appendToMenuFile(entry);
                            reloadMenu("");
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });*/

        imagePanel.onFilesDropped = new java.util.function.Consumer<List<File>>() {
            @Override
            public void accept(List<File> droppedFiles) {
                for (File file : droppedFiles) {
                    try {
                        if (file.isDirectory()) continue; // 폴더 드롭 무시(원하면 처리 로직 추가)
                        String name = file.getName();

                        // 경로 안전 결합 (APP_PATH 끝에 슬래시 없어도 OK)
                        Path dest = Paths.get(APP_PATH, name);

                        // 이미 리스트에 있으면 중복 추가 안 함
                        if (pluginListModel.contains(name)) continue;

                        Files.copy(file.toPath(), dest, StandardCopyOption.REPLACE_EXISTING);

                        String fullPath = dest.toFile().getAbsolutePath().replace("\\", "//");
                        String entry = "@" + name + ", Earth_Frame, open:" + fullPath;

                        appendToMenuFile(entry);
                        reloadMenu("");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        Designs.showMessage(LSJ_Launcher.this, "등록 실패", "파일 등록 중 오류가 발생했습니다: " + ex.getMessage());
                    }
                }
            }
        };

        
        rightPanel.add(imageDropPanel, BorderLayout.CENTER);
/*
        JTextArea helpArea = new JTextArea("루시퍼 사용 방법:\n- 우측 상단 영역에 파일 드래그\n- menu.ini에 자동 추가\n- 리스트 더블 클릭으로 실행\n- 하단에서 검색/삭제/종료 가능");
        helpArea.setEditable(false);
        helpArea.setBackground(new Color(240, 240, 240));
        helpArea.setFont(Designs.MIDDLE_FONT);
        rightPanel.add(new JScrollPane(helpArea), BorderLayout.CENTER);
*/
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setPreferredSize(new Dimension(250, 0));
        leftPanel.setBorder(null);

        pluginList.setFont(Designs.PLUGIN_FONT);
        pluginList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane scrollPane = new JScrollPane(pluginList);
        leftPanel.add(scrollPane, BorderLayout.CENTER);

        pluginList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    String selected = pluginList.getSelectedValue();
                    if (selected != null) {
                        File file = new File(APP_PATH + selected);
                        if (!file.exists()) {
                            Designs.showMessage(LSJ_Launcher.this, "실행 실패", "파일이 존재하지 않습니다");
                            pluginListModel.removeElement(selected);
                            return;
                        }
                        try {
                            /*if (file.getName().toLowerCase().endsWith(".lnk")) {
                                Runtime.getRuntime().exec("cmd /c start \"\" \"" + file.getAbsolutePath() + "\"");
                         */
                        	if (file.getName().toLowerCase().endsWith(".lnk")) {
                        	    // explorer.exe로 실행하여 Windows 기본 바로가기 해석 처리
                        	    Runtime.getRuntime().exec(new String[]{"cmd", "/c", "explorer \"" + file.getAbsolutePath() + "\""});
                        	   
                            
                            
                            } else {
                                Desktop.getDesktop().open(file);
                            }
                            SwingUtilities.getWindowAncestor(pluginList).dispose();
                        } catch (IOException ex) {
                            Designs.showMessage(SwingUtilities.getWindowAncestor(pluginList), "실행 실패", "파일 실행 오류 발생");
                        }
                    }
                }
            }
        });

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
        split.setResizeWeight(0.7);      // 초기 비율 (좌측 30%)
        split.setContinuousLayout(true);
        split.setDividerSize(2);

        add(split, BorderLayout.CENTER);


        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));

        JButton searchButton = new JButton("검색");
        JButton deleteBtn = new JButton("프로그램 삭제");
        JButton openMenuBtn = new JButton("menu.ini 열기");
        JButton exitBtn = new JButton("종료");

        for (JButton btn : new JButton[]{searchButton, deleteBtn, openMenuBtn, exitBtn}) {
            btn.setFont(Designs.BIG_FONT);
        }

        searchField.setPreferredSize(new Dimension(100, 30));
        bottomPanel.add(openMenuBtn);
        bottomPanel.add(deleteBtn);
        bottomPanel.add(exitBtn);
        bottomPanel.add(searchField);
        bottomPanel.add(searchButton);
        add(bottomPanel, BorderLayout.SOUTH);

        openMenuBtn.addActionListener(ev -> Designs.showTextEditor(this, new File(MENU_PATH)));

        searchButton.addActionListener(e -> reloadMenu(searchField.getText().toLowerCase()));

        deleteBtn.addActionListener(e -> {
            List<String> selectedItems = pluginList.getSelectedValuesList();
            if (!selectedItems.isEmpty()) {
                String pw = Designs.showInputDialog(this, "삭제 인증", "비밀번호 (ghost)를 입력하세요:");
                if ("ghost".equals(pw)) {
                    try {
                        List<String> lines = Files.readAllLines(Paths.get(MENU_PATH), Charset.forName("UTF-8"));
                        List<String> updated = lines.stream()
                            .filter(line -> selectedItems.stream().noneMatch(line::contains))
                            .collect(Collectors.toList());
                        Files.write(Paths.get(MENU_PATH), updated);
                        for (String selected : selectedItems) {
                            Path filePath = Paths.get(APP_PATH + selected);
                            if (Files.exists(filePath)) {
                               // Desktop.getDesktop().moveToTrash(filePath.toFile());
                            	Files.deleteIfExists(filePath);

                            }
                        }
                        reloadMenu("");
                    } catch (IOException ex) {
                        Designs.showMessage(this, "삭제 실패", "파일 삭제 중 오류 발생");
                    }
                } else if (pw != null) {
                    Designs.showMessage(this, "실패", "비밀번호가 틀렸습니다.");
                }
            }
        });

        exitBtn.addActionListener(e -> {
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) window.dispose();
        });
    }

    private void appendToMenuFile(String line) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(MENU_PATH, true))) {
            writer.write(line);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void reloadMenu(String query) {
        pluginListModel.clear();
        try {
            List<String> lines = Files.readAllLines(Paths.get(MENU_PATH));
            for (String line : lines) {
                if (line.startsWith("@")) {
                    String[] parts = line.substring(1).split(",");
                    if (parts.length >= 3) {
                        String name = parts[0].toLowerCase();
                        String action = parts[2].toLowerCase();
                        if (query.isEmpty() || name.contains(query) || action.contains(query)) {
                            pluginListModel.addElement(parts[0]);
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
