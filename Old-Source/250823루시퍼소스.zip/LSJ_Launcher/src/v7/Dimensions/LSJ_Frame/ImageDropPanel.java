package v7.Dimensions.LSJ_Frame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DnDConstants;
import java.awt.datatransfer.DataFlavor;
import java.awt.Image;
import java.awt.FontMetrics;

class ImageDropPanel extends JPanel {
    private BufferedImage sourceImg;
    private Image scaledImg; // 리사이즈 캐시
    private String hintText = "여기에 파일을 드래그하여 등록";

    ImageDropPanel() {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // 드래그앤드롭
        new DropTarget(this, new DropTargetAdapter() {
            @Override
            public void drop(DropTargetDropEvent dtde) {
                try {
                    dtde.acceptDrop(DnDConstants.ACTION_COPY);
                    @SuppressWarnings("unchecked")
                    List<File> files = (List<File>) dtde.getTransferable()
                            .getTransferData(DataFlavor.javaFileListFlavor);
                    if (onFilesDropped != null) onFilesDropped.accept(files);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        // 리사이즈 시 캐시 무효화
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                scaledImg = null;
                repaint();
            }
        });
    }

    Consumer<List<File>> onFilesDropped; // 외부에서 등록 로직 연결

    void setImage(BufferedImage img) {
        this.sourceImg = img;
        this.scaledImg = null;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();

        // 렌더링 품질
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int padding = 10;
        int labelSpace = 40; // 하단 안내문 여백
        int w = Math.max(1, getWidth() - padding * 2);
        int h = Math.max(1, getHeight() - padding * 2 - labelSpace);
        int x = padding;
        int y = padding;

        if (sourceImg != null) {
            // 필요할 때만 스케일 생성
            if (scaledImg == null) {
                double sx = (double) w / sourceImg.getWidth();
                double sy = (double) h / sourceImg.getHeight();
                double s = Math.min(sx, sy);

                int dw = Math.max(1, (int) Math.round(sourceImg.getWidth() * s));
                int dh = Math.max(1, (int) Math.round(sourceImg.getHeight() * s));

                BufferedImage tmp = new BufferedImage(dw, dh, BufferedImage.TYPE_INT_ARGB);
                Graphics2D gImg = tmp.createGraphics();
                gImg.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                gImg.drawImage(sourceImg, 0, 0, dw, dh, null);
                gImg.dispose();
                scaledImg = tmp;
            }
            int dx = x + (w - scaledImg.getWidth(null)) / 2;
            int dy = y + (h - scaledImg.getHeight(null)) / 2;
            g2.drawImage(scaledImg, dx, dy, null);
        } else {
            // 기본 안내문
            String text = hintText;
            FontMetrics fm = g2.getFontMetrics(g2.getFont().deriveFont(16f));
            g2.setFont(g2.getFont().deriveFont(16f));
            int tw = fm.stringWidth(text);
            g2.setColor(new Color(120, 120, 120));
            g2.drawString(text, x + (w - tw) / 2, y + h / 2);
        }

        g2.dispose();
    }
}
