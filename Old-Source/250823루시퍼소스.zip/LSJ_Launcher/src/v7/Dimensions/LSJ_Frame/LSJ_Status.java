package v7.Dimensions.LSJ_Frame;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.net.InetAddress;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Timer;
import java.util.TimerTask;

import v7.Config.Designs;

public class LSJ_Status extends JPanel {

    private JLabel cpuLabel, memoryLabel, timeLabel, localIpLabel, externalIpLabel, osInfoLabel, diskLabel;

    public LSJ_Status() {
        setLayout(null);
         setPreferredSize(new Dimension(800, 500)); // 외부 프레임에서 크기 제어
        setBackground(Color.decode("#1e354d")); // 유지됨

        cpuLabel = createLabel("CPU 사용률: ", 20);
        memoryLabel = createLabel("메모리 사용량: ", 60);
        timeLabel = createLabel("현재 시간: ", 100);
        localIpLabel = createLabel("로컬 IP: ", 140);
        externalIpLabel = createLabel("외부 IP: 불러오는 중...", 180);
        osInfoLabel = createLabel("운영체제 정보: ", 220);
        diskLabel = createLabel("디스크 사용량: ", 260);

        add(cpuLabel);
        add(memoryLabel);
        add(timeLabel);
        add(localIpLabel);
        add(externalIpLabel);
        add(osInfoLabel);
        add(diskLabel);

        // 종료 예약 버튼 (하단 단독 배치)
        JButton shutdownBtn = createButton("종료 예약", e -> reserveShutdown());
        shutdownBtn.setBounds(30, 320, 300, 45);
        add(shutdownBtn);

        // 닫기 버튼 (하단 그 아래 배치)
        JButton closeBtn = createButton("닫기", e -> SwingUtilities.getWindowAncestor(this).dispose());
        closeBtn.setBounds(30, 380, 300, 45);
        add(closeBtn);

        updateAll();
        startAutoRefresh();
        fetchExternalIP();
    }

    private JLabel createLabel(String text, int y) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("맑은 고딕", Font.BOLD, 26));
        label.setBounds(30, y, 740, 30);
        return label;
    }

    private JButton createButton(String text, java.awt.event.ActionListener action) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("맑은 고딕", Font.BOLD, 20));
        btn.setFocusPainted(false);
        btn.setBackground(Color.decode("#2c3e50"));
        btn.setForeground(Color.WHITE);
        btn.setBorderPainted(false);
        btn.addActionListener(action);
        return btn;
    }

    private void updateAll() {
        try {
            OperatingSystemMXBean osBean = ManagementFactory.getOperatingSystemMXBean();
            double cpuLoad = getProcessCpuLoad(osBean);
            cpuLabel.setText("CPU 사용률: " + String.format("%.1f", cpuLoad * 100) + " %");

            long used = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
            long total = Runtime.getRuntime().totalMemory();
            memoryLabel.setText("메모리 사용량: " + (used / 1024 / 1024) + "MB / " + (total / 1024 / 1024) + "MB");

            timeLabel.setText("현재 시간: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
            localIpLabel.setText("로컬 IP: " + InetAddress.getLocalHost().getHostAddress());

            String osInfo = System.getProperty("os.name") + " / " + System.getProperty("os.arch");
            osInfoLabel.setText("운영체제 정보: " + osInfo);

            File root = new File("C:\\");
            long free = root.getFreeSpace() / (1024 * 1024 * 1024);
            long totalDisk = root.getTotalSpace() / (1024 * 1024 * 1024);
            diskLabel.setText("디스크 사용량: " + (totalDisk - free) + "GB / " + totalDisk + "GB");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void startAutoRefresh() {
        Timer timer = new Timer(true);
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                SwingUtilities.invokeLater(() -> updateAll());
            }
        }, 0, 2000);
    }

    private void fetchExternalIP() {
        new Thread(() -> {
            try {
                URL url = new URL("https://api.ipify.org");
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                String ip = in.readLine();
                SwingUtilities.invokeLater(() -> externalIpLabel.setText("외부 IP: " + ip));
            } catch (Exception e) {
                SwingUtilities.invokeLater(() -> externalIpLabel.setText("외부 IP: 불러오기 실패"));
            }
        }).start();
    }

    private double getProcessCpuLoad(OperatingSystemMXBean osBean) {
        try {
            java.lang.reflect.Method method = osBean.getClass().getMethod("getSystemCpuLoad");
            method.setAccessible(true);
            Object value = method.invoke(osBean);
            if (value instanceof Double) return (Double) value;
        } catch (Exception ignored) {}
        return 0.0;
    }

    private void reserveShutdown() {
        try {
            Window top = SwingUtilities.getWindowAncestor(this);
            String input = Designs.showInputDialog(top, "종료 예약", "몇 분 후 종료할까요? (10~90)");
            if (input != null && !input.trim().isEmpty()) {
                int minutes = Integer.parseInt(input.trim());
                if (minutes < 10 || minutes > 90) {
                    Designs.showMessage(top, "오류", "5~120분 사이로 입력해주세요.");
                    return;
                }
                int seconds = minutes * 60;
                String cmd = "shutdown -s -t " + seconds;
                Runtime.getRuntime().exec(cmd);
                Designs.showMessage(top, "종료 예약", minutes + "분 후 시스템 종료가 예약되었습니다.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            Designs.showMessage(null, "오류", "종료 예약 실패");
        }
    }
}
