package v7.Dimensions.Network_Frame;

import java.awt.BorderLayout;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;

import v7.Config.Registry;

public class Server extends JPanel {
    private JTextPane messagePane;
    private JTextField inputField;
    private final List<String> messageLog = new ArrayList<>();
    private final List<BufferedWriter> clientWriters = new ArrayList<>();

    private ServerSocket serverSocket;
    
    private final AtomicBoolean iconSet = new AtomicBoolean(false);

	
    
    
    public Server() {
        setLayout(new BorderLayout());

 
        JPanel panel = this; // this가 JPanel일 경우

        addHierarchyListener(new HierarchyListener() {
            @Override public void hierarchyChanged(HierarchyEvent e) {
                if ((e.getChangeFlags() & HierarchyEvent.DISPLAYABILITY_CHANGED) != 0 && isDisplayable()) {
                    SwingUtilities.invokeLater(() ->
                        NetworkHelper.installWindowIconOnce(panel, iconSet)
                    );
                }
            }
        });
        
        messagePane = new JTextPane();
        messagePane.setEditable(false);
        add(new JScrollPane(messagePane), BorderLayout.CENTER);

        inputField = new JTextField();
        JButton sendBtn = new JButton("서버 전송");
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.add(inputField, BorderLayout.CENTER);
        bottom.add(sendBtn, BorderLayout.EAST);
        add(bottom, BorderLayout.SOUTH);

        sendBtn.addActionListener(e -> sendFromServer());
        inputField.addActionListener(e -> sendFromServer());

        new Thread(this::startServer).start();
        
        // 창 닫을 때 서버 소켓 종료
        NetworkHelper.attachWindowCloseSocketListener(this, serverSocket);



        
    }

    
    
    
    private void sendFromServer() {
        String msg = inputField.getText().trim();
        if (!msg.isEmpty()) {
            String full = msg;
            messageLog.add(full);
            append("서버 : ", msg);
            broadcast(full);
            inputField.setText("");
        }
    }

    private void broadcast(String msg) {
        for (BufferedWriter writer : clientWriters) {
            try {
                NetworkHelper.sendMessage(writer, msg);
            } catch (IOException e) {
                append("시스템", ": 전송 오류: " + e.getMessage());
            }
        }
    }

    private void append(String sender, String message) {
        try {
            messagePane.getDocument().insertString(
                messagePane.getDocument().getLength(),
                sender + message + "\n", null);
            messagePane.setCaretPosition(messagePane.getDocument().getLength());
        } catch (Exception ex) {
           // ex.printStackTrace();
        	// 나중 유저 수 늘어나면 추가하면 됨
        	
        }
    }

    private void startServer() {
        try (ServerSocket serverSocket = new ServerSocket(Registry.port)) {
            append("시스템", ": 서버 시작됨 (포트 " + Registry.port + ")");

            while (true) {
                Socket client = serverSocket.accept();
                BufferedWriter out = NetworkHelper.getWriter(client);
                clientWriters.add(out);
/*
                // 로그 전송
                for (String msg : messageLog) {
                    NetworkHelper.sendMessage(out, msg);
                }
*/
                // 메시지 수신 처리
                new Thread(() -> {
                    try (BufferedReader in = NetworkHelper.getReader(client)) {
                        String line;
                        while ((line = in.readLine()) != null) {
                            String full =  line;
                            messageLog.add(full);
                            append("", line);
                            broadcast(full);
                        }
                    } catch (IOException e) {
                        append("시스템", ": 연결 종료됨");
                    }
                }).start();
            }
        } catch (IOException e) {
            append("시스템", ": 서버 오류: " + e.getMessage());
        }
    }
}

