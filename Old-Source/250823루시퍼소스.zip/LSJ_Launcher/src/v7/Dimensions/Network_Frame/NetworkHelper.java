package v7.Dimensions.Network_Frame;

import java.awt.Frame;
import java.awt.Image;
import java.awt.Window;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class NetworkHelper {


    public static void installWindowIconOnce(JPanel panel, AtomicBoolean iconSetFlag) {
        if (iconSetFlag.get()) return;
        Window w = SwingUtilities.getWindowAncestor(panel);
        if (!(w instanceof Frame)) return;

        List<Image> icons = new ArrayList<>();
        URL u16 = panel.getClass().getResource("/images/icon16.png");
        URL u32 = panel.getClass().getResource("/images/icon32.png");
        URL u64 = panel.getClass().getResource("/images/icon64.png");

        if (u16 != null) icons.add(new ImageIcon(u16).getImage());
        if (u32 != null) icons.add(new ImageIcon(u32).getImage());
        if (u64 != null) icons.add(new ImageIcon(u64).getImage());

        if (icons.isEmpty()) {
            URL u = panel.getClass().getResource("/images/apple.jpg");
            if (u != null) icons.add(new ImageIcon(u).getImage());
            else icons.add(new ImageIcon("src/resources/images/apple.jpg").getImage()); // fallback
        }

        ((Frame) w).setIconImages(icons);
        iconSetFlag.set(true);
    }
	
    public static void attachWindowCloseSocketListener(JPanel panel, ServerSocket socket) {
        panel.addHierarchyListener(new HierarchyListener() {
            @Override public void hierarchyChanged(HierarchyEvent e) {
                if ((e.getChangeFlags() & HierarchyEvent.DISPLAYABILITY_CHANGED) != 0 && panel.isDisplayable()) {
                    Window window = SwingUtilities.getWindowAncestor(panel);
                    if (window instanceof JFrame) {
                        ((JFrame) window).addWindowListener(new WindowAdapter() {
                            @Override public void windowClosing(WindowEvent e) {
                                try {
                                    if (socket != null && !socket.isClosed()) {
                                        socket.close();
                                        System.out.println("서버 소켓 정상 종료됨");
                                    }
                                } catch (IOException ex) {
                                    ex.printStackTrace();
                                }
                            }
                        });
                    }
                }
            }
        });
    }

    
	
    public static BufferedWriter getWriter(Socket socket) throws IOException {
        return new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"));
    }

    public static BufferedReader getReader(Socket socket) throws IOException {
        return new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
    }

    public static void sendMessage(BufferedWriter out, String msg) throws IOException {
        out.write(msg);
        out.newLine();
        out.flush();
    }
}
