package v7.Dimensions.Network_Frame;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;

import v7.Config.Registry;

public class Client extends JPanel {

    private JTextField nicknameField, messageField;
    private JTextPane messagePane;
    private JLabel statusLabel;
    private Socket socket;
    private BufferedWriter out;


private final AtomicBoolean iconSet = new AtomicBoolean(false);

    
    public Client() {
        setLayout(new BorderLayout());

       // 프레임에 실제로 붙었을 때 아이콘 1회 설정
		
		JPanel panel = this; // this가 JPanel일 경우
		
		addHierarchyListener(new HierarchyListener() {
		    @Override public void hierarchyChanged(HierarchyEvent e) {
		        if ((e.getChangeFlags() & HierarchyEvent.DISPLAYABILITY_CHANGED) != 0 && isDisplayable()) {
		            SwingUtilities.invokeLater(() ->
		                NetworkHelper.installWindowIconOnce(panel, iconSet)
		            );
		        }
		    }
		});

       
      
        
        // 상단
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        
        
        nicknameField = new JTextField(Registry.username, 12);
        statusLabel = new JLabel("🔴 미연결");
        topPanel.add(new JLabel("닉네임:"));
        topPanel.add(nicknameField);
        topPanel.add(statusLabel);
        add(topPanel, BorderLayout.NORTH);

        // 메시지
        messagePane = new JTextPane();
        messagePane.setEditable(false);
        add(new JScrollPane(messagePane), BorderLayout.CENTER);

        // 하단
        JPanel bottomPanel = new JPanel(new BorderLayout());
        messageField = new JTextField();
        JButton sendBtn = new JButton("전송");
        bottomPanel.add(messageField, BorderLayout.CENTER);
        bottomPanel.add(sendBtn, BorderLayout.EAST);
        add(bottomPanel, BorderLayout.SOUTH);

        // 이벤트
        sendBtn.addActionListener(e -> sendMessage());
        messageField.addActionListener(e -> sendMessage());

        // 연결 시도
        new Thread(this::connect).start();
    }

    private void connect() {
        try {
            socket = new Socket(Registry.ip, Registry.port);
            out = NetworkHelper.getWriter(socket);
            BufferedReader in = NetworkHelper.getReader(socket);

            statusLabel.setText("🟢 연결됨");
            appendMessage("시스템", ": 서버에 연결되었습니다.");

            String line;
            while ((line = in.readLine()) != null) {
                appendMessage("", line);
            }
        } catch (IOException e) {
            statusLabel.setText("🔴 연결 실패");
            appendMessage("시스템", ": 연결 실패: " + e.getMessage());
        }
    }

    private void sendMessage() {
        if (out == null) return;

        String nick = nicknameField.getText().trim();
        String msg = messageField.getText().trim();
        if (!msg.isEmpty()) {
            try {
                NetworkHelper.sendMessage(out, nick + " : " + msg);
              //  appendMessage(nick, msg);
                messageField.setText("");
            } catch (IOException e) {
                appendMessage("시스템", ": 전송 실패: " + e.getMessage());
            }
        }
    }

    private void appendMessage(String sender, String message) {
        try {
            messagePane.getDocument().insertString(
                messagePane.getDocument().getLength(),
                sender + message + "\n", null);
            messagePane.setCaretPosition(messagePane.getDocument().getLength());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
