package v7.Config;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.swing.ImageIcon;


public class LSJ_Paths {

	static String MENU_PATH = Registry.MENU_PATH;    
	static String REGI_PATH = Registry.REGI_PATH;
	static final Properties props = new Properties();
		  
	 
	

    
    // 이미지 아이콘 및 로드 이미지 함수

    public static ImageIcon loadIcon(String jarPath) {
        try {
            // 💡 jar 기준 로딩 시도
            URL url = Registry.class.getResource(jarPath);
            if (url == null) throw new NullPointerException("getResource returned null");
            return new ImageIcon(url);
        } catch (Exception e) {
            // ⚠️ 실패 시 Eclipse 개발 경로 fallback
            String devPath = "src/resources" + jarPath;
            System.err.println("⚠️ getResource 실패, fallback to: " + devPath);
            return new ImageIcon(devPath);
        }
    }

    public static Image loadImage(String jarPath) {
        try {
            // jar 기준 이미지 로드 시도
            URL url = Registry.class.getResource(jarPath);
            if (url == null) throw new NullPointerException("getResource returned null");
            return Toolkit.getDefaultToolkit().getImage(url);
        } catch (Exception e) {
            // Eclipse 개발 경로 fallback
            String devPath = "src/resources" + jarPath;
            System.err.println("⚠️ 트레이 이미지 로드 실패, fallback to: " + devPath);
            return Toolkit.getDefaultToolkit().getImage(devPath);
        }
    }
    
    
	
	 
	    static {
	        try (FileReader reader = new FileReader(REGI_PATH)) {
	            props.load(reader);  // 기존 설정 불러오기
	        } catch (IOException e) {
	            System.err.println("[RegistrySaver] 기존 설정 불러오기 실패: " + e.getMessage());
	        }
	    }

	
	    public static void save() {
	        try (FileWriter writer = new FileWriter(REGI_PATH)) {
	            props.store(writer, "Registry auto-saved by user action");
	        } catch (IOException e) {
	            System.err.println("[RegistrySaver] 저장 실패: " + e.getMessage());
	        }
	    }
	 

	    
	 // LSJ_Paths 직접 파일 저장


	    
// 아래 get 관련 함수
	        
	    
	    @SuppressWarnings("unchecked")
	    public static <T> T get(String key, T defaultVal) {
	        String value = props.getProperty(key);
	        if (value == null) return defaultVal;

	        try {
	            if (defaultVal instanceof Boolean) {
	                return (T) Boolean.valueOf(value);
	            } else if (defaultVal instanceof Integer) {
	                return (T) Integer.valueOf(value);
	            } else if (defaultVal instanceof Double) {
	                return (T) Double.valueOf(value);
	            } else if (defaultVal instanceof String) {
	                return (T) value;
	            }
	        } catch (Exception e) {
	            System.err.println("[RegistryLoader] 변환 실패: " + key + " = " + value);
	        }

	        return defaultVal;
	    }
	    
	    
	   // 다양한 타입 get 
	    public static Color fromHex(String hex, Color fallback) {
	        try {
	            return Color.decode(hex);
	        } catch (Exception e) {
	            return fallback;
	        }
	    }
	   
	    
	    
	    // 공통 2 파서 범용
	    private static int[] parseTwoInts(String text, int[] fallback) {
	        try {
	            String[] parts = text.split(",");
	            if (parts.length < 2) return fallback;
	            return new int[]{ Integer.parseInt(parts[0].trim()), Integer.parseInt(parts[1].trim()) };
	        } catch (Exception e) {
	            return fallback;
	        }
	    }

	    // 특정 함수 종속
	    public static Dimension parseDimension(String text, Dimension fallback) {
	        int[] vals = parseTwoInts(text, new int[]{fallback.width, fallback.height});
	        return new Dimension(vals[0], vals[1]);
	    }

	    public static Point parsePoint(String text, Point fallback) {
	        int[] vals = parseTwoInts(text, new int[]{fallback.x, fallback.y});
	        return new Point(vals[0], vals[1]);
	    }

	   

	    
	    
	    
    // 공통 다항 파서    
    public static class Parser {

    	
    	public List<String[]> loadList(String path) {
    	    List<String[]> list = new ArrayList<>();

    	    try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
    	        String line;
    	        while ((line = reader.readLine()) != null) {
    	            line = line.trim();
    	            if (line.isEmpty() || line.startsWith("//") || line.startsWith("@")) continue;

    	            String[] parts = line.split("[,=]", 3);
    	            if (parts.length == 3) {
    	                list.add(new String[] {
    	                    parts[0].trim(), // name
    	                    parts[1].trim(), // type
    	                    parts[2].trim()  // action
    	                    
    	                });
    	                
    	            }
    	        }
    	    } catch (IOException e) {
    	        System.err.println("❌ 파일 읽기 실패: " + e.getMessage());
    	    }
    	   
    	    return list;
    	}   
    	
    	
    }



    //// 메뉴 DTO
    
    public static class M {


        public String name;
        public String type;
        public String action;

        public M(String name, String type, String action) {
            this.name = name;
            this.type = type;
            this.action = action;
        }
      
        // 메뉴 파싱, 네임, 타입, 액션 순
        
        public static List<M> Menu_Parser() {
            List<M> items = new ArrayList<>();
         
            Parser parser = new Parser();  // 공통 파서 사용

            List<String[]> raw = parser.loadList(MENU_PATH);

            for (String[] entry : raw) {
                if (entry.length == 3) {
                    items.add(new M(entry[0], entry[1], entry[2]));
                }
            }

            return items;
        }
      
    }



}
