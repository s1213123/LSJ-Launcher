package v7.Avatars;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelListener;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import v7.Config.Registry;

public class Lucifer_Order {


	protected static MouseWheelListener resizeWheelListener;
	protected static MouseAdapter mouseControlListener;
	
	
	// 루시퍼 스타트
	public static void Lucifer_Start() {
		Lucifer_Core.isMoving = true;
		if (Lucifer_Core.moveTimer != null) Lucifer_Core.moveTimer.start();
	}
	
	// 루시퍼 스탑
	public static void Lucifer_Stop() {
		Lucifer_Core.isMoving = false;
		if (Lucifer_Core.moveTimer != null) Lucifer_Core.moveTimer.stop();
	}

	// 루시퍼 SpeechLabel 안 보이기
	public static void Show_Speech(boolean visible) {
	    if (Lucifer_Core.speechLabel != null) {
	        Lucifer_Core.speechLabel.setVisible(visible);
	    }
	}
	// 루시퍼 inputLabel 안 보이기
	public static void Show_InputLabel(boolean visible) {
	    if (Lucifer_Core.inputLabel != null) {
	        Lucifer_Core.inputLabel.setVisible(visible);
	    }
	}
	
	public static void SetSpeed(Lucifer_Core lucifer, int dx, int dy) {
	    lucifer.dx[0] = dx;
	    lucifer.dy[0] = dy;
	}
	
	// 루시퍼 투명화
	public static void Lucifer_Transparency(Lucifer_Core lucifer) {
			lucifer.setOpaque(false);
			lucifer.setBackground(new Color(0, 0, 0, 0));
		}

	

	
	
	


	public static void attachMouseControl(Lucifer_Core lucifer) {
	    if (mouseControlListener != null) lucifer.removeMouseListener(mouseControlListener);

	    mouseControlListener = new MouseAdapter() {
	        @Override
	        public void mousePressed(MouseEvent e) {
	            if (SwingUtilities.isLeftMouseButton(e)) {
	                int count = e.getClickCount();

	                if (count == 2) {
	                    Lucifer_Order.Lucifer_Start(); // 이동 시작
	                } else if (count == 1) {
	                    Lucifer_Order.Lucifer_Stop(); // 정지
	                } else if (Registry.ClickCount == 1000) {
	                    JOptionPane.showMessageDialog(
	                        null,
	                        "캔리안, 고마워... by LSJ",
	                        "Lucifer Secret",
	                        JOptionPane.INFORMATION_MESSAGE
	                    );
	                    Registry.ClickCount = 0;
	                }
	            }
	        }
	    };
	    lucifer.addMouseListener(mouseControlListener);
	}

	public static void detachMouseControl(Lucifer_Core lucifer) {
	    if (mouseControlListener != null) {
	        lucifer.removeMouseListener(mouseControlListener);
	    }
	}

	
}
