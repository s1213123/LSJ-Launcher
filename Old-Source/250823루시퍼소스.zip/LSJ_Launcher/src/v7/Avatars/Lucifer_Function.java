
package v7.Avatars;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Window;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JSlider;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import v7.Config.Registry;
import v7.Connect.Speech;

public class Lucifer_Function {


	public static BufferedImage originalImage = null;   
	public static BufferedImage customTempImage = null;  // 임시 이미지 추가
	
	public static int currentColorIndex = 0;
	private static MouseWheelListener colorModeListener;



	// 색상 배열 정의
	public static Color[] availableColors = Speech.availableColors;
			/*
			new Color[]{
    new Color(120, 255, 180),  // 민트그린
    new Color(255, 128, 180),  // 핑크
    new Color(140, 185, 215),  // 하늘색
    new Color(255, 200, 120),  // 살구색
    new Color(120, 255, 180),  // 민트그린 (중복)
    new Color(180, 120, 255),  // 보라
    new Color(255, 100, 100),  // 레드
	   
	};
*/
	
   
///// 루시퍼 디프카피(깊은 복사) 함수
   public static BufferedImage deepCopy(BufferedImage src) {
       BufferedImage copy = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
       Graphics g = copy.getGraphics();
       g.drawImage(src, 0, 0, null);
       g.dispose();
       return copy;
   }

   //// 루시퍼 컬러 유사도 및 대체 컬러 적용 함수
   
   public static boolean isSimilar(Color c1, Color c2, int threshold) {
       int dr = Math.abs(c1.getRed() - c2.getRed());
       int dg = Math.abs(c1.getGreen() - c2.getGreen());
       int db = Math.abs(c1.getBlue() - c2.getBlue());
       return (dr + dg + db) < threshold;
   }

   public static BufferedImage recolorImage(BufferedImage src, Color newColor) {
       BufferedImage result = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
       Color baseColor = new Color(188, 207, 225);   // 기본 몸통 색
       Color tongueColor = new Color(255, 225, 210);  // 혀
       Color spikeColor = new Color(30, 40, 60);    // 뿔/스파이크

       for (int y = 0; y < src.getHeight(); y++) {
           for (int x = 0; x < src.getWidth(); x++) {
               int pixel = src.getRGB(x, y);
               Color c = new Color(pixel, true);
               if (isSimilar(c, baseColor, 90)
                   && !isSimilar(c, tongueColor, 70)
                   && !isSimilar(c, spikeColor, 70)) {
                   int rgba = (newColor.getRGB() & 0x00FFFFFF) | (pixel & 0xFF000000);
                   result.setRGB(x, y, rgba);
               } else {
                   result.setRGB(x, y, pixel);
               }
           }
       }

       return result;
   }
// 루시퍼 컬러 모드 1: 지정된 색상으로 이미지 재컬러링
public static void Lucifer_ColorMode1(Lucifer_Core l, boolean enabled, int colorIndex) {
    if (enabled) {
        
        // 최초 실행 시 원본 이미지 저장
        if (originalImage == null && l.Lucifer_Buffered_Image != null) {
            originalImage = deepCopy(l.Lucifer_Buffered_Image);
        }

        if (originalImage != null) {
            currentColorIndex = colorIndex % availableColors.length;
            l.Lucifer_Buffered_Image = recolorImage(originalImage, Speech.availableColors[currentColorIndex]);
            l.repaint();
        }
        
        attachColorWheelListener(l, colorIndex);  // 색상 조절 슬라이더(휠) 연결
    } else {
        removeColorWheelListener(l);             // 색상 조절 이벤트 제거
    }
}

// 250723 추가: 컬러 모드 2 (Hue Shift)
public static void Lucifer_ColorMode2(Lucifer_Core l, boolean enabled, float hueShift) {
    if (enabled) {
        if (originalImage == null && l.Lucifer_Buffered_Image != null) {
            originalImage = deepCopy(l.Lucifer_Buffered_Image);
        }

        if (originalImage != null) {
            l.Lucifer_Buffered_Image = shiftImageHue(originalImage, hueShift);  // → hue 조정 메서드 필요
            l.repaint();
        }
        attachHueSliderListener(l, hueShift);  // hue 전용 슬라이더 리스너 연결
    } else {
        removeHueSliderListener(l);
    }
}


//HSV 기반으로 이미지 전체의 Hue를 shift하는 메서드 250723 추가
public static BufferedImage shiftImageHue(BufferedImage source, float hueShift) {
 int width = source.getWidth();
 int height = source.getHeight();

 BufferedImage shiftedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

 for (int y = 0; y < height; y++) {
     for (int x = 0; x < width; x++) {
         int argb = source.getRGB(x, y);

         // alpha 값 추출
         int alpha = (argb >> 24) & 0xFF;

         // RGB → HSB 변환
         Color color = new Color(argb, true);
         float[] hsb = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);

         // Hue shift 적용
         float newHue = (hsb[0] + hueShift) % 1.0f;
         if (newHue < 0) newHue += 1.0f;

         // HSB → RGB로 다시 변환
         int shiftedRGB = Color.HSBtoRGB(newHue, hsb[1], hsb[2]);

         // 알파 값 복원
         int finalARGB = (alpha << 24) | (shiftedRGB & 0x00FFFFFF);
         shiftedImage.setRGB(x, y, finalARGB);
     }
 }

 return shiftedImage;
}

//전역 변수로 선언 (필요 시 Lucifer_Core 내부에 넣어도 됨)
private static JSlider hueSlider;


public static void attachHueSliderListener(Lucifer_Core l, float initialHue) {
    if (hueSlider == null) {
        hueSlider = new JSlider(0, 100, (int)(initialHue * 100));  // 0~100 범위
        hueSlider.setPreferredSize(new Dimension(150, 30));
        hueSlider.setToolTipText("루시퍼 색조 조절");

        hueSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                float hueValue = hueSlider.getValue() / 100f;  // 0.0 ~ 1.0f
                l.Lucifer_Buffered_Image = shiftImageHue(originalImage, hueValue);
                l.repaint();
            }
        });

        // 루시퍼 프레임이나 패널에 추가
        l.add(hueSlider); // 필요에 따라 add 위치 조정
        l.revalidate();
        l.repaint();
    }
}

public static void removeHueSliderListener(Lucifer_Core l) {
    if (hueSlider != null) {
        l.remove(hueSlider);
        hueSlider = null;
        l.revalidate();
        l.repaint();
    }
}

//마우스 체이싱
	
			private static Timer chasingTimer;
			
			public static void startMouseChasing(Lucifer_Core lucifer) {
				
				Lucifer_Order.Lucifer_Stop();
				lucifer.Lucifer_Flip();
				
			    if (chasingTimer != null && chasingTimer.isRunning()) {
			        chasingTimer.stop();
			    }
		
			    chasingTimer = new Timer(30, e -> {
			    	  Window window = SwingUtilities.getWindowAncestor(lucifer);  // 최상위 프레임 찾기
			        if (window == null) return;
		
			        Point mouse = MouseInfo.getPointerInfo().getLocation();
			        Point current = window.getLocation();
		
			        int dx = (mouse.x - current.x + 100) / 30;
			        int dy = (mouse.y - current.y - 250) / 30;
		
			        window.setLocation(current.x + dx, current.y + dy);
			    });
		
			    chasingTimer.start();
			}
		
			public static void stopMouseChasing() {
			    if (chasingTimer != null) chasingTimer.stop();
			}




			  // 디버그 정보 출력
			   public static void Lucifer_Debug(JComponent comp) {
			       // 트레이스 표시
			       System.err.println("루시퍼 패널");
			       comp.setBorder(BorderFactory.createLineBorder(Color.RED));

			       // 디버깅: 이미지 경로 출력
			       System.out.println("현재 작업 디렉터리: " + System.getProperty("user.dir"));
			       System.out.println("이미지 기본 경로: " + Registry.IMAGE_ICON_LUCIFER);
			   }
			   
			   
				
			   
			
			   public static void restoreOriginalImage(Lucifer_Core lucifer) {
				    if (lucifer == null || originalImage == null) return;

				    // 원본 이미지 복원
				    lucifer.Lucifer_Buffered_Image = deepCopy(originalImage);

				    // 원본 이미지 크기 반영
				    int newW = originalImage.getWidth();
				    int newH = originalImage.getHeight();
				    int speechH = Lucifer_Core.getLuciferSpeechHeight(newH);

				    // 내부 상태 갱신
				    lucifer.imgW = newW;
				    lucifer.imgH = newH;
				    lucifer.speechHeight = speechH;

				    // 프레임/패널 사이즈 재설정
				    lucifer.parentFrame.setSize(newW, newH + speechH);
				    lucifer.setPreferredSize(new Dimension(newW, newH + speechH));
				    lucifer.parentFrame.revalidate();
				    lucifer.revalidate();
				    lucifer.repaint();
				}


			   
			  
			   public static void ChangeImage(Lucifer_Core lucifer, Component parent) {
				    JFileChooser fileChooser = new JFileChooser();
				    fileChooser.setDialogTitle("변신할 파일을 고르세요.");

				    int result = fileChooser.showOpenDialog(parent);
				    if (result == JFileChooser.APPROVE_OPTION) {
				        File selectedFile = fileChooser.getSelectedFile();
				        try {
				            BufferedImage newImage = ImageIO.read(selectedFile);

				            // 최초 1회 원본 백업
				            if (originalImage == null && lucifer.Lucifer_Buffered_Image != null) {
				                originalImage = deepCopy(lucifer.Lucifer_Buffered_Image);
				            }

				            // 유저 인터랙션/이동 중지
				            lucifer.detachResizeWheel();
				            removeColorWheelListener(lucifer);
				            Lucifer_Order.detachMouseControl(lucifer);
				            Lucifer_Order.Lucifer_Stop();

				            // 이미지 적용
				            lucifer.Lucifer_Buffered_Image = newImage;
				            // 프레임/패널 사이즈 재설정
				            int newW = newImage.getWidth();
				            int newH = newImage.getHeight();
				            int speechH = Lucifer_Core.getLuciferSpeechHeight(newH);

				            lucifer.imgW = newW;
				            lucifer.imgH = newH;
				            lucifer.speechHeight = speechH;

				            lucifer.parentFrame.setSize(newW, newH + speechH);
				            lucifer.setPreferredSize(new Dimension(newW, newH + speechH));
				            lucifer.parentFrame.revalidate();
				            lucifer.revalidate();
				            lucifer.repaint();


				            // ※ 30초 후 복원 (Thread.sleep(1 * 30 * 1000) = 30,000ms)
				            new Thread(() -> {
				                try {
				                    Thread.sleep(1 * 30 * 1000);
				                    restoreOriginalImage(lucifer);

				                    lucifer.attachResizeWheel();
				                    attachColorWheelListener(lucifer, Registry.Lucifer_ColorIndex);
				                    Lucifer_Order.attachMouseControl(lucifer);
				                    Lucifer_Order.Lucifer_Start();

				                } catch (InterruptedException ignored) {}
				            }).start();

				        } catch (IOException e) {
				            JOptionPane.showMessageDialog(null, "루시퍼 캐릭터 변신 : " + e.getMessage());
				        }
				    }
				}



	
			   public static void attachColorWheelListener(Lucifer_Core l, int colorIndex) {
			       removeColorWheelListener(l); // 기존 리스너 제거

			       currentColorIndex = colorIndex % Speech.availableColors.length;

			       colorModeListener = e -> {
			           int notches = e.getWheelRotation();
			           currentColorIndex = (notches < 0)
			               ? (currentColorIndex + 1) % availableColors.length
			               : (currentColorIndex - 1 + availableColors.length) % Speech.availableColors.length;

			               Registry.Lucifer_ColorIndex = currentColorIndex;  // 현재 인덱스 저장
			               // System.out.println(Registry.Lucifer_ColorIndex); // 디버깅용
			               
			           if (Lucifer_Function.originalImage != null) {
			               l.Lucifer_Buffered_Image = recolorImage(originalImage, availableColors[currentColorIndex]);
			               l.repaint();
			           }
			       };
			       l.addMouseWheelListener(colorModeListener);
			   }

			   public static void removeColorWheelListener(Lucifer_Core l) {
			       if (colorModeListener != null) {
			           l.removeMouseWheelListener(colorModeListener);
			           colorModeListener = null;
			       }
			   }

			
			
			   
			   
			   
	}
