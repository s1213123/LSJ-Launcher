package v7.Avatars;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.Timer;

import v7.Config.Registry;
import v7.Connect.Speech;

/**
 * 루시퍼 코어(Lucifer_Core)
 * - 아바타 이미지 렌더링 및 기본 동작 설정
 * - 포털(Portal)을 상속받아 이동/반전/말풍선 높이 등의 공통 로직 활용
 */

public class Lucifer_Core extends Portal {

	
	public static JFrame parentFrame;
	public static BufferedImage Lucifer_Buffered_Image;
	
	   // 루시퍼 기본 이미지 크기 (초기 프레임 크기와 동일) / Default image size
    protected static int imgW = Registry.FRAME_WIDTH;
    protected static int imgH = Registry.FRAME_HEIGHT;

    protected static int speechHeight = getLuciferSpeechHeight(imgH);

    protected String srcPath = Registry.IMAGE_ICON_LUCIFER;

    
    
    protected int[] dx = Registry.Lucifer_dx;
    protected int[] dy = Registry.Lucifer_dy;

    protected static Timer moveTimer;
	protected static boolean isMoving = true;
    protected boolean isFlipped = false;
    

    
	public static boolean colorModeListenerAttached = true;

	private static int wheelSpeechCounter = 0;  // 휠 감지용 카운터
	private static final int WHEEL_THRESHOLD = 15;  // 10번에 1번만 변경
	private static int wheelFontCounter = 0;
	private static final int FONT_WHEEL_THRESHOLD = 4; // 3번마다 적용

	  private String mode;
	//  private JLabel imageLabel, speechLabel;
	
	/**
	 * 루시퍼 코어 생성자
	 * 
	 * @param parentFrame
	 *            루시퍼가 붙는 외부 JFrame (위치 제어 등에 활용)
	 */
	public Lucifer_Core(JFrame parentFrame, String mode) {
		super(parentFrame);
		this.parentFrame = parentFrame;
		Registry.globalLucifer = this;

	    this.mode = mode;
		
	    String srcPath;

	    switch (mode) {
	        case "lucifer_white":
	            srcPath = "images/lucifer_white.png";
	            break;
	        case "lucifer_red":
	            srcPath = "images/lucifer_red.png";
	            break;
	        default:
	            srcPath = Registry.IMAGE_ICON_LUCIFER;
	            break;
	    }
	    
		Evolution();

		// 초기 루시퍼 이미지 로드
		Lucifer_Imageloading(srcPath);
		Show_InputLabel(Registry.ShowInputLabel);
		Show_SpeechLabel(Registry.ShowSpeechLabel);
		
		Lucifer_Move();
		Lucifer_Wheel_Resize1();
		
		
		Lucifer_Order.attachMouseControl(this);
		Lucifer_Order.Lucifer_Transparency(this);
	    
		//System.out.println(Registry.Lucifer_ColorIndex); // 디버깅용
		Lucifer_Function.Lucifer_ColorMode1(this, Lucifer_Core.colorModeListenerAttached, Registry.Lucifer_ColorIndex);
		
		
		setLayout(null);
	
		
	}

	

	/**
	 * 루시퍼 이미지 직접 출력 (BufferedImage 기반)
	 * @param g Graphics 객체
	 */

	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (Lucifer_Buffered_Image != null) {
				
			if (isFlipped) {
			    g.drawImage(Lucifer_Buffered_Image, imgW, speechHeight, -imgW, imgH, this);
			} else {
			    g.drawImage(Lucifer_Buffered_Image, 0, speechHeight, imgW, imgH, this);
			}

			
		}
	}

	// 루시퍼 진화 (말풍선 초기화)
	public void Evolution() {

		if (imageLabel != null)
			imageLabel.setVisible(false);
		if (inputLabel != null)
			inputLabel.setVisible(false);	
		
		
		if (speechLabel != null) {
			speechLabel.setVisible(false);
			// 최초 1회 생성
			//speechLabel = new JLabel();

	        String[] sampleLines = Speech.getGroupLines("samples2");
	        // 그리팅 인사말
	        
	        int randomIndex = new Random().nextInt(sampleLines.length);
	        speechLabel = new JLabel("<html><body style='width: " + (imgW - 40) + "px'>" + sampleLines[randomIndex] + "</body></html>");

			
			
	        speechLabel.setFont(new Font("맑은 고딕", Font.BOLD, 14));
	        
			speechLabel.setOpaque(true);
			speechLabel.setBackground(new Color(255, 255, 255, 230));
			speechLabel.setForeground(Color.BLACK);
			speechLabel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
			speechLabel.setBounds(0, 0, imgW, speechHeight);
			//speechLabel.setText(Speech.getSpeechByTime());
			//speechLabel.setText(Speech.foodLines);
			//Speech.getSpeechByTime();
			
		    add(speechLabel);

			// 이후 주기적 업데이트
/*			Timer timer = new Timer(3000, e -> {
			    String newText = Speech.getSpeechByTime();
			    speechLabel.setText(newText);
				
				
			});
			timer.start();
*/		}
	
		
		
	        
		
	}
	
	private void Lucifer_Imageloading(String srcPath){
	
	
		try {
		    URL imageUrl = getClass().getClassLoader().getResource(srcPath);
		    if (imageUrl != null) {
		        Lucifer_Buffered_Image = ImageIO.read(imageUrl);
		    } else {
		        File fallback = new File("src/resources/" + srcPath);
		        if (fallback.exists()) {
		            Lucifer_Buffered_Image = ImageIO.read(fallback);
		        } else {
		            System.err.println("루시퍼 이미지 경로 실패 (resource & fallback 모두 실패): " + srcPath);
		        }
		    }
		    
		    if (Lucifer_Buffered_Image != null) {
	    	
		    	speechHeight = getLuciferSpeechHeight(imgH);
						    	
			   	Show_SpeechLabel(Registry.ShowSpeechLabel);
				Show_InputLabel(Registry.ShowInputLabel);
		    	
		        int totalH = imgH + speechHeight;
			    
			    parentFrame.setSize(imgW, totalH);
			    setPreferredSize(new Dimension(imgW, totalH));
			    parentFrame.revalidate();
		    }
		    
		    
		} catch (Exception e) {
		    System.err.println("루시퍼 이미지 로드 실패");
		    e.printStackTrace();
		}
	}
	
	

	
	
	// 猷⑥떆�띁 �씠�룞 �븿�닔
	private void Lucifer_Move() {
	    moveTimer = new Timer(30, null); // 30ms 媛꾧꺽

	    moveTimer.addActionListener(e -> {
	        if (!isMoving || Lucifer_Buffered_Image == null || parentFrame == null) return;

	        Point current = parentFrame.getLocation();
	        int newX = current.x + dx[0];
	        int newY = current.y + dy[0];

	        // 화면 경계 체크 (X)
	        int screenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
	        int frameWidth = parentFrame.getWidth();
	        if (newX < 0 || newX + frameWidth > screenWidth) {
	            dx[0] = -dx[0]; // X 방향 반전
	            Lucifer_Flip();
	        }

	        // 화면 경계 체크 (Y)
	        int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
	        int frameHeight = parentFrame.getHeight();
	        if (newY < 0 || newY + frameHeight > screenHeight) {
	            dy[0] = -dy[0]; // Y 방향 반전
	        }

	        parentFrame.setLocation(newX, newY); // X + Y 이동
	    });

	    moveTimer.start();
	    isMoving = true;
	}

	public void Lucifer_Flip() {
	    isFlipped = !isFlipped;
	    repaint();
	}
	


	


	// 휠 리스너 (초기화)
	protected MouseWheelListener resizeWheelListener;

	// 휠 리스너 등록
	protected void Lucifer_Wheel_Resize1() {
	    resizeWheelListener = e -> {
	        int delta = (e.getWheelRotation() < 0) ? 10 : -10;
	        Lucifer_Wheel_Resize2(delta);
	        
	        // 폰트 조절은 일정 횟수 후에만 반응
	        wheelFontCounter++;
	        if (wheelFontCounter >= FONT_WHEEL_THRESHOLD) {
	            wheelFontCounter = 0;

	            int currentSize = speechLabel.getFont().getSize();
	            int newFontSize = currentSize + (e.getWheelRotation() < 0 ? 1 : -1);
	            newFontSize = Math.max(14, Math.min(50, newFontSize));

	            speechLabel.setFont(new Font("맑은 고딕", Font.BOLD, newFontSize));
	            speechLabel.repaint();
	        }
	    };
	    
	    addMouseWheelListener(resizeWheelListener);
	}


	// 휠 리스너 제거
	public void detachResizeWheel() {
	    if (resizeWheelListener != null) {
	        removeMouseWheelListener(resizeWheelListener);
	    }
	}

	public void attachResizeWheel() {
	    if (resizeWheelListener != null) {
	        addMouseWheelListener(resizeWheelListener);
	    }
	}

	
	
	// 루시퍼 크기 조정 함수 (휠 이벤트 → 이미지 리사이즈)
	protected void Lucifer_Wheel_Resize2(int delta){
		
		if (Lucifer_Buffered_Image == null) return;

		speechHeight = getLuciferSpeechHeight(imgH);

	    imgW = Math.max(150, imgW + delta);
	    imgH = Math.max(150, imgH + delta);  


	    int totalH = imgH + speechHeight;
	    
	    parentFrame.setSize(imgW, totalH);
	    setPreferredSize(new Dimension(imgW, totalH));
	    parentFrame.revalidate();

		Show_SpeechLabel(Registry.ShowSpeechLabel);
		Show_InputLabel(Registry.ShowInputLabel);
	    
		repaint();
	}
	
	
	
	
	
	// 말풍선 표시 여부 처리
	public static void Show_SpeechLabel(Boolean showSpeechLabel) {
	    if (speechLabel != null) {
	        // 말풍선 크기 설정
	        int SPEECH_W = imgW;
	        int SPEECH_H = speechHeight;

	        speechLabel.setBounds(0, 0, SPEECH_W, SPEECH_H);
	        speechLabel.setOpaque(true);
	        speechLabel.setBackground(new Color(255, 255, 255, 200));
	        //speechLabel.setFont(new Font("맑은 고딕", Font.BOLD, Speech.getFontSize()));

	        
	        if (showSpeechLabel) {
	            wheelSpeechCounter++;

	            if (wheelSpeechCounter >= WHEEL_THRESHOLD) {
	                wheelSpeechCounter = 0;  // 초기화
	                String newText = Speech.smartLine();
	                // 스피치 스마트 라인 출
	                
	                String htmlText = "<html><body style='width: " + (imgW - 60) + "px'>" + newText + "</body></html>";
	                speechLabel.setText(htmlText);
	            }
	        }
	        
/*	        if (showSpeechLabel) {
	            String newText = Speech.getSpeechByTime();
	            String htmlText = "<html><body style='width: " + (imgW-52) + "px'>" + newText + "</body></html>";
	            speechLabel.setText(htmlText);
	        }
*/
	        speechLabel.setVisible(showSpeechLabel);

	        // HTML 기반 재적용 (재래핑)
	        String rawText = speechLabel.getText();
	        if (rawText != null && rawText.startsWith("<html>")) {
	            String stripped = rawText.replaceAll("(?s)<html>.*?<body.*?>(.*?)</body></html>", "$1").trim();
	            String updatedHtml = "<html><body style='width: " + (imgW-60) + "px'>" + stripped + "</body></html>";
	            speechLabel.setText(updatedHtml);
	        }

	        speechLabel.repaint();
	    }
	}

	
    // 입력 라벨 표시 여부 처리
    public void Show_InputLabel(Boolean showInputLabel) {
        
        if (inputLabel != null) {

        	   int clockW = imgW * 10 /10;
               int clockH = imgH * 1 / 3;
               int clockX = (imgW - clockW) / 2;
               int clockY = speechHeight + (imgH * 1 / 2);
               
               // 기존 inputLabel 제거 후 새로 부착
        	remove(inputLabel);
        	
            inputLabel = new JLabel() {
                @Override
                protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                    g2.setColor(new Color(255, 255, 255, 215));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30); // 그리기
                    super.paintComponent(g2);
                    g2.dispose();
                }
            };
            
      

            int dynamicFontSize = Math.max(20, imgH / 8);
            inputLabel.setFont(new Font("맑은 고딕", Font.BOLD, dynamicFontSize));
            
            inputLabel.setBounds(clockX, clockY, clockW, clockH);
            inputLabel.setHorizontalAlignment(SwingConstants.CENTER);
             
            inputLabel.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 255, 128), 2, true));
            
       
            add(inputLabel);            

             
            inputLabel.setOpaque(false);
     

            inputLabel.setVisible(showInputLabel);
            inputLabel.repaint(); 
        }
    }
	

    public static int getLuciferSpeechHeight(int luciferHeight) {
          //if (!ShowSpeechLabel) return 0;

    	// 말풍선 높이 계산
          int dynamic = luciferHeight / 4; 
          return Math.max(50, Math.min(dynamic, 200));
      }



}
