
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.JFrame;

import Config.L_Setting_DTO;
import Config.Lucid_Loader;
import Lucifer_Core.AvatarCore;
import Lucifer_Core.Lucifer1;
import Lucifer_Core.Lucifer2;
import Panels.Lucid_Frame;

public class LSJ_Starter extends JFrame {
    private static final String CONFIG_PATH = "config/lucifer_setting.txt";
    private Point mousePressedLocation;

    public LSJ_Starter() {
        super("LSJ_Launcher");
        initFrame();

        L_Setting_DTO L_dto = Lucid_Loader.loadFromFile(CONFIG_PATH);
        AvatarCore avatarPanel = initAvatar(L_dto);

        add(avatarPanel, BorderLayout.CENTER);
        applyDragMove(avatarPanel);
       
        //테스트용
        new Lucid_Frame(this);
        //
    }

    private void initFrame() {
        setUndecorated(true);
        setAlwaysOnTop(true);
        setBackground(new Color(0, 0, 0, 0));
        setLayout(new BorderLayout());
    }

    private AvatarCore initAvatar(L_Setting_DTO L_dto) {
        AvatarCore avatarPanel;
        avatarPanel = new AvatarCore(L_dto);
        if ("lucifer1".equals(L_dto.getAvatarType())) {
            avatarPanel = new Lucifer1(L_dto, this);
        } else if ("lucifer2".equals(L_dto.getAvatarType())) {
            avatarPanel = new Lucifer2(L_dto, this);
        }

        avatarPanel.setBounds(L_dto.getPosX(), L_dto.getPosY(), L_dto.getSizeW(), L_dto.getSizeH());
        avatarPanel.setBorder(BorderFactory.createLineBorder(Color.GREEN, 2));
      //  setSize(A_dto.getSizeW(), A_dto.getSizeH() + A_dto.getSpeechHeight());
      //  setLocation(A_dto.getPosX(), A_dto.getPosY() - A_dto.getSpeechHeight());
        setSize(L_dto.getSizeW(), L_dto.getSizeH());
        setLocation(L_dto.getPosX(), L_dto.getPosY());
        return avatarPanel;
    }

    private void applyDragMove(AvatarCore avatarPanel) {
        avatarPanel.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                mousePressedLocation = e.getPoint();
            }
        });

        avatarPanel.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                Point current = e.getLocationOnScreen();
                setLocation(current.x - mousePressedLocation.x, current.y - mousePressedLocation.y);
            }
        });
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            LSJ_Starter starter = new LSJ_Starter();
            starter.setVisible(true);
        });
    }
}
