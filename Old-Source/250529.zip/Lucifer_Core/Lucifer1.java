package Lucifer_Core;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import Config.L_Setting_DTO;

public class Lucifer1 extends AvatarCore {

	private JFrame hostFrame;
	
    private Timer moveTimer;
    private int dx, dy;

    
    // 2단계 진화
    private boolean isMoving = true;

    protected BufferedImage luciferBufferImage;
    protected float luciferScale = 1.0f;
    protected boolean luciferFlipped = false;

    
    
    public Lucifer1(L_Setting_DTO L_dto, JFrame frame) {
        super(L_dto);
        this.hostFrame = frame;
        
        remove(portalLabel);
        

        dx = L_dto.getMoveX();
        dy = L_dto.getMoveY();
        
        ImageIcon luciferIcon = new ImageIcon(L_dto.getImagePath());
        Image luciferScaledImage = luciferIcon.getImage().getScaledInstance(
        		L_dto.getSizeW(), L_dto.getSizeH(), Image.SCALE_SMOOTH
        );

        try {
            luciferBufferImage = ImageIO.read(new File(L_dto.getImagePath()));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
     
        
        addMouse();
        
        sayHello();
        startMoving();  
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (luciferBufferImage != null) {
            Graphics2D g2 = (Graphics2D) g.create();
            int drawWidth = (int)(luciferBufferImage.getWidth() * luciferScale);
            int drawHeight = (int)(luciferBufferImage.getHeight() * luciferScale);

            int x = (getWidth() - drawWidth) / 2;
            int y = (getHeight() - drawHeight) / 2;

            if (luciferFlipped) {
                g2.drawImage(luciferBufferImage, x + drawWidth, y, -drawWidth, drawHeight, null);
            } else {
                g2.drawImage(luciferBufferImage, x, y, drawWidth, drawHeight, null);
            }

            g2.dispose();
        }
    }

    private void addMouse(){


        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    isMoving = !isMoving;
                    speak(isMoving ? "움직일게!" : "잠깐 멈출게!");
                }
            }
        });
        
        addMouseWheelListener(e -> {
            int drawWidth = (int)(luciferBufferImage.getWidth() * luciferScale);
            int drawHeight = (int)(luciferBufferImage.getHeight() * luciferScale);

            if (e.getWheelRotation() < 0) {
                drawWidth += 10;
                drawHeight += 10;
            } else {
                drawWidth -= 10;
                drawHeight -= 10;
            }

            // 제한
            drawWidth = Math.max(100, Math.min(1400, drawWidth));
            drawHeight = Math.max(100, Math.min(1400, drawHeight));

            luciferScale = drawWidth / (float) luciferBufferImage.getWidth();

            setPreferredSize(new Dimension(drawWidth, drawHeight));
            revalidate();

            // ✅ 말풍선 크기/위치 갱신
            if (speechLabel != null) {
                int speechHeight = L_dto.getSpeechHeight();
                speechLabel.setBounds(
                    0,
                    0,
                    drawWidth,
                    speechHeight
                );
                speechLabel.repaint();
            }

            if (hostFrame != null) {
                hostFrame.getContentPane().setPreferredSize(new Dimension(drawWidth, drawHeight));
                hostFrame.pack();
            }

            repaint();
        });
    }
    
    private void startMoving() {
        moveTimer = new Timer(30, e -> {
        	
            if (!isMoving) return; // 멈춤 상태면 이동하지 않음

            Point current = hostFrame.getLocation();
            int newX = current.x + dx;

            int screenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
            int frameWidth = hostFrame.getWidth();

            if (newX < 0 || newX + frameWidth > screenWidth) {
                dx = -dx;
                luciferFlipped = !luciferFlipped;
                repaint();
            }

            hostFrame.setLocation(newX, current.y);
        });
        moveTimer.start();
        
    }

    
    public void sayHello() {
        speak("안녕, 나는 루시퍼야!");
    }
}


