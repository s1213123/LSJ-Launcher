package Lucifer_Core;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;

import Config.L_Setting_DTO;

// Lucifer2 클래스는 Lucifer1을 상속받아, 마우스 휠을 이용해 색상을 순환하여 바꾸는 기능을 추가한 클래스입니다.
public class Lucifer2 extends Lucifer1 {

    // 사용 가능한 색상 배열 정의
    private final Color[] availableColors = new Color[]{
        new Color(255, 128, 180),  // 핑크
        new Color(140, 185, 215),  // 연하늘
        new Color(255, 200, 120),  // 살구
        new Color(120, 255, 180),  // 민트
        new Color(180, 120, 255),  // 보라
        new Color(255, 100, 100)   // 레드
    };

    private int currentColorIndex = 0;  // 현재 선택된 색상 인덱스
    private BufferedImage originalImage;  // 원본 이미지 백업용

    // 생성자: Lucifer1에서 받은 DTO와 프레임을 바탕으로 초기화
    public Lucifer2(L_Setting_DTO L_dto, JFrame frame) {
        super(L_dto, frame);

        // luciferBufferImage가 존재할 경우, 원본 이미지 복사 후 첫 번째 색상으로 변환
        if (luciferBufferImage != null) {
            originalImage = deepCopy(luciferBufferImage);
            luciferBufferImage = recolorImage(originalImage, availableColors[currentColorIndex]);
        }

        // 마우스 휠로 색상 전환 기능 추가
        addMouseWheelListener(new MouseWheelListener() {
            @Override
            public void mouseWheelMoved(MouseWheelEvent e) {
                int notches = e.getWheelRotation();
                if (notches < 0) {
                    currentColorIndex = (currentColorIndex + 1) % availableColors.length;
                } else {
                    currentColorIndex = (currentColorIndex - 1 + availableColors.length) % availableColors.length;
                }

                // 색상 변경 적용
                if (originalImage != null) {
                    luciferBufferImage = recolorImage(originalImage, availableColors[currentColorIndex]);
                    repaint(); // 이미지 갱신
                }
            }
        });
    }

    // 이미지 깊은 복사 함수
    private BufferedImage deepCopy(BufferedImage src) {
        BufferedImage copy = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = copy.createGraphics();
        g.drawImage(src, 0, 0, null);
        g.dispose();
        return copy;
    }


    // 색상이 유사한지 판단
    private boolean isSimilar(Color c1, Color c2, int threshold) {
        int dr = Math.abs(c1.getRed() - c2.getRed());
        int dg = Math.abs(c1.getGreen() - c2.getGreen());
        int db = Math.abs(c1.getBlue() - c2.getBlue());
        return (dr + dg + db) < threshold;
    }

    // 몸통 색상만 변경
    private BufferedImage recolorImage(BufferedImage src, Color newColor) {
        BufferedImage result = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Color baseColor = new Color(188, 207, 225);   // 몸통
        Color tongueColor = new Color(255, 225, 210); // 혀
        Color spikeColor = new Color(30, 40, 60);     // 뿔

        for (int y = 0; y < src.getHeight(); y++) {
            for (int x = 0; x < src.getWidth(); x++) {
                int pixel = src.getRGB(x, y);
                Color c = new Color(pixel, true);
                if (isSimilar(c, baseColor, 80)
                    && !isSimilar(c, tongueColor, 60)
                    && !isSimilar(c, spikeColor, 60)) {
                    int rgba = (newColor.getRGB() & 0x00FFFFFF) | (pixel & 0xFF000000);
                    result.setRGB(x, y, rgba);
                } else {
                    result.setRGB(x, y, pixel);
                }
            }
        }
        return result;
    }
}