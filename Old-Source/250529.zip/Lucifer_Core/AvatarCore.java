
package Lucifer_Core;

import java.awt.Color;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import Config.L_Setting_DTO;

public class AvatarCore extends JPanel {

    protected JLabel portalLabel;     // 아바타 이미지
    protected JLabel speechLabel;     // 말풍선
    protected L_Setting_DTO L_dto;

    public AvatarCore(L_Setting_DTO L_dto) {
        this.L_dto = L_dto;
        init();
    }

    protected void init() {
        setOpaque(false);
        setLayout(null);
        setupAvatarImage();
        setupSpeechBubble();
        setupMouseEvents();  // 하위 클래스에서 필요하면 오버라이드
  
    }

    protected void setupAvatarImage() {
        ImageIcon avatarIcon;
        URL imageUrl = getClass().getClassLoader().getResource("resources/portal.png");

        if (imageUrl != null) {
            avatarIcon = new ImageIcon(imageUrl);
        } else {
            avatarIcon = new ImageIcon("src/resources/portal.png");  // 개발 환경용 fallback
        }

        portalLabel = new JLabel(avatarIcon);
        portalLabel.setBounds(0, 0, L_dto.getSizeW(), L_dto.getSizeH());
        add(portalLabel);
    }

    protected void setupSpeechBubble() {
        speechLabel = new JLabel(L_dto.getDefaultMessage(), SwingConstants.CENTER);
        speechLabel.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        speechLabel.setForeground(Color.WHITE);
        speechLabel.setOpaque(true);
        speechLabel.setBackground(new Color(0, 0, 0, 150));
        speechLabel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 2));

        // 예전 방식대로 최상단 고정
        speechLabel.setBounds(0, 0, L_dto.getSizeW(), L_dto.getSpeechHeight());
        add(speechLabel);
    }

    protected void setupMouseEvents() {
    	addMouseListener(new MouseAdapter() {
    	    @Override
    	    public void mousePressed(MouseEvent e) {
    	        if (SwingUtilities.isRightMouseButton(e)) {
    	        	 Point locationOnScreen = getLocationOnScreen(); // 루시퍼 프레임의 위치
    	                int popupX = locationOnScreen.x + e.getX();
    	                int popupY = locationOnScreen.y + e.getY();

    	                AvatarCall lucidFrame = new AvatarCall(popupX, popupY); // 생성
    	                lucidFrame.setLocation(popupX, popupY); // 위치 지정
    	        }
    	    }
    	});

    }

    public void speak(String message) {
        speechLabel.setText(message);
    }
}
