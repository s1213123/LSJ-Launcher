package Lucifer_Core;

import Config.Lucid_Loader;
import Config.M_Setting_DTO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;

public class AvatarCall extends JFrame {
    public AvatarCall(int x, int y) {
        M_Setting_DTO p_dto = Lucid_Loader.loadSetting("C:/LSJ-Soft/LSJ-Eclipse/LSJ-Eclipse/LSJ-Workspace/LSJ-Launcher/Config/menu_setting.txt");

        setLayout(new GridLayout(5, 1));
        setSize(250, 250);
        setLocation(x, y);
        setUndecorated(true);
        setAlwaysOnTop(true);

        // 배경 색상 설정 (선택)
        Color backgroundColor = Color.decode(p_dto.getColor());

        // 타이틀
        JLabel titleLabel = new JLabel(p_dto.getTitle(), SwingConstants.CENTER);
        titleLabel.setFont(new Font(p_dto.getFont(), Font.BOLD, p_dto.getFontsize()));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBackground(backgroundColor);
        titleLabel.setOpaque(true);
        add(titleLabel);

        // 버튼들
        for (int i = 0; i < 4; i++) {
            JButton button = new JButton(p_dto.getButtons()[i]);
            button.setFont(new Font(p_dto.getFont(), Font.PLAIN, p_dto.getFontsize()));
            button.setBackground(backgroundColor); // 버튼도 동일 배경
            button.setForeground(Color.WHITE);     // 글씨 하얗게
            add(button);
        }

        // 포커스 잃으면 닫기
        addWindowFocusListener(new WindowAdapter() {
            @Override
            public void windowLostFocus(WindowEvent e) {
                dispose();
            }
        });

        setVisible(true);
    }
}
