package Panels;

import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

import Config.P_Setting_DTO;

public class LucidSimplePanel extends JPanel {

    public LucidSimplePanel(P_Setting_DTO P_dto) {
        setLayout(null);
        setBounds(P_dto.getX(), P_dto.getY(), P_dto.getWidth(), P_dto.getHeight());
        setBackground(P_dto.getColor());
        setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));

        JLabel titleLabel = new JLabel(P_dto.getTitle());
        titleLabel.setBounds(10, 10, 180, 20);
        add(titleLabel);

        JLabel keyLabel = new JLabel("단축키: " + P_dto.getKey());
        keyLabel.setBounds(10, 35, 180, 20);
        add(keyLabel);
    }
}
