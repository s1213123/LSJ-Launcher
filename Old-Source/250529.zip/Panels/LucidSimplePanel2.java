package Panels;

import javax.swing.*;

import Config.M_Setting_DTO;

import java.awt.*;

public class LucidSimplePanel2 extends JFrame {
    public LucidSimplePanel2(M_Setting_DTO dto) {
        setTitle(dto.getTitle());
        setUndecorated(true);
        setLayout(new GridLayout(0, 1));
        setBackground(Color.decode(dto.getColor()));
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Font font = new Font(dto.getFont(), Font.PLAIN, dto.getFontsize());

        for (String btnText : dto.getButtons()) {
            JButton button = new JButton(btnText);
            button.setFont(font);
            add(button);
        }

        pack();
    }
}
