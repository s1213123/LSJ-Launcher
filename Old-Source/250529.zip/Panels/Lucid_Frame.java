
package Panels;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import Config.P_Setting_Parser;
import Config.P_Setting_DTO;
import Memories.EmptyPanel;


public class Lucid_Frame extends JFrame {
    private Point mousePressedLocation;
    private Map<String, JPanel> panelMap = new HashMap<>();

    public Lucid_Frame(JFrame luciferRef) {
        setTitle("Lucid Frame - 메뉴바 우측 세로");
        setUndecorated(true);
        setBackground(new Color(0, 0, 0, 0));
        setFocusableWindowState(true);
        setAlwaysOnTop(true);
        setLayout(null);

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setSize(screenSize.width, screenSize.height);
        setLocation(0, 0);

        JPanel borderPanel = new JPanel();
        borderPanel.setBorder(BorderFactory.createLineBorder(new Color(160, 0, 200), 4));
        borderPanel.setBounds(0, 0, screenSize.width, screenSize.height);
        borderPanel.setOpaque(false);
        add(borderPanel);

        // 메뉴바 세로 우측 배치
        JPanel menuBarPanel = new JPanel();
        menuBarPanel.setLayout(new GridLayout(0, 1, 0, 8));
        menuBarPanel.setBackground(new Color(255, 255, 255, 200));
        int menuWidth = 120;
        int menuHeight = 280;
        menuBarPanel.setBounds(screenSize.width - menuWidth - 20, 60, menuWidth, menuHeight);
        
  

        
/*
        addMenuButton(menuBarPanel, "상태", "status");
        addMenuButton(menuBarPanel, "설정", "setting");
        addMenuButton(menuBarPanel, "FTP", "ftp");
        addMenuButton(menuBarPanel, "영상", "video");
        addMenuButton(menuBarPanel, "스캐너", "scanner");
        addMenuButton(menuBarPanel, "모터", "motor");
        addMenuButton(menuBarPanel, "일기장", "diary");

*/        addMenuButton(menuBarPanel, "빈패널", "empty");
        
        add(menuBarPanel);

        int y = 60;
 /*       addPanel("status", createPanel("상태 보기", new Color(235, 250, 230)), 100, y += 140);
        addPanel("setting", new LucidSettingPanel(), 100, y += 140);
        addPanel("ftp", createPanel("FTP 공유 파일", new Color(250, 230, 230)), 100,  y += 140);
        addPanel("video", createPanel("영상 처리", new Color(240, 240, 200)), 100, y += 140);
        addPanel("scanner", createPanel("스캐너", new Color(230, 250, 250)), 100, y += 140);
        addPanel("motor", createPanel("모터 제어", new Color(250, 240, 255)), 100, y += 140);
        addPanel("diary", new LucidDiaryPanel(), 100, y += 140);
        
*/
        addPanel("empty", new EmptyPanel(), 400, 800);

        add(new EmptyPanel());
        
       // showPanel("status");

        
        List<P_Setting_DTO> panelList = P_Setting_Parser.loadPanels("Config/panel_setting.txt");
/*
        for (PanelGroupDTO dto : panelList) {
            JPanel panel = new LucidSimplePanel(dto); // DTO 기반으로 구성된 패널 생성
            panel.setBounds(dto.x, dto.y, dto.width, dto.height); // 위치/크기 적용
            add(panel); // 프레임에 패널 추가
        }
*/
        
        for (P_Setting_DTO P_dto : panelList) {
            addMenuButton(menuBarPanel, P_dto.getTitle(), P_dto.getKey()); // key는 패널 ID
           // addMenuButton.addActionListner(e->togglePanel(key));
            

            LucidHighPanel panel = new LucidHighPanel(P_dto.getTitle(), P_dto.getColor());
            
            //panel.addActionListener(e -> togglePanel(key));
            
            panel.setBounds(P_dto.getX(), P_dto.getY(), P_dto.getWidth(), P_dto.getHeight());
            add(panel);
        }

        
       /* 
        // 경로 테스트 코드
        File f = new File("Config/panel_setting.txt");
        System.out.println("파일 존재 여부: " + f.exists());
        System.out.println("절대 경로: " + f.getAbsolutePath());
*/
        
        luciferRef.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setVisible(true);
    }

    private void addMenuButton(JPanel menu, String label, String key) {
        JButton button = new JButton(label);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(100, 30));
        button.addActionListener(e -> togglePanel(key));
        menu.add(button);
    }

    
    public void addPanel(String key, JPanel panel, int x, int y) {
        panel.setBounds(x, y, panel.getPreferredSize().width, panel.getPreferredSize().height);
        panel.setVisible(false);
        add(panel);
        panelMap.put(key, panel);
    }
/*
    private JPanel createPanel(String title, Color bgColor) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(title));
        panel.setBackground(bgColor);
        panel.add(new JLabel(title), BorderLayout.CENTER);
        return panel;
    }
*/
    public void togglePanel(String key) {
        JPanel panel = panelMap.get(key);
        if (panel != null) {
            panel.setVisible(!panel.isVisible());
            
          
        }
        
        
    }

    public void showPanel(String key) {
        JPanel panel = panelMap.get(key);
        if (panel != null) {
            panel.setVisible(true);
        }
    }

    public void hidePanel(String key) {
        JPanel panel = panelMap.get(key);
        if (panel != null) {
            panel.setVisible(false);
        }
    }
}
