package Panels;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

public class LucidHighPanel extends JPanel {
    private Point initialClick;

    public LucidHighPanel(String title, Color color) {
        setLayout(new BorderLayout());
        setBackground(color);
        setBorder(BorderFactory.createTitledBorder(title));

        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                initialClick = e.getPoint();
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                Component c = (Component) e.getSource();
                Point location = c.getLocation();
                int x = location.x - initialClick.x + e.getX();
                int y = location.y - initialClick.y + e.getY();
                c.setLocation(x, y);
            }
        });
    }
}
