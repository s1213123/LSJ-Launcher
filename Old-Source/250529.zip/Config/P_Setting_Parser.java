package Config;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class P_Setting_Parser {

    // 설정 파일을 받아서, 패널 DTO 리스트를 반환
    public static List<P_Setting_DTO> loadPanels(String path) {
        List<P_Setting_DTO> panels = new ArrayList<>();             // 최종 결과 저장
        Map<String, Map<String, String>> grouped = new HashMap<>(); // 그룹별 데이터 분리 (p1, p2 등)

        // 파일 읽기 시도
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            String line;

            while ((line = reader.readLine()) != null) {
                // 주석 또는 빈 줄 건너뛰기
                if (line.startsWith("#") || !line.contains("=")) continue;

                // key=value 형식 분리
                String[] parts = line.split("=", 2);
                String key = parts[0].trim();   // 예: p1.x
                String value = parts[1].trim(); // 예: 100

                // key를 p1 / x 구조로 분리
                String[] keyParts = key.split("\\.");
                if (keyParts.length != 2) continue;

                String group = keyParts[0];     // 예: p1
                String field = keyParts[1];     // 예: x

                // 그룹이 없으면 새로 추가하고 값 저장
                grouped.putIfAbsent(group, new HashMap<>());
                grouped.get(group).put(field, value);
            }

            // 그룹화된 정보를 바탕으로 DTO 구성
            for (Map<String, String> fields : grouped.values()) {
                P_Setting_DTO P_dto = new P_Setting_DTO();
                try {
                    P_dto.setTitle(fields.getOrDefault("title", "Untitled"));
                    P_dto.setX(Integer.parseInt(fields.getOrDefault("x", "100")));
                    P_dto.setY(Integer.parseInt(fields.getOrDefault("y", "100")));
                    P_dto.setWidth(Integer.parseInt(fields.getOrDefault("w", "300")));
                    P_dto.setHeight(Integer.parseInt(fields.getOrDefault("h", "200")));

                    int r = Integer.parseInt(fields.getOrDefault("r", "200"));
                    int g = Integer.parseInt(fields.getOrDefault("g", "200"));
                    int b = Integer.parseInt(fields.getOrDefault("b", "200"));
                    P_dto.setColor(new Color(r, g, b));

                    P_dto.setKey(fields.getOrDefault("key", "F1"));
                } catch (Exception e) {
                    e.printStackTrace(); // 필드 하나라도 잘못되면 로그 찍고 넘어감
                }
                panels.add(P_dto); // 리스트에 추가
            }

        } catch (IOException e) {
            e.printStackTrace(); // 파일 로딩 실패 시 로그
        }

        return panels; // 최종 반환
    }
}
