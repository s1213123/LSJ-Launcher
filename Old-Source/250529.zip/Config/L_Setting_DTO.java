package Config;

import java.awt.Color;

public class L_Setting_DTO {
   
        private String name;
        private int posX, posY;
        private int sizeW, sizeH;
        private int moveX, moveY;
        private Color avatarColor;
        private String imagePath;
        private String defaultMessage;
        private int speechHeight;
        
        private int experience;
        private int evolutionThreshold;
        private int decayRate;   
        private String avatarType;
        
        public L_Setting_DTO() {
            this.name = "Lucifer";
            this.posX = 0;
            this.posY = 0;
            this.sizeW = 300;
            this.sizeH = 300;
            this.moveX = 0;
            this.moveY = 0;
            this.avatarColor = new Color(200, 200, 200);
            this.imagePath = "resources/avatar/lucifer1.png";
            this.defaultMessage = "안녕, 나는 루시퍼야!";
            
            
            
            this.experience = 0;
            this.evolutionThreshold = 50;
            this.decayRate = 1; 
            this.avatarType = "portal";
   
        }

        // Getters and Setters
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

        public int getPosX() { return posX; }
        public void setPosX(int posX) { this.posX = posX; }

        public int getPosY() { return posY; }
        public void setPosY(int posY) { this.posY = posY; }

        public int getSizeW() { return sizeW; }
        public void setSizeW(int sizeW) { this.sizeW = sizeW; }

        public int getSizeH() { return sizeH; }
        public void setSizeH(int sizeH) { this.sizeH = sizeH; }

        public int getMoveX() { return moveX; }
        public void setMoveX(int moveX) { this.moveX = moveX; }

        public int getMoveY() { return moveY; }
        public void setMoveY(int moveY) { this.moveY = moveY; }

        public Color getAvatarColor() { return avatarColor; }
        public void setAvatarColor(Color avatarColor) { this.avatarColor = avatarColor; }

        public String getImagePath() { return imagePath; }
        public void setImagePath(String imagePath) { this.imagePath = imagePath; }

        public String getDefaultMessage() { return defaultMessage; }
        public void setDefaultMessage(String defaultMessage) { this.defaultMessage = defaultMessage; }
        

        public int getSpeechHeight() { return speechHeight; }

        public void setSpeechHeight(int speechHeight) { this.speechHeight = speechHeight; }
        
        
        public int getExperience() { return experience; }
        public void setExperience(int experience) { this.experience = experience; }

        public int getEvolutionThreshold() { return evolutionThreshold; }
        public void setEvolutionThreshold(int evolutionThreshold) { this.evolutionThreshold = evolutionThreshold; }

        public int getDecayRate() { return decayRate; }
        public void setDecayRate(int decayRate) { this.decayRate = decayRate; }


        public String getAvatarType() { return avatarType; }
        public void setAvatarType(String type) { this.avatarType = type; }
    

}


