package Config;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;


public class Lucid_Loader {

    public static L_Setting_DTO loadFromFile(String filePath) {
        L_Setting_DTO dto = new L_Setting_DTO();
        Properties props = new Properties();

        
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            props.load(reader);

            dto.setName(props.getProperty("name", "Lucifer"));
            dto.setPosX(Integer.parseInt(props.getProperty("posX", "0")));
            dto.setPosY(Integer.parseInt(props.getProperty("posY", "0")));
            dto.setSizeW(Integer.parseInt(props.getProperty("sizeW", "300")));
            dto.setSizeH(Integer.parseInt(props.getProperty("sizeH", "300")));
            dto.setMoveX(Integer.parseInt(props.getProperty("moveX", "0")));
            dto.setMoveY(Integer.parseInt(props.getProperty("moveY", "0")));
            dto.setAvatarColor(Color.decode(props.getProperty("avatarColor", "#C8C8C8")));
            dto.setImagePath(props.getProperty("imagePath", "resources/avatar/lucifer1.png"));
            dto.setDefaultMessage(props.getProperty("defaultMessage", "안녕, 나는 루시퍼야!"));
            dto.setSpeechHeight(Integer.parseInt(props.getProperty("speechHeight", "30")));

            dto.setExperience(Integer.parseInt(props.getProperty("experience", "0")));
            dto.setEvolutionThreshold(Integer.parseInt(props.getProperty("evolutionThreshold", "50")));
            dto.setDecayRate(Integer.parseInt(props.getProperty("decayRate", "1")));

            dto.setAvatarType(props.getProperty("avatarType", "portal")); 

        } catch (IOException | NumberFormatException e) {
            System.err.println("⚠️ 설정 파일 읽기 오류: " + e.getMessage());
        }

        return dto;
    }
    
    public static M_Setting_DTO loadSetting(String filePath) {
        M_Setting_DTO dto = new M_Setting_DTO();
        Properties prop = new Properties();

        try (InputStream input = new FileInputStream(filePath)) {
            prop.load(new InputStreamReader(input, "UTF-8"));

            dto.setTitle(prop.getProperty("title", "기본 타이틀"));
            dto.setButton(0, prop.getProperty("btn1", "버튼1"));
            dto.setButton(1, prop.getProperty("btn2", "버튼2"));
            dto.setButton(2, prop.getProperty("btn3", "버튼3"));
            dto.setButton(3, prop.getProperty("btn4", "버튼4"));
            dto.setColor(prop.getProperty("color", "#000000"));
            dto.setFont(prop.getProperty("font", "SansSerif"));
            dto.setFontsize(Integer.parseInt(prop.getProperty("fontsize", "14")));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return dto;
    }
    
    
}
