package Config;

public class M_Setting_DTO {
    private String title;
    private String[] buttons = new String[4];
    private String color;
    private String font;
    private int fontsize;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String[] getButtons() {
        return buttons;
    }

    public void setButton(int index, String text) {
        if (index >= 0 && index < 4) {
            this.buttons[index] = text;
        }
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getFont() {
        return font;
    }

    public void setFont(String font) {
        this.font = font;
    }

    public int getFontsize() {
        return fontsize;
    }

    public void setFontsize(int fontsize) {
        this.fontsize = fontsize;
    }
}
