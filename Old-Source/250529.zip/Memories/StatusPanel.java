package Memories;

import java.awt.BorderLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class StatusPanel extends JPanel {
    public StatusPanel() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createTitledBorder("상태 보기"));
        add(new JLabel("상태 정보 출력 영역"), BorderLayout.CENTER);
    }
}