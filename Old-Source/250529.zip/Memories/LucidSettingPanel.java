package Memories;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.*;

public class LucidSettingPanel extends JPanel {
    private JTextArea settingArea;
    private JButton saveButton;
    private JButton loadButton;
    private final String settingFilePath = "data/settings.txt";

    public LucidSettingPanel() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createTitledBorder("환경 설정"));
        setBackground(new Color(230, 240, 255)); // 연파랑 배경

        settingArea = new JTextArea(10, 40);
        JScrollPane scrollPane = new JScrollPane(settingArea);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setOpaque(false);

        saveButton = new JButton("저장");
        loadButton = new JButton("불러오기");

        saveButton.addActionListener(e -> saveSettings());
        loadButton.addActionListener(e -> loadSettings());

        buttonPanel.add(loadButton);
        buttonPanel.add(saveButton);

        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        loadSettings(); // 시작 시 자동 로딩
    }

    private void saveSettings() {
        try {
            Files.createDirectories(Paths.get("data"));
            Files.write(Paths.get(settingFilePath), settingArea.getText().getBytes());
            JOptionPane.showMessageDialog(this, "설정이 저장되었습니다.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "저장 실패: " + ex.getMessage());
        }
    }

    private void loadSettings() {
        try {
            if (Files.exists(Paths.get(settingFilePath))) {
                String content = new String(Files.readAllBytes(Paths.get(settingFilePath)));
                settingArea.setText(content);
            } else {
                settingArea.setText("# 여기에 설정을 입력하세요\n# 예시: launch_on_start=true");
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "불러오기 실패: " + ex.getMessage());
        }
    }
}
