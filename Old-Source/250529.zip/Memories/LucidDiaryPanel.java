package Memories;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LucidDiaryPanel extends JPanel {
    private JTextArea diaryArea;
    private JButton saveButton;
    private JButton loadButton;
    private final String diaryPath = "data/diary.txt";

    public LucidDiaryPanel() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createTitledBorder("루시드 일기장"));
        setBackground(new Color(255, 250, 235)); // 베이지톤 배경

        diaryArea = new JTextArea(8, 40);
        diaryArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(diaryArea);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setOpaque(false);

        saveButton = new JButton("저장");
        loadButton = new JButton("불러오기");

        saveButton.addActionListener(e -> saveDiary());
        loadButton.addActionListener(e -> loadDiary());

        buttonPanel.add(loadButton);
        buttonPanel.add(saveButton);

        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        loadDiary(); // 자동 불러오기
    }

    private void saveDiary() {
        try {
            Files.createDirectories(Paths.get("data"));
            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date());
            String content = "[" + timestamp + "]\n" + diaryArea.getText() + "\n\n";
            Files.write(Paths.get(diaryPath), content.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            JOptionPane.showMessageDialog(this, "일기가 저장되었습니다.");
            diaryArea.setText("");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "저장 실패: " + ex.getMessage());
        }
    }

    private void loadDiary() {
        try {
            if (Files.exists(Paths.get(diaryPath))) {
                String content = new String(Files.readAllBytes(Paths.get(diaryPath)));
                diaryArea.setText(content);
            } else {
                diaryArea.setText("# 여기에 당신의 하루를 남겨보세요.");
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "불러오기 실패: " + ex.getMessage());
        }
    }
}
