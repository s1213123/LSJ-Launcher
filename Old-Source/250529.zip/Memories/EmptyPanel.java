
package Memories;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class EmptyPanel extends JPanel {
    public EmptyPanel() {
        Map<String, String> settings = loadSettings("Config/panel_setting.txt");

        int width = parseOrDefault(settings.get("width"), 280);
        int height = parseOrDefault(settings.get("height"), 140);
        int red = parseOrDefault(settings.get("red"), 220);
        int green = parseOrDefault(settings.get("green"), 220);
        int blue = parseOrDefault(settings.get("blue"), 220);

        /*
        // 경로 테스트 코드
        File f = new File("Config/panel_setting.txt");
        System.out.println("파일 존재 여부: " + f.exists());
        System.out.println("절대 경로: " + f.getAbsolutePath());
        //
        */
        setBackground(new Color(red, green, blue));
        setPreferredSize(new Dimension(width, height));
        setBorder(BorderFactory.createTitledBorder("LSJ Empty 패널"));
        setLayout(new BorderLayout());
        add(new JLabel("empty_panel.txt 설정 기반입니다."), BorderLayout.CENTER);

        // 마우스 드래그 이동 기능 포함
        MouseAdapter dragger = new MouseAdapter() {
            Point offset = null;

            public void mousePressed(MouseEvent e) {
                offset = e.getPoint();
            }

            public void mouseDragged(MouseEvent e) {
                Point location = getLocation();
                int newX = location.x + e.getX() - offset.x;
                int newY = location.y + e.getY() - offset.y;
                setLocation(newX, newY);
            }
        };
        addMouseListener(dragger);
        addMouseMotionListener(dragger);
    }
    private Map<String, String> loadSettings(String path) {
        Map<String, String> map = new HashMap<>();
        File file = new File(path);

       /* if (!file.exists()) {
            try {
                // 폴더 먼저 생성
                file.getParentFile().mkdirs();

                // 파일 생성
                PrintWriter writer = new PrintWriter(file);
                writer.println("x=600");
                writer.println("y=400");
                writer.println("width=280");
                writer.println("height=140");
                writer.println("red=220");
                writer.println("green=220");
                writer.println("blue=220");
                writer.close();

                System.out.println("🟢 설정 파일 자동 생성 완료: " + file.getAbsolutePath());

            } catch (IOException e) {
                System.out.println("❌ 설정 파일 생성 실패: " + e.getMessage());
            }
        }*/

        // 설정값 읽기 시도
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.contains("=")) {
                    String[] parts = line.split("=");
                    if (parts.length == 2)
                        map.put(parts[0].trim(), parts[1].trim());
                }
            }
        } catch (IOException e) {
            System.out.println("❌ 설정 파일 읽기 실패: " + e.getMessage());
        }

        return map;
    }
    private int parseOrDefault(String value, int defaultVal) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return defaultVal;
        }
    }
}
