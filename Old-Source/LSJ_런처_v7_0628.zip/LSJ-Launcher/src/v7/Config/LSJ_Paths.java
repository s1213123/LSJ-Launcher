package v7.Config;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class LSJ_Paths {

    
	
	

    
	// 경로 설정
	public static final String BASE_PATH = Paths.get("LucidSystem").toAbsolutePath().toString();
	
    // 하위 디렉터리
    public static final String APP_PATH  = BASE_PATH + "/APP/";
    public static final String TXT_PATH  = BASE_PATH + "/DIARY/";
    public static final String PNG_PATH  = BASE_PATH + "/IMAGES/";
    public static final String TEMP_PATH = BASE_PATH + "/TEMP/";
	
    // 초기화 함수
    public static void initPaths() {
        try {
            Files.createDirectories(Paths.get(APP_PATH));
            Files.createDirectories(Paths.get(TXT_PATH));
            Files.createDirectories(Paths.get(PNG_PATH));
            Files.createDirectories(Paths.get(TEMP_PATH));
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    
        
    }
    // menu.ini 생성
    public static void make_Menu_ini(){
    Path make_txt_Path = Paths.get(BASE_PATH + "/menu.ini");
    if (Files.notExists(make_txt_Path)) {
        try {
            List<String> lines = Arrays.asList(
                "LSJ 런처, LSJ_Frame, LSJ_Launcher",
                "Nova 다이어리 , LSJ_Frame, Nova_Diary",
                "Weaver 캔버스, LSJ_Frame, Weaver_Canvas",
                "LSJ 뷰어, LSJ_Frame, LSJ_Viewer",
                "루시퍼 컨트롤, LSJ_Frame, Control_L",
                "환경 설정, LSJ_Frame, LSJ_Status"
            );
            Files.write(make_txt_Path, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE);
            System.out.println("✅ menu.ini 파일 생성 완료: " + make_txt_Path.toString());
        } catch (IOException e) {
            System.err.println("❌ menu.ini 생성 실패: " + e.getMessage());
        	}
    	}
    }

    // registry.ini 생성
    public static void make_Registry_ini(){
    Path make_txt_Path = Paths.get(BASE_PATH + "/registry.ini");
    if (Files.notExists(make_txt_Path)) {
        try {
            List<String> lines = Arrays.asList(
                "LSJ 런처, LSJ_Frame, LSJ_Launcher",
                "Nova 다이어리 , LSJ_Frame, Nova_Diary",
                "Weaver 캔버스, LSJ_Frame, Weaver_Canvas",
                "LSJ 뷰어 , LSJ_Frame, LSJ_Viewer",
                "루시퍼 컨트롤, LSJ_Frame, Control_L",
                "환경 설정, LSJ_Frame, LSJ_Status"
            );
            Files.write(make_txt_Path, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE);
            System.out.println("✅ registry.ini 파일 생성 완료: " + make_txt_Path.toString());
        } catch (IOException e) {
            System.err.println("❌ registry.ini 생성 실패: " + e.getMessage());
        	}
    	}
    }
	
	

    // 공통 파서    
    public static class Parser {

    	
    	public List<String[]> loadList(String path) {
    	    List<String[]> list = new ArrayList<>();

    	    try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
    	        String line;
    	        while ((line = reader.readLine()) != null) {
    	            line = line.trim();
    	            if (line.isEmpty() || line.startsWith("#") || line.startsWith("//")) continue;

    	            String[] parts = line.split("[,.=]", 3);
    	            if (parts.length == 3) {
    	                list.add(new String[] {
    	                    parts[0].trim(), // name
    	                    parts[1].trim(), // type
    	                    parts[2].trim()  // action
    	                    
    	                });
    	                
    	            }
    	        }
    	    } catch (IOException e) {
    	        System.err.println("❌ 파일 읽기 실패: " + e.getMessage());
    	    }
    	   
    	    return list;
    	}   
    	
    	
    }



    //// 메뉴 DTO
    
    public static class M {


        public String name;
        public String type;
        public String action;

        public M(String name, String type, String action) {
            this.name = name;
            this.type = type;
            this.action = action;
        }
      
        // 메뉴 파싱, 네임, 타입, 액션 순
        
        public static List<M> Menu_Parser() {
            List<M> items = new ArrayList<>();
         
            Parser parser = new Parser();  // 공통 파서 사용

            List<String[]> raw = parser.loadList(BASE_PATH + "/menu.ini");

            for (String[] entry : raw) {
                if (entry.length == 3) {
                    items.add(new M(entry[0], entry[1], entry[2]));
                }
            }

            return items;
        }
      
    }



}
