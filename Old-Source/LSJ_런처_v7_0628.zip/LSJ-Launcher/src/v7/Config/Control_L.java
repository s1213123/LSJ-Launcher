package v7.Config;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JPanel;

import v7.Avatars.Lucifer_C;
import v7.Avatars.Lucifer_F1;
import v7.Avatars.Lucifer_F2;

public class Control_L extends JPanel {

    private Lucifer_C lucifer;

    public Control_L() {
        this.lucifer = Registry.globalLucifer;
        setLayout(new GridLayout(0, 1, 10, 10));

        // 💬 말풍선 On/Off 버튼
        JButton toggleSpeech = new JButton("💬 말풍선 On/Off");
        toggleSpeech.addActionListener(e -> {
            boolean next = !Registry.ShowSpeechLabel;
            Registry.ShowSpeechLabel = next;
            if (lucifer != null) lucifer.Show_SpeechLabel(next);
        });

        // ⏰ 시계 On/Off 버튼
        JButton toggleInput = new JButton("⏰ 시계 On/Off");
        toggleInput.addActionListener(e -> {
            boolean next = !Registry.ShowInputLabel;
            Registry.ShowInputLabel = next;
            if (lucifer != null) lucifer.Show_InputLabel(next);
        });

        // ▶ 루시퍼 시작
        JButton startButton = new JButton("▶ 루시퍼 시작");
        startButton.addActionListener(e -> Lucifer_F1.Lucifer_Start());

        // ⏸ 루시퍼 정지
        JButton stopButton = new JButton("⏸ 루시퍼 정지");
        stopButton.addActionListener(e -> Lucifer_F1.Lucifer_Stop());

        // 🐢 느리게 이동
        JButton slowButton = new JButton("🐢 느리게 이동");
        slowButton.addActionListener(e -> Lucifer_F1.SetSpeed(lucifer, 2, 0));

        // 🐇 빠르게 이동
        JButton fastButton = new JButton("🐇 빠르게 이동");
        fastButton.addActionListener(e -> Lucifer_F1.SetSpeed(lucifer, 10, 0));

    
        // 색상 모드
     
        JButton toggleColorButton = new JButton("색상 모드");
        add(toggleColorButton);

        toggleColorButton.addActionListener(e -> {
            Lucifer_C.colorModeListenerAttached = !Lucifer_C.colorModeListenerAttached;
            //Lucifer_C.repaint();
            Lucifer_F1.Lucifer_ColorMode1(lucifer, Lucifer_C.colorModeListenerAttached, 3);
        });

       /* JButton redButton = new JButton("레드");
        redButton.addActionListener(e -> {
            Lucifer_F1.setColorIndex(lucifer, 0); // 예: 0 = red
        });
        add(redButton);*/


        // 🖼 루시퍼 이미지 선택
        JButton imageButton = new JButton("🖼 이미지 선택");
        imageButton.addActionListener(e -> Lucifer_F2.ChangeImage(lucifer, this));

        // ❌ 닫기
        JButton closeButton = new JButton("❌ 닫기");
        closeButton.addActionListener(e -> {
        	 java.awt.Window window = javax.swing.SwingUtilities.getWindowAncestor(this);
        	    if (window != null) window.dispose();
        });

        add(toggleSpeech);
        add(toggleInput);
        add(startButton);
        add(stopButton);
        add(slowButton);
        add(fastButton);
        add(imageButton);
        add(closeButton);
    }
    
    
}
