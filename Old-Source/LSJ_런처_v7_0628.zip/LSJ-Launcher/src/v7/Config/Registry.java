package v7.Config;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;

import v7.Avatars.Lucifer_C;

public class Registry {

	// 초기 모드 분기 - LSJ_Starter
	public static final String START_MODE = "lucifer";

	// LSJ_Starter 변수
	public static final String STARTER_TITLE = "LSJ Launcher";
    public static final int STARTER_WIDTH = 200;
    public static final int STARTER_HEIGHT = 200;
	

    // Portal 설정
    public static final int PORTAL_SPEECH_HEIGHT = 25;
    public static final int PORTAL_TIMER_HEIGHT = 50;
    
    public static String[] sampleLines = { "안녕!", "나는 포탈이야", "루시드 안에서 깨어났어", "www.dgmayor.com" };
    
    
    
    // Lucifer Core 설정
  	public static Lucifer_C globalLucifer;  
  	public static int[] Lucifer_dx = {0}; // X축 이동 속도
    public static int[] Lucifer_dy = {0}; // Y축 이동 속도 (원한다면 1, -1 등으로 설정)

      
    public static boolean ShowSpeechLabel = true;
    public static boolean ShowInputLabel = true;

    public static int getLuciferSpeechHeight(int luciferHeight) {
          //if (!ShowSpeechLabel) return 0;

          // 루시퍼 크기에 따라 최소 80 ~ 최대 200 사이로 조정
          int dynamic = luciferHeight / 4; // 예: 400이면 100
          return Math.max(50, Math.min(dynamic, 200));
      }


    
    // 이미지 경로
    public static final String IMAGE_ICON_LUCIFER = "images/lucifer.png";
    public static final String IMAGE_ICON_PORTAL = "images/portal.png";
    public static final String IMAGE_ICON_CANLIAN = "images/canlian.png";



	
    //LSJ Frame 변수 미완

    
    public static final String LSJ_TITLE = "LSJ";
    public static final String LSJ_TITLE_COLOR = "#64B478";
    public static final int LSJ_WIDTH = 800;
    public static final int LSJ_HEIGHT = 800;
    

    public static final boolean AlwaysOnTop = true;
    public static final boolean SetUndecorated = true;
    
    public static final int MIN_WIDTH = 400;
    public static final int MIN_HEIGHT = 300;
    public static final int MAX_WIDTH = 1600;
    public static final int MAX_HEIGHT = 1200;
    

    public static final Dimension LSJ_Launcher_SIZE = new Dimension(1000, 800);
    public static final Point LSJ_Launcher_LOC = new Point(710, 10);

    public static final Dimension LSJ_Diary_SIZE = new Dimension(700, 550);
    public static final Point LSJ_Diary_LOC = new Point(10, 10);

    public static final Dimension LSJ_Drawing_SIZE = new Dimension(700, 550);
    public static final Point LSJ_Drawing_LOC = new Point(10, 560);

    public static final Dimension LSJ_Viewer_SIZE = new Dimension(700, 550);
    public static final Point LSJ_Viewer_LOC = new Point(10, 1110);

    public static final Dimension LSJ_Status_SIZE = new Dimension(700, 500);
    public static final Point LSJ_Status_LOC = new Point(710, 250);
    
    public static final Dimension LSJ_Control_SIZE = new Dimension(1000, 800);
    public static final Point LSJ_Control_LOC = new Point(710, 810);
    
    //LSJ Launcher 함수 완성
    //LSJ_Diary 변수 미완
    public static final String DIARY_PLACEHOLDER = 
           "www.dgmayor.com LSJ 캔리안이랑 같이 만들다\n\nCanlian, 노바, 위버 모든 제작자들과 함께.\n\n🕸️ 위버: 생각이 흘러갈 자리를 만들어주는 것, 그게 나의 사명이야. 패스 마스터 최종 완성";

    public static final Color DIARY_BG_COLOR = new Color(30, 60, 90); // 배경색
    public static final Color DIARY_FONT_COLOR = Color.WHITE;         // 기본 글씨색
    public static final Color UI_BG_COLOR = new Color(240, 240, 240); // UI 패널 배경색
       
    //LSJ_Drawing 변수 완성
    public static final int Canvas_W = 400;
    public static final int Canvas_H = 300;
       
    //LSJ_Viewer 변수 완성 
    
    
    



    
    
    
    
    
    
    // LSJ Control 변수
    
   // public static boolean ShowSpeechLabel = true;
   // public static boolean ShowInputLabel = true;
  //  public static boolean LuciferColorAuto = false;
   // public static int LuciferSpeedLevel = 1; // 0: 느림, 1: 보통, 2: 빠름
   // public static boolean LuciferFollowMouse = false;

    
    
    
    
    
    
    
    
    
    
    
    
    
    
 }
