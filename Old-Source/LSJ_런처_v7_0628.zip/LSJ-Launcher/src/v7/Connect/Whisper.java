package v7.Connect;

import java.awt.Component;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import v7.Config.LSJ_Paths;
import v7.Config.Registry;
import v7.Dimensions.LSJ_Frame.LSJ_Frame;

public class Whisper extends JPanel {

    private JPopupMenu popupMenu; // 우클릭 팝업 메뉴
    private List<LSJ_Paths.M> menu_parser = LSJ_Paths.M.Menu_Parser(); // 메뉴 항목 리스트
    //private final Map<String, Runnable> commandMap = new HashMap<>();
    private LSJ_Paths.M selectedItem; // 현재 선택된 항목


    
    // ✅ 메뉴를 생성하고 화면에 표시
    public void function(Component parent, int x, int y) {
        popupMenu = new JPopupMenu("루시퍼 메뉴");
        popupMenu.removeAll();

        
        for (LSJ_Paths.M item : menu_parser) {
            JMenuItem m = new JMenuItem(item.name);
            m.addActionListener(e -> OpenByText(item)); // 클릭 시 선택 처리
            popupMenu.add(m);
        }

        popupMenu.show(parent, x, y);
        
    }

    
 // ✅ 명령 실행 진입점
    private void OpenByText(LSJ_Paths.M item) {
        this.selectedItem = item;

        System.out.println("▶ [" + getClass().getSimpleName() + "] " + item.name + " | " + item.type + " | " + item.action);


        JFrame frame = null;

        if ("LSJ_Frame".equals(item.type)) {
            frame = new LSJ_Frame(item.action); // action 전달
        }
        if ("Lucid_Frame".equals(item.type)) {
            frame = new LSJ_Frame(item.action); // action 전달
        }
        if ("Earth_Frame".equals(item.type)) {
            frame = new LSJ_Frame(item.action); // action 전달
        }

        if (frame != null) {
            frame.setVisible(true);
        }
    }
        
    /*
 // (선택) URL 열기 - 나중에
    private void openURL(String url) {
        try {
            java.awt.Desktop.getDesktop().browse(new java.net.URI(url));
        } catch (Exception e) {
            System.out.println("🌐 URL 열기 실패: " + url);
        }
        
    */
    
    // ✅ 생성자: 메뉴 파서와 명령 등록
    public Whisper() {
   

        
        Whisper_Debug();
    }


    
    
    private void Whisper_Debug(){

        System.err.println("AvatarCall_C 클래스 호출");
        
        // 앞으로 작업 목록
        // openURL 구현
        // jpanel 버튼 기반으로 전환
    }
}