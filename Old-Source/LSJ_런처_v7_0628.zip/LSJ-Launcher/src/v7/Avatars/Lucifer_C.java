package v7.Avatars;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.Timer;

import v7.Config.Registry;

/**
 * 루시퍼 코어 클래스 이미지 출력 및 기본 구조 설정
 */
public class Lucifer_C extends Portal {

	//public static Lucifer_Core instance;
	
	
	protected JFrame parentFrame;
	protected static BufferedImage luciferImage;
	
	 // 루시퍼 이미지
    protected int imgW = Registry.STARTER_WIDTH;
    protected int imgH = Registry.STARTER_HEIGHT;

    protected int speechHeight = Registry.getLuciferSpeechHeight(imgH);

    protected String srcPath = Registry.IMAGE_ICON_LUCIFER;
    // 이미지 추가 필요....
    

	protected static Timer moveTimer;
	protected static boolean isMoving = true;
    protected boolean isFlipped = false;
    
    
    
    protected int[] dx = Registry.Lucifer_dx;
    protected int[] dy = Registry.Lucifer_dy;

   // boolean showSpeechLabel = Registry.ShowSpeechLabel;
    //boolean showInputLabel = Registry.ShowInputLabel;



	public static boolean colorModeListenerAttached = true;

	 
    
    
	
	/**
	 * 루시퍼 코어 생성자
	 * 
	 * @param parentFrame
	 *            루시퍼가 속하는 외부 JFrame (위치 제어 등 활용)
	 */
	public Lucifer_C(JFrame parentFrame) {
		super(parentFrame);
		this.parentFrame = parentFrame;

		// Lucifer_Core.java 생성자 내부
		Registry.globalLucifer = this;

		
		Evolution();
		// ✅ 루시퍼 이미지 로딩
		Lucifer_Imageloading(srcPath);
		
		
		
		
		
		Show_InputLabel(Registry.ShowInputLabel);
		Show_SpeechLabel(Registry.ShowSpeechLabel);
		
		Lucifer_Move();
		
		
		Lucifer_Wheel_Resize1();
		
		Lucifer_F1.Lucifer_AddMouse(this);
		Lucifer_F1.Lucifer_Transparency(this);
		Lucifer_F1.SetSpeed(this, 2, 0);
		
		
		
	      Lucifer_F1.Lucifer_ColorMode1(this, Lucifer_C.colorModeListenerAttached, 1);
		
		 //Lucifer_F1.Lucifer_ColorMode1(this);
	



		
		// ✅ 레이아웃 설정
		setLayout(null);
	
		
	}

	

/*	
	*//**
	 * 루시퍼 이미지 직접 출력 (BufferedImage 기반) 
	 * @param g 그래픽 컨텍스트
	 */

	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (luciferImage != null) {
				
			if (isFlipped) {
			    g.drawImage(luciferImage, imgW, speechHeight, -imgW, imgH, this);
			} else {
			    g.drawImage(luciferImage, 0, speechHeight, imgW, imgH, this);
			}

			
		}
	}

	// 캔리안 소환
	public void Evolution() {

		//Canlian speechPanel = new Canlian("src/resources/speech_data.json");
		//speechPanel.setBounds(0, 0, Registry.SPEECH_WIDTH, Registry.SPEECH_HEIGHT); // 말풍선 위치 조정
		//add(speechPanel);

		// ✅ AvatarCore 기본 라벨 숨김 처리
		if (imageLabel != null)
			imageLabel.setVisible(false);
		if (speechLabel != null)
			speechLabel.setVisible(false);
		if (inputLabel != null)
			inputLabel.setVisible(false);	
	}
	
	private void Lucifer_Imageloading(String srcPath){
	
		//srcPath = "images/lucifer.png";
		// URL url = Registry.class.getResource(jarPath);
		try {
		    URL imageUrl = getClass().getClassLoader().getResource(srcPath);
		    if (imageUrl != null) {
		        luciferImage = ImageIO.read(imageUrl);
		    } else {
		        File fallback = new File("src/resources/" + srcPath);
		        if (fallback.exists()) {
		            luciferImage = ImageIO.read(fallback);
		        } else {
		            System.err.println("❌ 루시퍼 이미지 경로 실패 (resource & fallback 모두 실패)" + srcPath);
		        }
		    }
		    
		    if (luciferImage != null) {

		    	//	imgW = luciferImage.getWidth();
		    	//	imgH = luciferImage.getHeight();
		    	
		    	speechHeight = Registry.getLuciferSpeechHeight(imgH);
				
		    	
			   	Show_SpeechLabel(Registry.ShowSpeechLabel);
				Show_InputLabel(Registry.ShowInputLabel);
		    	
		    	
		        int totalH = imgH + speechHeight;
			    
			    parentFrame.setSize(imgW, totalH);
			    setPreferredSize(new Dimension(imgW, totalH));
			    parentFrame.revalidate();
		    }
		    
		    
		} catch (Exception e) {
		    System.err.println("❌ 루시퍼 이미지 로딩 실패");
		    e.printStackTrace();
		}
	}
	
	

	// 루시퍼 크기 조정  휠 사이즈 1
	protected void Lucifer_Wheel_Resize1(){
		addMouseWheelListener(e -> {
			int delta = (e.getWheelRotation() < 0) ? 10 : -10;
			Lucifer_Wheel_Resize2(delta);
		});
		
	}
	
	
	// 루시퍼 크기 조정 휠 사이즈 2
	protected void Lucifer_Wheel_Resize2(int delta){
		
		if (luciferImage == null) return;

		speechHeight = Registry.getLuciferSpeechHeight(imgH);

	    imgW = Math.max(150, imgW + delta);
	    imgH = Math.max(150, imgH + delta);  // 비율 동기화 or 따로도 가능


	    int totalH = imgH + speechHeight;
	    
	    parentFrame.setSize(imgW, totalH);
	    setPreferredSize(new Dimension(imgW, totalH));
	    parentFrame.revalidate();

		Show_SpeechLabel(Registry.ShowSpeechLabel);
		Show_InputLabel(Registry.ShowInputLabel);
	    
		repaint();
	}
	
	
	
	// 루시퍼 이동 함수
	private void Lucifer_Move() {
	    moveTimer = new Timer(30, null); // 30ms 간격

	    moveTimer.addActionListener(e -> {
	        if (!isMoving || luciferImage == null || parentFrame == null) return;

	        Point current = parentFrame.getLocation();
	        int newX = current.x + dx[0];
	        int newY = current.y + dy[0];

	        // 화면 경계 체크 (X)
	        int screenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
	        int frameWidth = parentFrame.getWidth();
	        if (newX < 0 || newX + frameWidth > screenWidth) {
	            dx[0] = -dx[0]; // X 방향 반전
	            Lucifer_Flip();
	        }

	        // 화면 경계 체크 (Y) - 선택사항
	        int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
	        int frameHeight = parentFrame.getHeight();
	        if (newY < 0 || newY + frameHeight > screenHeight) {
	            dy[0] = -dy[0]; // Y 방향 반전 (선택)
	        }

	        parentFrame.setLocation(newX, newY); // X + Y 이동
	    });

	    moveTimer.start();
	    isMoving = true;
	}



	public void Lucifer_Flip() {
	    isFlipped = !isFlipped;
	    repaint();
	}
	


	
	
	
	
	// 스피치 및 인풋 라벨만 재 사용
	 // ✨ 스피치 및 인풋 라벨 위치 + 라운딩 영역 계산 처리
    public void Show_SpeechLabel(Boolean showSpeechLabel) {
        if (speechLabel != null) {
           
        	
            int SPEECH_W = imgW * 10 /10;
            int SPEECH_H = speechHeight;
            
            //speechLabel.setBounds(imgW / 20, 0, SPEECH_W, SPEECH_H);
            speechLabel.setBounds(0, 0, SPEECH_W, SPEECH_H);

            speechLabel.setOpaque(true);
            speechLabel.setBackground(new Color(255, 255, 255, 200));
    
            
            //speechLabel.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 255, 128), 2, true));
            speechLabel.setVisible(showSpeechLabel);
            speechLabel.repaint();
        }
        
    }
    
    public void Show_InputLabel(Boolean showInputLabel) {
        
        if (inputLabel != null) {
        
   
        	   int clockW = imgW * 10 /10;
               int clockH = imgH * 1 / 3;
               int clockX = (imgW - clockW) / 2;
               int clockY = speechHeight + (imgH * 1 / 2);
               
        	// 먼저 이전 라벨 제거
        	remove(inputLabel);
        	
            inputLabel = new JLabel() {
                @Override
                protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                    g2.setColor(new Color(255, 255, 255, 215));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30); // 둥근 모서리
                    super.paintComponent(g2);
                    g2.dispose();
                }
            };
            
      

            int dynamicFontSize = Math.max(20, imgH / 8);
            inputLabel.setFont(new Font("맑은 고딕", Font.BOLD, dynamicFontSize));
            
            inputLabel.setBounds(clockX, clockY, clockW, clockH);
            inputLabel.setHorizontalAlignment(SwingConstants.CENTER);
             
            inputLabel.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 255, 128), 2, true));
            
            // 다시 붙이기
            add(inputLabel);            

             
            inputLabel.setOpaque(false);
     

            inputLabel.setVisible(showInputLabel);
            inputLabel.repaint(); 
        }
    }
	
	

}
