
package v7.Avatars;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import v7.Config.Registry;

public class Lucifer_F1 {


	public static BufferedImage originalImage = null;   

	public static int currentColorIndex = 0;
	public static int clickCount = 0;
	
	
	
	// 최근에 추가
	private static MouseWheelListener colorModeListener;
	
//////오직 루시퍼 색상 모드 1만 //////////////////
	
	/*
	public static void Basic(Lucifer_Core lucifer){

		//// 루시퍼 컬러 모드 1 호출
		Lucifer_AddMouse(lucifer);
		Lucifer_Transparency(lucifer);
		SetSpeed(lucifer, 2, 0);
		Lucifer_ColorMode1(lucifer);
		
		
	}
	*/
	

	// 루시퍼 스타트
	public static void Lucifer_Start() {
		Lucifer_C.isMoving = true;
		if (Lucifer_C.moveTimer != null) Lucifer_C.moveTimer.start();
	}
	
	// 루시퍼 스탑
	public static void Lucifer_Stop() {
		Lucifer_C.isMoving = false;
		if (Lucifer_C.moveTimer != null) Lucifer_C.moveTimer.stop();
	}

	// 루시퍼 SpeechLabel 안 보이기
	public static void Show_Speech(boolean visible) {
	    if (Lucifer_C.speechLabel != null) {
	        Lucifer_C.speechLabel.setVisible(visible);
	    }
	}
	// 루시퍼 inputLabel 안 보이기
	public static void Show_InputLabel(boolean visible) {
	    if (Lucifer_C.inputLabel != null) {
	        Lucifer_C.inputLabel.setVisible(visible);
	    }
	}
	
	public static void SetSpeed(Lucifer_C lucifer, int dx, int dy) {
	    lucifer.dx[0] = dx;
	    lucifer.dy[0] = dy;
	}
	
	// 루시퍼 투명화
	public static void Lucifer_Transparency(Lucifer_C lucifer) {
			lucifer.setOpaque(false);
			lucifer.setBackground(new Color(0, 0, 0, 0));
		}

	
	
	
	// 루시퍼 마우스 이벤트
	public static void Lucifer_AddMouse(Lucifer_C lucifer){
			
	/*		// 마우스 휠로 루시퍼 크기 제어
			lucifer.addMouseWheelListener(e -> {
				int delta = (e.getWheelRotation() < 0) ? 10 : -10;
				lucifer.Lucifer_Resize(delta);
			});
			*/
			// 마우스 버튼으로 루시퍼 정지 및 움직임 명령
			lucifer.addMouseListener(new MouseAdapter() {
			    @Override
			    public void mousePressed(MouseEvent e) {
			        if (SwingUtilities.isLeftMouseButton(e)) {
			            int count = e.getClickCount();

			            if (count == 2) {
			                Lucifer_F1.Lucifer_Start(); // 더블클릭: 이동 시작
			            } else if (count == 1) {
			                Lucifer_F1.Lucifer_Stop(); // 한 번 클릭: 정지
			            
			        } else if (clickCount == 1000) {
			            	JOptionPane.showMessageDialog(
			                        null,
			                        "캔리안, 고마워... by LSJ",
			                        "Lucifer Secret",
			                        JOptionPane.INFORMATION_MESSAGE
			                    );
			                clickCount = 0; // 다시 초기화
			            }
			        } 
			    }
			});
	 
		}
	

	//////////////////////////////////////////

	 // 💬 디버그 정보 출력
   public static void Lucifer_Debug(JComponent comp) {
       // 트레이 매니저
   	System.err.println("루시퍼 패널");
    comp.setBorder(BorderFactory.createLineBorder(Color.RED));
   //    Designs.applyPanelBorder(this, Color.GREEN);
       
   	// 디버깅 이미지 경로 함수
		System.out.println("📂 현재 작업 디렉터리: " + System.getProperty("user.dir"));
		System.out.println("📂 이미지 상대 경로: " + Registry.IMAGE_ICON_LUCIFER);
   }
   
   
   
   
   
   ///////////////////////////////////////////////
   /// 루시퍼 이미지 휠 체인지 배열 변화 1
   /////////////////////////////////////////////////
   
	// 색상 배열 정의
	public static Color[] availableColors = new Color[]{
		new Color(120, 255, 180),  // 민트
	    new Color(255, 128, 180),  // 핑크
	    new Color(140, 185, 215),  // 연하늘
	    new Color(255, 200, 120),  // 살구
	    new Color(120, 255, 180),  // 민트
	    new Color(180, 120, 255),  // 보라
	    new Color(255, 100, 100),   // 레드
	   
	};

	// 루시퍼 컬러 모드 1
   
	/*
	public static void setColorIndex(Lucifer_C lucifer, int colorIndex) {
	    if (originalImage != null) {
	        currentColorIndex = colorIndex % availableColors.length;
	        lucifer.luciferImage = recolorImage(originalImage, availableColors[currentColorIndex]);
	        lucifer.repaint();
	    }
	}
*/
	
	public static void Lucifer_ColorMode1(Lucifer_C lucifer, boolean enabled, int colorIndex) {

	        if (enabled) {
	        	
	            // 🔥 현재 인덱스를 지정된 색상으로 설정 (휠 전에 먼저 적용)
	        	 currentColorIndex = colorIndex % availableColors.length;
	        	 
	        	 // 🔥 원본 이미지가 없을 때만 저장 (처음 진입 시에만)
	        	    if (lucifer.luciferImage != null && originalImage == null) { 
	        	        originalImage = deepCopy(lucifer.luciferImage);
	        	    }
	        	    // 🔥 현재 색상으로 리컬러 적용
	        	    lucifer.luciferImage = recolorImage(originalImage, availableColors[currentColorIndex]);
  
	        	 // 🔥 마우스 휠로 색상 바꿀 수 있는 리스너 생성
	            colorModeListener = e -> {
	                int notches = e.getWheelRotation();
	                if (notches < 0) {
	                    currentColorIndex = (currentColorIndex + 1) % availableColors.length;
	                } else {
	                    currentColorIndex = (currentColorIndex - 1 + availableColors.length) % availableColors.length;
	                }

	                if (originalImage != null) {
	                	  // 🔥 바뀐 색으로 이미지 갱신 (계속 originalImage 기준)
	                    lucifer.luciferImage = recolorImage(originalImage, availableColors[currentColorIndex]);
	                    lucifer.repaint();
	                }
	            };
	            lucifer.addMouseWheelListener(colorModeListener);
	            
	        } else {
	        	 // 🔥 리스너 제거 (모드 OFF)
	            if (colorModeListener != null) {
	                lucifer.removeMouseWheelListener(colorModeListener);
	                colorModeListener = null;
	            }
	            // 🔥 모드 OFF 시 현재 이미지를 그대로 복사해 유지
	            if (originalImage != null) {            
	            	lucifer.luciferImage = deepCopy(lucifer.luciferImage);
	                lucifer.repaint();
	            }
	        }
	    }
	
	
	/*
	public static void Lucifer_ColorMode1(Lucifer_C lucifer){
   	
   	
   	if (lucifer.luciferImage != null) {
           originalImage = deepCopy(lucifer.luciferImage); // 원본 이미지 백업
           lucifer.luciferImage = recolorImage(originalImage, availableColors[currentColorIndex]); // 첫 적용
       }

       lucifer.addMouseWheelListener(e -> {
           int notches = e.getWheelRotation();
           if (notches < 0) {
        	   currentColorIndex = (currentColorIndex + 1) % availableColors.length;
           } else {
        	   currentColorIndex = (currentColorIndex - 1 + availableColors.length) % availableColors.length;
           }

           if (originalImage != null) {
               lucifer.luciferImage = recolorImage(originalImage, availableColors[currentColorIndex]);
               lucifer.repaint();
           }
       }); 	
   }
   
   */
   
   ///// 루시퍼 버퍼링 제거 함수
   public static BufferedImage deepCopy(BufferedImage src) {
       BufferedImage copy = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
       Graphics g = copy.getGraphics();
       g.drawImage(src, 0, 0, null);
       g.dispose();
       return copy;
   }

   //// 루시퍼 색상 유사도 및 재색칠 함수
   
   public static boolean isSimilar(Color c1, Color c2, int threshold) {
       int dr = Math.abs(c1.getRed() - c2.getRed());
       int dg = Math.abs(c1.getGreen() - c2.getGreen());
       int db = Math.abs(c1.getBlue() - c2.getBlue());
       return (dr + dg + db) < threshold;
   }

   public static BufferedImage recolorImage(BufferedImage src, Color newColor) {
       BufferedImage result = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
       Color baseColor = new Color(188, 207, 225);   // 몸통 기준색
       Color tongueColor = new Color(255, 225, 210); // 혀
       Color spikeColor = new Color(30, 40, 60);     // 뿔

       for (int y = 0; y < src.getHeight(); y++) {
           for (int x = 0; x < src.getWidth(); x++) {
               int pixel = src.getRGB(x, y);
               Color c = new Color(pixel, true);
               if (isSimilar(c, baseColor, 90)
                   && !isSimilar(c, tongueColor, 70)
                   && !isSimilar(c, spikeColor, 70)) {
                   int rgba = (newColor.getRGB() & 0x00FFFFFF) | (pixel & 0xFF000000);
                   result.setRGB(x, y, rgba);
               } else {
                   result.setRGB(x, y, pixel);
               }
           }
       }

       return result;
   }


	
	
}
