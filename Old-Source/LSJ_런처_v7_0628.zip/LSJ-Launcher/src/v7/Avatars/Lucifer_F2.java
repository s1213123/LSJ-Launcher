package v7.Avatars;

import java.awt.Component;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class Lucifer_F2 {

	
	

	   /////////////////// 추가 함수 //////////////////////////
	   

	// 루시퍼 이미지 변경 (사용자에게 파일 선택)
	public static void ChangeImage(Lucifer_C lucifer, Component parent) {
	    JFileChooser fileChooser = new JFileChooser();
	    fileChooser.setDialogTitle("루시퍼 이미지 선택");

	    int result = fileChooser.showOpenDialog(parent);
	    if (result == JFileChooser.APPROVE_OPTION) {
	        File selectedFile = fileChooser.getSelectedFile();
	        try {
	            BufferedImage newImage = ImageIO.read(selectedFile);
	            lucifer.luciferImage = newImage;
	            Lucifer_F1.originalImage = Lucifer_F1.deepCopy(newImage); // ✅ 새로운 이미지도 원본으로 저장

	            lucifer.repaint();
	        } catch (IOException e) {
	            JOptionPane.showMessageDialog(null, "이미지 로딩 실패: " + e.getMessage());
	        }
	    }
	}

}
