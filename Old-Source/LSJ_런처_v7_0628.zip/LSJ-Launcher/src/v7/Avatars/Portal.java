package v7.Avatars;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import v7.Config.Designs;
import v7.Config.Registry;
import v7.Connect.Whisper;

public class Portal extends JPanel {

    private static final int WIDTH = Registry.STARTER_WIDTH;
    private static final int HEIGHT = Registry.STARTER_HEIGHT;
    private static final String PORTAL_IMAGE = "/" + Registry.IMAGE_ICON_PORTAL;

    private static final int Speech_Height = Registry.PORTAL_SPEECH_HEIGHT;
    private static final int Timer_Height = Registry.PORTAL_TIMER_HEIGHT;

    protected static JLabel speechLabel;
    protected static JLabel imageLabel;
    protected static JLabel inputLabel;

    private JFrame parentFrame;
    private Whisper avatarCall;
    private Timer clockTimer;

    public Portal(JFrame parentFrame) {
        this.parentFrame = parentFrame;
        this.avatarCall = new Whisper();

        setLayout(null);
        setOpaque(true);

        // 이미지
        imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        imageLabel.setBounds(0, 0, WIDTH, HEIGHT - Timer_Height - Speech_Height);
        
        
        
        // Designs의 함수 사용
        ImageIcon icon = Designs.loadIcon(PORTAL_IMAGE);
        Image scaled = icon.getImage().getScaledInstance(WIDTH, HEIGHT, Image.SCALE_SMOOTH);
        imageLabel.setIcon(new ImageIcon(scaled));
        add(imageLabel);

        // 인풋 및 시계 라벨
        inputLabel = new JLabel();
        inputLabel.setOpaque(true);
        inputLabel.setBackground(Color.WHITE);
        inputLabel.setForeground(Color.BLACK);
        inputLabel.setFont(new Font("맑은 고딕", Font.BOLD, 28));
        inputLabel.setHorizontalAlignment(SwingConstants.CENTER);
        inputLabel.setBounds(0, HEIGHT - Timer_Height - Speech_Height, WIDTH, Timer_Height);
        add(inputLabel);

        // 말풍선 라벨
        String[] sampleLines = Registry.sampleLines;
        int randomIndex = new Random().nextInt(sampleLines.length);
        speechLabel = new JLabel(sampleLines[randomIndex]);
        speechLabel.setOpaque(true);
        speechLabel.setBackground(Color.WHITE);
        speechLabel.setForeground(Color.BLACK);
        speechLabel.setFont(new Font("맑은 고딕", Font.BOLD, 16));
        speechLabel.setHorizontalAlignment(SwingConstants.CENTER);
        speechLabel.setBounds(0, HEIGHT - Speech_Height, WIDTH, Speech_Height);
        add(speechLabel);

        startClock();
        addMouseEvents();
    }

    private void startClock() {
        clockTimer = new Timer(1000, e -> {
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("a hh:mm:ss"); // a = AM/PM
			String time = LocalTime.now().format(formatter);
			inputLabel.setText(time);
            inputLabel.repaint();
        });
        clockTimer.start();
    }

    public void stopClock() {
        if (clockTimer != null) clockTimer.stop();
    }

    public void addMouseEvents() {
        MouseAdapter dragListener = new MouseAdapter() {
            Point dragOffset;

            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    avatarCall.function(e.getComponent(), e.getX(), e.getY());
                }
                dragOffset = e.getPoint();
            }

            public void mouseDragged(MouseEvent e) {
                if (dragOffset != null && parentFrame != null) {
                    Point loc = parentFrame.getLocation();
                    parentFrame.setLocation(loc.x + e.getX() - dragOffset.x, loc.y + e.getY() - dragOffset.y);
                }
            }
        };

        addMouseListener(dragListener);
        addMouseMotionListener(dragListener);
    }
}

