package v7;

public class Test {



/*  
 * 
 *   
   /* // ✍️ UI 구성 요소
    private JButton launchAvatarCore;
    private JButton launchLucifer;
    private JButton lucifer_control;
   // ✅ 버튼 패널 구성

    
    
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
    buttonPanel.setBackground(Color.DARK_GRAY);


    // ✅ AvatarCore_C 실행 버튼
    launchAvatarCore = new JButton("Launch AvatarCore");
    launchAvatarCore.addActionListener(e -> {
        Portal avatarPanel_C = new Portal(this);
        getContentPane().removeAll();
        getContentPane().add(avatarPanel_C);
        revalidate();
        repaint();
    });

    // ✅ Lucifer1 실행 버튼
    launchLucifer = new JButton("Launch Lucifer1");
    launchLucifer.addActionListener(e -> {
        Lucifer luciferPanel = new Lucifer(this);
        getContentPane().removeAll();
        getContentPane().add(luciferPanel);
        revalidate();
        repaint();
    });

    // ✅ Lucifer1 실행 버튼
    lucifer_control = new JButton("Lucifer Control");
    lucifer_control.addActionListener(e -> {
        Lucifer_Control lucifer_control = new Lucifer_Control();
        getContentPane().removeAll();
        getContentPane().add(lucifer_control);
        revalidate();
        repaint();
    });

    
    // ✅ 버튼 패널에 버튼 한 번만 추가
    buttonPanel.add(launchAvatarCore);
    buttonPanel.add(launchLucifer);
    buttonPanel.add(lucifer_control);

    // ✅ 패널 프레임에 한 번만 추가
    add(buttonPanel); // 기본은 CENTER이지만 레이아웃 미지정 시 사용 가능
*/

}
