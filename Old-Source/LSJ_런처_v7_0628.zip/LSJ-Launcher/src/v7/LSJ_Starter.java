package v7;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import v7.Avatars.Lucifer_C;
import v7.Avatars.Portal;
import v7.Config.Designs;
import v7.Config.LSJ_Paths;
import v7.Config.Registry;
import v7.Connect.Canlian;

public class LSJ_Starter extends JFrame {

 
    private String mode;
    
    public LSJ_Starter() {
    	this.mode = Registry.START_MODE;
    	init();
    }
    
    public LSJ_Starter(String overrideMode){
    	this.mode = overrideMode;
    	init();
    }

    
    private void init() {
        setTitle(Registry.STARTER_TITLE);
        setSize(Registry.STARTER_WIDTH, Registry.STARTER_HEIGHT);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel;

        switch (mode) {
            case "portal":
                panel = new Portal(this); break;
            case "lucifer":
            	panel = new Lucifer_C(this); break;
            case "canlian":
            	panel = new Canlian(this); break;
            case "custom":
              //	panel = new Custom(this); break;
            default:
            	 panel = new Portal(this); break;
        }

        getContentPane().add(panel);
   

     
        // ✅ 트레이 등록
        LSJ_Paths.initPaths();
        LSJ_Paths.make_Registry_ini();
        LSJ_Paths.make_Menu_ini();

        Designs.Transparent_Frame(this);
        Designs.registerTray(this);
        

    }

    
    
    public static void main(String[] args) {
        System.setProperty("sun.java2d.uiScale", "1.0");
        SwingUtilities.invokeLater(() -> {
            new LSJ_Starter().setVisible(true);
        });
    }
}


