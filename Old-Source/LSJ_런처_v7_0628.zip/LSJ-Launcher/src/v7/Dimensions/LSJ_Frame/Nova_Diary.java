// LSJ_Diary 리뉴얼 버전: 중앙 텍스트 + 하단 메뉴
package v7.Dimensions.LSJ_Frame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.BorderFactory;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JToggleButton;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.undo.UndoManager;

import v7.Config.Designs;
import v7.Config.LSJ_Paths;
import v7.Config.Registry;

public class Nova_Diary extends JPanel {

    private static final Font TEXT_FONT = Designs.FONT_BODY;
    private static final Insets TEXT_MARGIN = new Insets(20, 20, 20, 20);
    private static final Color BG_COLOR = new Color(30, 60, 90);
    private static final Color TEMP_COLOR = new Color(100, 200, 100);  // 연두색
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
    private static final String TXT_PATH = LSJ_Paths.TXT_PATH;
    private static final String TEMP_PATH = LSJ_Paths.TEMP_PATH;
    private static final String PLACEHOLDER_TEXT = Registry.DIARY_PLACEHOLDER;

    private JTextArea diaryArea;
    private JToggleButton tempBtn;
    private final UndoManager undoManager = new UndoManager();

    public Nova_Diary() {
        setLayout(new BorderLayout());
        setBackground(BG_COLOR);

        setupDiaryArea();
        setupMenuBar();
        setupPopupMenu();
        setupKeyBindings();
    }

    private void setupDiaryArea() {
        diaryArea = new JTextArea(PLACEHOLDER_TEXT);
        diaryArea.setFont(TEXT_FONT);
        diaryArea.setLineWrap(true);
        diaryArea.setWrapStyleWord(true);
        diaryArea.setBackground(BG_COLOR);
        diaryArea.setForeground(Color.WHITE);
        diaryArea.setCaretColor(Color.WHITE);
        diaryArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220), 10),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        diaryArea.getDocument().addUndoableEditListener(undoManager);

        diaryArea.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (diaryArea.getText().equals(PLACEHOLDER_TEXT)) {
                    diaryArea.setText("");
                }
            }
            public void focusLost(FocusEvent e) {
                if (diaryArea.getText().trim().isEmpty()) {
                    diaryArea.setText(PLACEHOLDER_TEXT);
                    diaryArea.setCaretPosition(0);
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(diaryArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        add(scrollPane, BorderLayout.CENTER);
    }

    private void setupPopupMenu() {
        JPopupMenu popup = new JPopupMenu();
        JMenuItem undoItem = new JMenuItem("뒤로 가기");
        JMenuItem cutItem = new JMenuItem("잘라내기");
        JMenuItem copyItem = new JMenuItem("복사");
        JMenuItem pasteItem = new JMenuItem("붙여넣기");

        undoItem.addActionListener(e -> { if (undoManager.canUndo()) undoManager.undo(); });
        cutItem.addActionListener(e -> diaryArea.cut());
        copyItem.addActionListener(e -> diaryArea.copy());
        pasteItem.addActionListener(e -> diaryArea.paste());

        popup.add(undoItem);
        popup.addSeparator();
        popup.add(cutItem);
        popup.add(copyItem);
        popup.add(pasteItem);

        diaryArea.setComponentPopupMenu(popup);
        diaryArea.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    diaryArea.requestFocusInWindow();
                    popup.show(e.getComponent(), e.getX(), e.getY());
                }
            }
            public void mouseReleased(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    diaryArea.requestFocusInWindow();
                    popup.show(e.getComponent(), e.getX(), e.getY());
                }
            }
        });
    }

    private void setupKeyBindings() {
        InputMap im = diaryArea.getInputMap(JComponent.WHEN_FOCUSED);
        ActionMap am = diaryArea.getActionMap();

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_DOWN_MASK), "Undo");
        am.put("Undo", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (undoManager.canUndo()) undoManager.undo();
            }
        });

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_X, InputEvent.CTRL_DOWN_MASK), "Cut");
        am.put("Cut", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { diaryArea.cut(); }
        });

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.CTRL_DOWN_MASK), "Copy");
        am.put("Copy", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { diaryArea.copy(); }
        });

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_V, InputEvent.CTRL_DOWN_MASK), "Paste");
        am.put("Paste", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { diaryArea.paste(); }
        });

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_DOWN_MASK), "TempSave");
        am.put("TempSave", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { tempBtn.doClick(); }
        });
    }

    private void setupMenuBar() {
        JPanel menuPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        menuPanel.setBackground(Color.LIGHT_GRAY);

        JLabel fontLabel = new JLabel("폰트 크기:");
        fontLabel.setFont(TEXT_FONT);
        JComboBox<Integer> fontCombo = new JComboBox<>(new Integer[]{14, 18, 24, 30, 36});
        fontCombo.setFont(TEXT_FONT);
        fontCombo.setSelectedItem(TEXT_FONT.getSize());
        fontCombo.addActionListener(e -> {
            int newSize = (int) fontCombo.getSelectedItem();
            diaryArea.setFont(new Font(TEXT_FONT.getName(), TEXT_FONT.getStyle(), newSize));
        });

        JButton cancelBtn = new JButton("취소");
        cancelBtn.setFont(TEXT_FONT);
        JButton saveBtn = new JButton("저장");
        saveBtn.setFont(TEXT_FONT);
        tempBtn = new JToggleButton("임시 저장");
        tempBtn.setFont(TEXT_FONT);

        cancelBtn.addActionListener(e -> {
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) window.dispose();
        });

        saveBtn.addActionListener(e -> saveDiary());
        tempBtn.addActionListener(this::toggleTempState);

        menuPanel.add(fontLabel);
        menuPanel.add(fontCombo);
        menuPanel.add(cancelBtn);
        menuPanel.add(saveBtn);
        menuPanel.add(tempBtn);

        add(menuPanel, BorderLayout.SOUTH);
    }

    private void toggleTempState(ActionEvent e) {
        if (tempBtn.isSelected()) {
            diaryArea.setBackground(TEMP_COLOR);
            diaryArea.setEditable(false);
            saveToTempFile();
        } else {
            diaryArea.setBackground(BG_COLOR);
            diaryArea.setEditable(true);
        }
    }

    private void saveDiary() {
        String title = Designs.showInputDialog(this, "다이어리 저장", "파일 이름 입력:");
        if (title == null || title.trim().isEmpty() || diaryArea.getText().trim().isEmpty()) return;
        File file = new File(TXT_PATH + "/" + title.trim() + ".txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write(diaryArea.getText());
            Designs.showMessage(this, "성공", "저장 완료: " + file.getName());
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) window.dispose();
        } catch (IOException ex) {
            Designs.showMessage(this, "오류", "저장 실패: " + ex.getMessage());
        }
    }

    private void saveToTempFile() {
        String filename = "TEMP_" + LocalDateTime.now().format(FORMATTER) + ".txt";
        File file = new File(TEMP_PATH + "/" + filename);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write(diaryArea.getText());
            Designs.showMessage(this, "임시 저장", "임시 저장 완료: " + filename);
        } catch (IOException ex) {
            Designs.showMessage(this, "오류", "임시 저장 실패: " + ex.getMessage());
        }
    }
}

