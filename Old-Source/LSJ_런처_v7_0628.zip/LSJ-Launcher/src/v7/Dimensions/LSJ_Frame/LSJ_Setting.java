package v7.Dimensions.LSJ_Frame;

// LSJ_setting.java - 환경설정 패널


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class LSJ_Setting extends JDialog {
    private JCheckBox speechBubbleToggle;
    private JCheckBox timerToggle;
    private JCheckBox styleToggle;
    private JTextField passwordField;
    private JButton saveButton;
    private JButton closeButton;

    private Properties settings;
    private static final String SETTINGS_FILE = "settings.txt";

    public LSJ_Setting(JFrame parent) {
        super(parent, "환경설정", true);
        setSize(320, 240);
        setLocationRelativeTo(parent);
        setUndecorated(true);
        setLayout(new BorderLayout());

        settings = new Properties();
        loadSettings();

        JPanel titleBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        titleBar.setBackground(new Color(80, 160, 80));
        JLabel titleLabel = new JLabel("  🌱 LSJ 환경설정");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 13));
        titleBar.add(titleLabel);

        // 설정 영역
        JPanel settingPanel = new JPanel();
        settingPanel.setLayout(new BoxLayout(settingPanel, BoxLayout.Y_AXIS));
        settingPanel.setBackground(new Color(245, 255, 245));

        speechBubbleToggle = new JCheckBox("💬 말풍선 토글");
        timerToggle = new JCheckBox("⏰ 타이머 토글");
        styleToggle = new JCheckBox("🎨 감성 스타일 적용 (기능 없음)");
        passwordField = new JTextField(15);

        speechBubbleToggle.setOpaque(false);
        timerToggle.setOpaque(false);
        styleToggle.setOpaque(false);

        speechBubbleToggle.setSelected(Boolean.parseBoolean(settings.getProperty("bubble", "true")));
        timerToggle.setSelected(Boolean.parseBoolean(settings.getProperty("timer", "true")));
        passwordField.setText(settings.getProperty("password", ""));

        settingPanel.add(Box.createVerticalStrut(10));
        settingPanel.add(speechBubbleToggle);
        settingPanel.add(timerToggle);
        settingPanel.add(styleToggle);
        settingPanel.add(Box.createVerticalStrut(10));
        settingPanel.add(new JLabel("🔑 비밀번호 설정:"));
        settingPanel.add(passwordField);

        // 버튼
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        saveButton = new JButton("저장");
        closeButton = new JButton("닫기");

        saveButton.addActionListener(e -> saveSettings());
        closeButton.addActionListener(e -> dispose());

        buttonPanel.add(closeButton);
        buttonPanel.add(saveButton);

        add(titleBar, BorderLayout.NORTH);
        add(settingPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void loadSettings() {
        try (FileInputStream fis = new FileInputStream(SETTINGS_FILE)) {
            settings.load(fis);
        } catch (IOException e) {
            System.out.println("설정 파일이 없어 기본값으로 로드합니다.");
        }
    }

    private void saveSettings() {
        try (FileOutputStream fos = new FileOutputStream(SETTINGS_FILE)) {
            settings.setProperty("bubble", String.valueOf(speechBubbleToggle.isSelected()));
            settings.setProperty("timer", String.valueOf(timerToggle.isSelected()));
            settings.setProperty("password", passwordField.getText());
            settings.store(fos, "Lucifer Settings");
            JOptionPane.showMessageDialog(this, "설정이 저장되었습니다.", "저장", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
