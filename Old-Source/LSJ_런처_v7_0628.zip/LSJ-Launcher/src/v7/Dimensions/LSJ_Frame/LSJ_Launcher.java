package v7.Dimensions.LSJ_Frame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.Window;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import v7.Config.Designs;
import v7.Config.LSJ_Paths;
import v7.Config.Registry;

//전체 런처 UI 골격 구현 예시 (JPanel 기반)
//리팩토링 완료: 하단 버튼 기능 완전 활성화 및 정돈
//LSJ_Frame에서 호출될 패널 형태로 구성
public class LSJ_Launcher extends JPanel {
    private static final String MENU_PATH = LSJ_Paths.BASE_PATH + "/menu.ini";
    private static final String APP_PATH = LSJ_Paths.APP_PATH;
   
    
    //private static final String MAIN_LAUNCHER_IMG = "src/resources/" + Registry.IMAGE_ICON_PORTAL;
   // private static final String MAIN_LAUNCHER_IMG = Registry.IMAGE_ICON_PORTAL);
    //private static final String MAIN_LUCIFER_IMG = Registry.getIcon(Registry.IMAGE_ICON_LUCIFER);
    
    private final DefaultListModel<String> pluginListModel = new DefaultListModel<>();
    private final JList<String> pluginList = new JList<>(pluginListModel);
    private final JTextField searchField = new JTextField();

    public LSJ_Launcher() {
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(1000, 600));
        loadMenuFile();

        JLabel topBanner = new JLabel("LSJ Launcher v3.0 with Canlian (www.dgmayor.com)", SwingConstants.CENTER);
        topBanner.setFont(Designs.FONT_HEADER);
        topBanner.setOpaque(true);
        topBanner.setBackground(new Color(180, 220, 250));
        topBanner.setPreferredSize(new Dimension(1000, 60));
        add(topBanner, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout());
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBorder(null);

        JPanel imageDropPanel = new JPanel(new BorderLayout());
        imageDropPanel.setPreferredSize(new Dimension(500, 400));
        imageDropPanel.setBackground(Color.WHITE);

        JLabel imageLabel = new JLabel();
        ImageIcon icon = Designs.loadIcon("/" + Registry.IMAGE_ICON_PORTAL);
        Image img = icon.getImage().getScaledInstance(300, 150, Image.SCALE_SMOOTH);
        imageLabel.setIcon(new ImageIcon(img));
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        imageLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        imageDropPanel.add(imageLabel, BorderLayout.CENTER);

        JLabel dropLabel = new JLabel("여기에 파일을 드래그하여 등록", SwingConstants.CENTER);
        dropLabel.setFont(Designs.FONT_TITLE);
        dropLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        imageDropPanel.add(dropLabel, BorderLayout.SOUTH);

        new DropTarget(imageDropPanel, new DropTargetAdapter() {
            public void drop(DropTargetDropEvent dtde) {
                try {
                    dtde.acceptDrop(DnDConstants.ACTION_COPY);
                    List<File> droppedFiles = (List<File>) dtde.getTransferable().getTransferData(DataFlavor.javaFileListFlavor);
                    for (File file : droppedFiles) {
                        String name = file.getName();
                        if (!pluginListModel.contains(name)) {
                            Files.copy(file.toPath(), Paths.get(APP_PATH + name), StandardCopyOption.REPLACE_EXISTING);
                            String entry = "#" + name + ",LSJ_Frame," + name.replaceFirst("\\..*", "");
                            appendToMenuFile(entry);
                            pluginListModel.addElement(name);
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        rightPanel.add(imageDropPanel, BorderLayout.NORTH);

        JTextArea helpArea = new JTextArea("루시퍼 사용 방법:\n- 우측 상단 영역에 파일 드래그\n- menu.txt에 자동 추가\n- 리스트 더블 클릭으로 실행\n- 하단에서 검색/삭제/종료 가능");
        helpArea.setEditable(false);
        helpArea.setBackground(new Color(240, 240, 240));
        helpArea.setFont(Designs.FONT_BODY);
        rightPanel.add(new JScrollPane(helpArea), BorderLayout.CENTER);

        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setPreferredSize(new Dimension(400, 0));
        leftPanel.setBorder(null);

        pluginList.setFont(Designs.FONT_HEADER);
        JScrollPane scrollPane = new JScrollPane(pluginList);
        leftPanel.add(scrollPane, BorderLayout.CENTER);
        
        
        
        pluginList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    String selected = pluginList.getSelectedValue();
                    if (selected != null) {
                        try {
                            File file = new File(APP_PATH + selected);
                            if (file.getName().toLowerCase().endsWith(".lnk")) {
                                Runtime.getRuntime().exec("cmd /c start \"\" \"" + file.getAbsolutePath() + "\"");
                            } else {
                                Desktop.getDesktop().open(file);
                            }

                            // ✅ 실행 후 자동 닫기
                            SwingUtilities.getWindowAncestor(pluginList).dispose();

                        } catch (IOException ex) {
                            Designs.showMessage(SwingUtilities.getWindowAncestor(pluginList), "실행 실패", "파일 실행 오류 발생");
                        }
                    }
                }
            }
        });

        centerPanel.add(leftPanel, BorderLayout.WEST);
        centerPanel.add(rightPanel, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));

        JButton searchButton = new JButton("검색");
        JButton deleteBtn = new JButton("프로그램 삭제");
        JButton openMenuBtn = new JButton("menu.txt 열기");
        JButton exitBtn = new JButton("종료");

        for (JButton btn : new JButton[]{searchButton, deleteBtn, openMenuBtn, exitBtn}) {
            btn.setFont(Designs.FONT_BODY);
        }

        searchField.setPreferredSize(new Dimension(200, 30));
        bottomPanel.add(openMenuBtn);
        bottomPanel.add(deleteBtn);
        bottomPanel.add(exitBtn);
        bottomPanel.add(searchField);
        bottomPanel.add(searchButton);
        add(bottomPanel, BorderLayout.SOUTH);

        openMenuBtn.addActionListener(ev -> Designs.showTextEditor(this, new File(MENU_PATH)));

        searchButton.addActionListener(e -> {
            String query = searchField.getText().toLowerCase();
            pluginListModel.clear();
            try {
                List<String> lines = Files.readAllLines(Paths.get(MENU_PATH));
                for (String line : lines) {
                    if (line.startsWith("#")) {
                        String[] parts = line.substring(1).split(",");
                        if (parts.length >= 1 && parts[0].toLowerCase().contains(query)) {
                            pluginListModel.addElement(parts[0]);
                        }
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });

        deleteBtn.addActionListener(e -> {
            String selected = pluginList.getSelectedValue();
            if (selected != null) {
                String pw = Designs.promptPassword(this, "삭제 인증", "비밀번호 (ghost)를 입력하세요:");
                if ("ghost".equals(pw)) {
                    pluginListModel.removeElement(selected);
                    try {
                        List<String> lines = Files.readAllLines(Paths.get(MENU_PATH));
                        List<String> updated = lines.stream()
                            .filter(line -> !line.contains(selected))
                            .collect(Collectors.toList());
                        Files.write(Paths.get(MENU_PATH), updated);
                        Files.deleteIfExists(Paths.get(APP_PATH + selected));
                    } catch (IOException ex) {
                        Designs.showMessage(this, "삭제 실패", "파일 삭제 중 오류 발생");
                    }
                } else if (pw != null) {
                    Designs.showMessage(this, "실패", "비밀번호가 틀렸습니다.");
                }
            }
        });

        exitBtn.addActionListener(e -> {
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) window.dispose();
        });
    }

    private void appendToMenuFile(String line) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(MENU_PATH, true))) {
            writer.write(line);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadMenuFile() {
        try {
            List<String> lines = Files.readAllLines(Paths.get(MENU_PATH));
            for (String line : lines) {
                if (line.startsWith("#")) {
                    String[] parts = line.substring(1).split(",");
                    if (parts.length >= 1 && !pluginListModel.contains(parts[0])) {
                        pluginListModel.addElement(parts[0]);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

