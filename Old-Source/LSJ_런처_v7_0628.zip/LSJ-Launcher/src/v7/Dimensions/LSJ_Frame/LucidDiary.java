package v7.Dimensions.LSJ_Frame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LucidDiary extends JDialog {
    private JTextArea diaryArea;
    private JButton submitButton;
    private JButton cancelButton;
    private String userInput;
    private static boolean isDiaryOpen = false;

    private static final int MIN_WIDTH = 400;
    private static final int MIN_HEIGHT = 280;
    private static final int MAX_WIDTH = 800;
    private static final int MAX_HEIGHT = 600;

    public LucidDiary(JFrame parent) {
        super(parent, false);
        if (isDiaryOpen) return;
        isDiaryOpen = true;

        setTitle("LSJ-Chatting");
        setUndecorated(true);
        setSize(480, 340);
        setLocationRelativeTo(parent);
        setAlwaysOnTop(true);
        setLayout(new BorderLayout());

        // 상단 바
        JPanel titleBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        titleBar.setBackground(new Color(100, 180, 120));
        JLabel titleLabel = new JLabel("  LSJ-Chatting");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 13));
        titleBar.add(titleLabel);

        final Point[] initialClick = new Point[1];
        titleBar.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                initialClick[0] = e.getPoint();
            }
        });
        titleBar.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                Point loc = getLocation();
                int xMoved = e.getX() - initialClick[0].x;
                int yMoved = e.getY() - initialClick[0].y;
                setLocation(loc.x + xMoved, loc.y + yMoved);
            }
        });

        // 텍스트 영역
        diaryArea = new JTextArea();
        diaryArea.setBackground(Color.BLACK);
        diaryArea.setForeground(Color.WHITE);
        diaryArea.setCaretColor(Color.WHITE);
        diaryArea.setLineWrap(true);
        diaryArea.setWrapStyleWord(true);
        diaryArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(diaryArea);

        // 마우스 휠로 크기 조절
        addMouseWheelListener(e -> {
            int notches = e.getWheelRotation();
            Dimension size = getSize();
            int delta = notches * -20;

            int newWidth = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, size.width + delta));
            int newHeight = Math.max(MIN_HEIGHT, Math.min(MAX_HEIGHT, size.height + delta));
            setSize(newWidth, newHeight);
        });

        // 전송 / 취소 버튼
        submitButton = new JButton("전송");
        cancelButton = new JButton("취소");

        submitButton.addActionListener(e -> {
            String text = diaryArea.getText();
            if (!text.trim().isEmpty()) {
                userInput = text;
                saveToTimestampedFile(text);
                isDiaryOpen = false;
                dispose();
            }
        });

        cancelButton.addActionListener(e -> {
            userInput = null;
            isDiaryOpen = false;
            dispose();
        });

        // 하단 패널
        JPanel bottomPanel = new JPanel(new BorderLayout());

        JLabel usageLabel = new JLabel("  ⠀휠로 크기 조절 가능 / Ctrl+Enter → 전송");
        usageLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        bottomPanel.add(usageLabel, BorderLayout.WEST);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(cancelButton);
        buttonPanel.add(submitButton);
        bottomPanel.add(buttonPanel, BorderLayout.EAST);

        // 엔터키 전송
        diaryArea.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.isControlDown() && e.getKeyCode() == KeyEvent.VK_ENTER) {
                    submitButton.doClick();
                }
            }
        });

        // 조립
        add(titleBar, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void saveToTimestampedFile(String text) {
        try {
            String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            String time = new SimpleDateFormat("HHmmss").format(new Date());
            String filename = "diary_" + date + "_" + time + ".txt";
            BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
            writer.write(text);
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean isOpen() {
        return isDiaryOpen;
    }

    public String getUserInput() {
        return userInput;
    }
}
