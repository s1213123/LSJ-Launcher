package v7.Dimensions.LSJ_Frame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import v7.Config.Control_L;

public class LSJ_Frame extends JFrame {

	  private final String LSJ_TITLE = v7.Config.Registry.LSJ_TITLE;
	    private final String LSJ_TITLE_COLOR = v7.Config.Registry.LSJ_TITLE_COLOR;
	    private final boolean AlwaysOnTop = v7.Config.Registry.AlwaysOnTop;
	    private final boolean SetUndecorated = v7.Config.Registry.SetUndecorated;

	    private final int MIN_WIDTH = v7.Config.Registry.MIN_WIDTH;
	    private final int MIN_HEIGHT = v7.Config.Registry.MIN_HEIGHT;
	    private final int MAX_WIDTH = v7.Config.Registry.MAX_WIDTH;
	    private final int MAX_HEIGHT = v7.Config.Registry.MAX_HEIGHT;

	    
	 
	    
	    
    public LSJ_Frame(String action) {
        setTitle(LSJ_TITLE + action);

        Object[] result = createPanelMeta(action);
        JPanel panel = (JPanel) result[0];
        Dimension size = (Dimension) result[1];
        Point location = (Point) result[2];
        LSJ_Frame_UI(size.width, size.height, location);

        JPanel titleBar = new LSJ_TitleBar(this, LSJ_TITLE + "     " + action);
        add(titleBar, BorderLayout.NORTH);

        if (panel != null) {
            panel.setBackground(Color.decode(LSJ_TITLE_COLOR));
            add(panel, BorderLayout.CENTER);
        }

        revalidate();
        repaint();
    }

    private void LSJ_Frame_UI(int width, int height, Point location) {
        setSize(width, height);

        if (location.x < 0 || location.y < 0) {
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            int x = screenSize.width - width - 100;
            int y = 100;
            setLocation(x, y);
        } else {
            setLocation(location);
        }

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setAlwaysOnTop(AlwaysOnTop);
        setUndecorated(SetUndecorated);
        setLayout(new BorderLayout());
    }

    
    /*
    "LSJ 런처, LSJ_Frame, LSJ_Launcher",
    "Nova 다이어리 , LSJ_Frame, Nova_Diary",
    "Weaver 캔버스, LSJ_Frame, Weaver_Canvas",
    "LSJ 뷰어 (반만), LSJ_Frame, LSJ_Viewer",
    "루시퍼 컨트롤, LSJ_Frame, Lucifer_Control",
    "환경 설정, LSJ_Frame, LSJ_Status"
    */
    private Object[] createPanelMeta(String action) {
        JPanel panel = null;
       
    //    if ("LSJ_Launcher".equals(action)) panel = new LSJ_Launcher();
      //  else if ("Nova_Diary".equals(action)) panel = new Nova_Diary();
       // else if ("Weaver_Canvas".equals(action)) panel = new Weaver_Canvas();
       // else if ("LSJ_Viewer".equals(action)) panel = new LSJ_Viewer();
       // else if ("LSJ_Status".equals(action)) panel = new LSJ_Status();
       // else 
        if ("Control_L".equals(action)) panel = new Control_L();
        else {
            try {
                String className = "v7.Dimensions.LSJ_Frame." + action;
                Class<?> clazz = Class.forName(className);
                Object instance = clazz.getDeclaredConstructor().newInstance();

                if (instance instanceof JPanel) {
                    panel = (JPanel) instance;
                } else {
                    System.err.println("⚠️ " + className + " 은(는) JPanel이 아님");
                }

            } catch (Exception e) {
                System.err.println("❌ 패널 클래스 로딩 실패: " + action);
                e.printStackTrace();
            } 
        }
            
        Dimension size = new Dimension(600, 500);
        
        if ("LSJ_Launcher".equals(action)) size = v7.Config.Registry.LSJ_Launcher_SIZE;
        else if ("Nova_Diary".equals(action)) size = v7.Config.Registry.LSJ_Diary_SIZE;
        else if ("Weaver_Canvas".equals(action)) size = v7.Config.Registry.LSJ_Drawing_SIZE;
        else if ("LSJ_Viewer".equals(action)) size = v7.Config.Registry.LSJ_Viewer_SIZE;
        else if ("LSJ_Status".equals(action)) size = v7.Config.Registry.LSJ_Status_SIZE;
        else if ("Control_L".equals(action)) size = v7.Config.Registry.LSJ_Control_SIZE;

        Point offset = new Point(100, 100);
        
        if ("LSJ_Launcher".equals(action)) offset = v7.Config.Registry.LSJ_Launcher_LOC;
        else if ("Nova_Diary".equals(action)) offset = v7.Config.Registry.LSJ_Diary_LOC;
        else if ("Weaver_Canvas".equals(action)) offset = v7.Config.Registry.LSJ_Drawing_LOC;
        else if ("LSJ_Viewer".equals(action)) offset = v7.Config.Registry.LSJ_Viewer_LOC;
        else if ("LSJ_Status".equals(action)) offset = v7.Config.Registry.LSJ_Status_LOC;
        else if ("Control_L".equals(action)) offset = v7.Config.Registry.LSJ_Control_LOC;

        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        Point location = new Point(screen.width - size.width - offset.x, offset.y);

        return new Object[]{panel, size, location};
    }

    public class LSJ_TitleBar extends JPanel {
        private Point initialClick;

        public LSJ_TitleBar(JFrame frame, String title) {
            setLayout(new BorderLayout());
            setPreferredSize(new Dimension(0, 40));
            setBackground(Color.decode(LSJ_TITLE_COLOR));

            JLabel titleLabel = new JLabel("  " + title);
            titleLabel.setForeground(Color.WHITE);
            titleLabel.setFont(new Font("맑은 고딕", Font.BOLD, 15));
            add(titleLabel, BorderLayout.WEST);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 2));
            buttonPanel.setOpaque(false);
            add(buttonPanel, BorderLayout.EAST);

            addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    initialClick = e.getPoint();
                }
            });

            addMouseMotionListener(new MouseMotionAdapter() {
                public void mouseDragged(MouseEvent e) {
                    int xMoved = e.getX() - initialClick.x;
                    int yMoved = e.getY() - initialClick.y;
                    frame.setLocation(frame.getX() + xMoved, frame.getY() + yMoved);
                }
            });

            addMouseWheelListener(e -> {
                if (e.isControlDown()) {
                    int delta = e.getWheelRotation() * 20;
                    int newWidth = Math.max(MIN_WIDTH, Math.min(frame.getWidth() - delta, MAX_WIDTH));
                    int newHeight = Math.max(MIN_HEIGHT, Math.min(frame.getHeight() - delta * frame.getHeight() / frame.getWidth(), MAX_HEIGHT));
                    frame.setSize(newWidth, newHeight);
                }
            });
        }
    }
}
