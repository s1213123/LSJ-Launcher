package v7;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import v7.Avatars.Lucifer_Core;
import v7.Avatars.Portal;
import v7.Config.Designs;
import v7.Config.Registry;
import v7.Connect.Canlian;

public class LSJ_Starter extends JFrame {

 
    private String mode;
    
    public LSJ_Starter() {
    	this.mode = Registry.START_MODE;
    	init();
    }
    
    public LSJ_Starter(String overrideMode){
    	this.mode = overrideMode;
    	init();
    }

    
    private void init() {
        setTitle("LSJ Launcher");
        setSize(Registry.FRAME_WIDTH, Registry.FRAME_HEIGHT);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

 
        
        // ✅ 트레이 등록
        Registry.initPaths();
        Registry.make_Registry_ini(false);
        Registry.make_Menu_ini(false);
        
        
        JPanel panel;

        switch (mode) {
            case "portal":
                panel = new Portal(this); break;
            case "lucifer":
            	panel = new Lucifer_Core(this); break;
            case "canlian":
            	panel = new Canlian(this); break;
         
            default:
            	 panel = new Portal(this); break;
        }

        getContentPane().add(panel);
   

        Designs.Transparent_Frame(this);
        Designs.registerTray(this);
        
        
      

    }

    
    
    public static void main(String[] args) {
        System.setProperty("sun.java2d.uiScale", "1.0");
        SwingUtilities.invokeLater(() -> {
            new LSJ_Starter().setVisible(true);
        });
    }
}


