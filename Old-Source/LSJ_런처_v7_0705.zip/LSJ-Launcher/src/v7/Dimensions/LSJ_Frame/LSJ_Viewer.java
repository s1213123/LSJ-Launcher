package v7.Dimensions.LSJ_Frame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Window;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import v7.Config.Designs;
import v7.Config.LSJ_Paths;
import v7.Config.Registry;
public class LSJ_Viewer extends JPanel {
    private JPanel listPanel;
    private JScrollPane scrollPane; // ✅ 스크롤팬 필드로 분리
    
    private JLabel pathLabel;
    private File currentFolder;
    private final File rootFolder = new File(Registry.BASE_PATH);

    private final ImageIcon folderIcon = LSJ_Paths.loadIcon("/" + Registry.IMAGE_ICON_PORTAL);
    private final ImageIcon fileIcon = LSJ_Paths.loadIcon("/" + Registry.IMAGE_ICON_LUCIFER);

    private final List<File> selectedFiles = new ArrayList<>();
    private boolean selectionMode = false;
    JButton toggleSelectBtn = new JButton("선택 모드"); // 초기 상태는 보기 모드

    
    
    
    
    
    
    private final Map<String, ImageIcon> iconCache = new LinkedHashMap<String, ImageIcon>(100, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, ImageIcon> eldest) {
            return size() > 100; // 최대 100개만 유지
        }
    };
    
    public LSJ_Viewer() {
        setLayout(new BorderLayout());
        setBackground(new Color(200, 220, 255));

        currentFolder = rootFolder;
        if (!currentFolder.exists()) currentFolder.mkdirs();

        pathLabel = createPathLabel();
        add(pathLabel, BorderLayout.NORTH);

        listPanel = new JPanel(new WrapLayout(FlowLayout.LEFT, 10, 10));
        listPanel.setBackground(new Color(200, 220, 255));

        scrollPane = new JScrollPane(listPanel);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        add(scrollPane, BorderLayout.CENTER);

        add(setupButtonPanel(), BorderLayout.SOUTH);
        showFileList("ALL");
    }
    
    private JLabel createPathLabel() {
    	JLabel label = new JLabel();
    	label.setOpaque(true);
    	label.setBackground(Color.WHITE);
    	label.setFont(new Font("맑은 고딕", Font.PLAIN, 18)); // ✅ 크기 키움
    	label.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15)); // ✅ 여백도 살짝 증가

        return label;
    }

    private JPanel setupButtonPanel() {
        JPanel panel = new JPanel();
       
        
        
        
        
        Font buttonFont = new Font("맑은 고딕", Font.PLAIN, 16);
        //buttonFont = Designs.FONT_BODY;
        
        
        
        
        toggleSelectBtn.setFont(buttonFont);
        
        
        JButton allBtn = new JButton("전체 보기");
        JButton txtBtn = new JButton("TXT 보기");
        JButton pngBtn = new JButton("PNG 보기");
        JButton backBtn = new JButton("뒤로 가기");

        toggleSelectBtn.setFont(buttonFont);

        toggleSelectBtn.addActionListener(e -> {
            selectionMode = !selectionMode;
            selectedFiles.clear(); // 전환 시 선택 초기화
            toggleSelectBtn.setText(selectionMode ? "뷰어 모드" : "삭제 모드");
            showFileList("ALL");
        });

        
        JButton deleteBtn = new JButton("삭제");
        JButton clearBtn = new JButton("닫기");

        JButton[] buttons = {allBtn, txtBtn, pngBtn, backBtn, toggleSelectBtn, deleteBtn, clearBtn};
        for (JButton btn : buttons) btn.setFont(buttonFont);

        allBtn.addActionListener(e -> showFileList("ALL"));
        txtBtn.addActionListener(e -> showFileList("TXT"));
        pngBtn.addActionListener(e -> showFileList("PNG"));

        backBtn.addActionListener(e -> {
            File parent = currentFolder.getParentFile();
            if (parent != null && parent.exists() && !currentFolder.equals(rootFolder)) {
                currentFolder = parent;
                showFileList("ALL");
            }
        });


        deleteBtn.addActionListener(e -> deleteSelectedFiles());

        clearBtn.addActionListener(e -> {
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) window.dispose();
        });

        panel.add(backBtn);
        panel.add(allBtn);
        panel.add(txtBtn);
        panel.add(pngBtn);
        panel.add(toggleSelectBtn);
        panel.add(deleteBtn);
        panel.add(clearBtn);

        return panel;
    }
    

    private void showFileList(String mode) {
        listPanel.removeAll();
        pathLabel.setText("현재 위치: " + currentFolder.getAbsolutePath());

        List<File> filtered = filterFiles(currentFolder.listFiles(), mode);
        int counter = 0;
        for (File f : filtered) {
            // 이미지 해상도 기준 필터링 (예: 너무 큰 썸네일은 생략)
            if (f.getName().toLowerCase().endsWith(".png")) {
                try {
                    ImageIcon icon = new ImageIcon(f.getAbsolutePath());
                    int width = icon.getIconWidth();
                    int height = icon.getIconHeight();
                    if (width > 2000 || height > 2000) {
                        continue; // 고해상도 이미지는 썸네일 생략
                    }
                } catch (Exception ex) {
                    continue;
                }
            }

            JPanel filePanel = createFilePanel(f);
            listPanel.add(filePanel);
            try {
                if (counter % 10 == 0) Thread.sleep(5); // 10개마다 딜레이로 성능 유지
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        listPanel.setPreferredSize(null);
        listPanel.revalidate();
        listPanel.repaint();

        SwingUtilities.invokeLater(() -> {
            int width = listPanel.getParent().getWidth();
            listPanel.setPreferredSize(new Dimension(width, listPanel.getPreferredSize().height));
            listPanel.revalidate();
        });
    }


    
    private List<File> filterFiles(File[] files, String mode) {
        List<File> result = new ArrayList<>();
        if (files == null) return result;

        for (File f : files) {
            String name = f.getName().toLowerCase();
            if ("TXT".equals(mode) && name.endsWith(".txt")) {
                result.add(f);
            } else if ("PNG".equals(mode) && name.endsWith(".png")) {
                result.add(f);
            } else if ("ALL".equals(mode)) {
                result.add(f);
            }
        }
        return result;
    }

    private JPanel createFilePanel(File f) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setPreferredSize(new Dimension(120, 120));
        panel.setBackground(Color.WHITE);

        JLabel iconLabel = new JLabel();
        iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
   
        if (f.isDirectory()) {
            iconLabel.setIcon(folderIcon);
        } else if ((f.getName().toLowerCase().endsWith(".png") || f.getName().toLowerCase().endsWith(".jpg")) && f.length() < 5 * 1024 * 1024) {
            if (iconCache.containsKey(f.getAbsolutePath())) {
                iconLabel.setIcon(iconCache.get(f.getAbsolutePath()));
            } else {
                iconLabel.setIcon(fileIcon); // 기본 아이콘
                new Thread(() -> {
                    Image image = new ImageIcon(f.getAbsolutePath()).getImage();
                    image = image.getScaledInstance(64, 64, Image.SCALE_FAST);
                    ImageIcon thumb = new ImageIcon(image);
                    iconCache.put(f.getAbsolutePath(), thumb);
                    SwingUtilities.invokeLater(() -> iconLabel.setIcon(thumb));
                }).start();
            }
        } else {
            iconLabel.setIcon(fileIcon);
        }

        
        panel.add(iconLabel, BorderLayout.CENTER);

        JLabel nameLabel = new JLabel(f.getName(), SwingConstants.CENTER);
        nameLabel.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        nameLabel.setForeground(Color.DARK_GRAY);
        nameLabel.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        panel.add(nameLabel, BorderLayout.SOUTH);

        panel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        panel.addMouseListener(new MouseAdapter() {
        	 public void mouseClicked(MouseEvent e) {
        	        if (selectionMode) {
        	            if (selectedFiles.contains(f)) {
        	                selectedFiles.remove(f);
        	                panel.setBackground(Color.WHITE);
        	            } else {
        	                selectedFiles.add(f);
        	                panel.setBackground(new Color(255, 200, 200));
        	            }
        	        } else {
        	            openFile(f); // 보기 모드에서는 열기만
        	        }
        	    }
        });

        return panel;
    }

    private void deleteSelectedFiles() {
        if (selectedFiles.isEmpty()) {
            Designs.showMessage(this, "LSJ 런처", "삭제할 파일을 선택하세요.");
            return;
        }

        String input = Designs.promptPassword(this, "LSJ 파일 삭제 인증", "비밀번호 (ghost)를 입력하세요:");
        if ("ghost".equals(input)) {
            int count = 0;
            for (File f : selectedFiles) {
                if (f.exists() && f.delete()) count++;
            }
            selectedFiles.clear();
            showFileList("ALL");
            Designs.showMessage(this, "LSJ 런처", count + "개 파일이 삭제되었습니다.");
        } else if (input != null) {
        	Designs.showMessage(this, "LSJ 런처", "비밀번호가 틀렸습니다.");
        }
    }


    private void openFile(File f) {
        if (f.isDirectory()) {
            currentFolder = f;
            showFileList("ALL");
        } else if (f.getName().toLowerCase().endsWith(".txt") || f.getName().toLowerCase().endsWith(".ini")) {
            new LSJ_TextWindow(f).setVisible(true);
        

        } else if (f.getName().toLowerCase().endsWith(".png")) {
            new LSJ_ImageWindow(f).setVisible(true);
        } else {
            try {
                Desktop.getDesktop().open(f);
            } catch (IOException e) {
            
            	Designs.showMessage(this, f.getName(), "⚠️ 실행할 수 없습니다.");
            }
        }
    }

}
class LSJ_TextWindow extends JFrame {
    public LSJ_TextWindow(File file) {
        setTitle(file.getName());
        setSize(800, 550); // 창도 조금 키움
        setLocationRelativeTo(null);
        setAlwaysOnTop(true);

        // 자바 기본 아이콘 제거
        setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB));

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("맑은 고딕", Font.PLAIN, 20));  // ✅ 글씨 크기 키움
        textArea.setMargin(new Insets(15, 20, 15, 20));          // ✅ 넉넉한 여백
        textArea.setBackground(Color.BLACK);                    // ✅ 다크 배경
        textArea.setForeground(Color.WHITE);                    // ✅ 밝은 글자색
        textArea.setCaretColor(Color.LIGHT_GRAY);
        textArea.setLineWrap(true);                             // ✅ 자동 줄바꿈
        textArea.setWrapStyleWord(true);                        // ✅ 단어 기준 줄바꿈

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            textArea.read(reader, null);
        } catch (IOException e) {
            textArea.setText("⚠️ 파일을 불러올 수 없습니다.");
        }

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        add(scrollPane);
    }
}





class LSJ_ImageWindow extends JFrame {
    public LSJ_ImageWindow(File file) {
        setTitle(file.getName());
        setSize(800, 800);
        setLocationRelativeTo(null);
        setAlwaysOnTop(true);

        setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB));

        ImageIcon icon = new ImageIcon(file.getAbsolutePath());
        Image image = icon.getImage();

        ImagePanel imagePanel = new ImagePanel(image);

        JScrollPane scrollPane = new JScrollPane(imagePanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        add(scrollPane);
    }
}

class ImagePanel extends JPanel {
    private Image image;

    public ImagePanel(Image image) {
        this.image = image;
        setBackground(Color.GRAY);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int panelWidth = getWidth();
        int panelHeight = getHeight();

        int imgWidth = image.getWidth(null);
        int imgHeight = image.getHeight(null);

        if (imgWidth <= 0 || imgHeight <= 0) return;

        double widthRatio = (double) panelWidth / imgWidth;
        double heightRatio = (double) panelHeight / imgHeight;
        double scale = Math.min(widthRatio, heightRatio);

        int drawWidth = (int) (imgWidth * scale);
        int drawHeight = (int) (imgHeight * scale);

        int x = (panelWidth - drawWidth) / 2;
        int y = (panelHeight - drawHeight) / 2;

        g.drawImage(image, x, y, drawWidth, drawHeight, this);
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(735, 735); // 초기 프레임 크기 기준
    }
}



// WrapLayout 클래스 추가
class WrapLayout extends FlowLayout {
    public WrapLayout(int align, int hgap, int vgap) {
        super(align, hgap, vgap);
    }

    public Dimension preferredLayoutSize(Container target) {
        return layoutSize(target, true);
    }

    public Dimension minimumLayoutSize(Container target) {
        return layoutSize(target, false);
    }

    private Dimension layoutSize(Container target, boolean preferred) {
        synchronized (target.getTreeLock()) {
            int targetWidth = target.getWidth();
            if (targetWidth == 0) targetWidth = Integer.MAX_VALUE;
            int hgap = getHgap();
            int vgap = getVgap();
            Insets insets = target.getInsets();
            int maxWidth = targetWidth - (insets.left + insets.right + hgap * 2);

            int x = 0, y = insets.top + vgap;
            int rowHeight = 0;

            Dimension dim = new Dimension(0, 0);
            for (Component comp : target.getComponents()) {
                if (!comp.isVisible()) continue;
                Dimension d = preferred ? comp.getPreferredSize() : comp.getMinimumSize();
                if (x == 0 || (x + d.width <= maxWidth)) {
                    if (x > 0) x += hgap;
                    x += d.width;
                    rowHeight = Math.max(rowHeight, d.height);
                } else {
                    x = d.width;
                    y += vgap + rowHeight;
                    rowHeight = d.height;
                }
            }
            y += rowHeight + vgap;
            dim.setSize(targetWidth, y);
            return dim;
        }
    }
}


