// 리팩토링된 LSJ_Drawing.java - 주요 기능별로 주석 및 가독성 개선

package v7.Dimensions.LSJ_Frame;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Deque;

import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;

import v7.Config.Designs;
import v7.Config.Registry;

public class Weaver_Canvas extends JPanel {
	 // === 기본 상수 설정 ===
    private static final int MARGIN = 10;
    private static final int HANDLE_SIZE = 8;
    private static final Font UI_FONT = Designs.FONT_BODY; // ✅ 폰트 상수 통합

    // === 패스 함수 ===
    private static final String DRAW_FOLDER = Registry.PNG_PATH;
    private static final String TEMP_FOLDER = Registry.TEMP_PATH;
    private int Canvas_W = 400;
    private int Canvas_H = 300;

    // === 캔버스 및 그래픽 ===
    private BufferedImage canvas;
    private Graphics2D g2;
    private int prevX, prevY;

    // === 상태 및 설정 ===
    private Color currentColor = Color.BLACK;
    private int strokeWidth = 2;
    private boolean tempSaved = false;
    private boolean isDrawing = false;

    // === UI 컴포넌트 ===
    private JButton saveButton, tempSaveButton, colorButton;
    private JComboBox<String> strokeSelector;
    private JPanel drawingArea;
    private JPopupMenu popupMenu;

    // === 선택 및 우클릭 위치 ===
    private Rectangle selectionArea = null;
    private Point selectionStart = null;
    private Point lastRightClick = null;

    // === 붙여넣기 이미지 관련 ===
    private BufferedImage floatingImage = null;
    private Rectangle floatingRect = null;
    private boolean draggingFloating = false;
    private boolean resizingFloating = false;
    private Point dragOffset = null;

    // === 히스토리 스택 ===
    private final Deque<BufferedImage> history = new ArrayDeque<>();

    public Weaver_Canvas() {
        setLayout(new BorderLayout());
        setBackground(Color.decode("#F4F4F4"));

        initCanvas();
        initDrawingArea();
        initControls();
        setupPopupMenu();
        setupPasteHotkey();
    }
    
    private void initCanvas() {
        canvas = new BufferedImage(Canvas_W, Canvas_H, BufferedImage.TYPE_INT_ARGB);
        g2 = canvas.createGraphics();
        applyGraphicsDefaults();
    }

    private void initDrawingArea() {
        drawingArea = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(Color.LIGHT_GRAY);
                g.fillRect(0, 0, getWidth(), getHeight());
                g.drawImage(canvas, MARGIN, MARGIN, null);

                if (floatingImage != null && floatingRect != null) {
                    g.drawImage(floatingImage, floatingRect.x + MARGIN, floatingRect.y + MARGIN,
                                floatingRect.width, floatingRect.height, null);
                    g.setColor(Color.RED);
                    g.drawRect(floatingRect.x + MARGIN, floatingRect.y + MARGIN,
                               floatingRect.width, floatingRect.height);
                    g.fillRect(floatingRect.x + MARGIN + floatingRect.width - HANDLE_SIZE,
                               floatingRect.y + MARGIN + floatingRect.height - HANDLE_SIZE,
                               HANDLE_SIZE, HANDLE_SIZE);
                }
            }
        };

        drawingArea.setBackground(Color.LIGHT_GRAY);
        add(drawingArea, BorderLayout.CENTER);

        drawingArea.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                Point p = new Point(e.getX() - MARGIN, e.getY() - MARGIN);
                if (floatingRect != null && floatingRect.contains(p)) {
                    Rectangle handle = new Rectangle(floatingRect.x + floatingRect.width - HANDLE_SIZE,
                                                     floatingRect.y + floatingRect.height - HANDLE_SIZE,
                                                     HANDLE_SIZE, HANDLE_SIZE);
                    if (handle.contains(p)) {
                        resizingFloating = true;
                    } else {
                        draggingFloating = true;
                        dragOffset = new Point(p.x - floatingRect.x, p.y - floatingRect.y);
                    }
                } else if (!tempSaved && SwingUtilities.isLeftMouseButton(e)) {
                    isDrawing = true;
                    saveHistory();
                    prevX = p.x;
                    prevY = p.y;
                    selectionArea = null;
                } else if (SwingUtilities.isRightMouseButton(e)) {
                    lastRightClick = p;
                    popupMenu.show(e.getComponent(), e.getX(), e.getY());
                }
            }

            public void mouseReleased(MouseEvent e) {
                draggingFloating = false;
                resizingFloating = false;
                isDrawing = false;
            }
        });

        drawingArea.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                Point p = new Point(e.getX() - MARGIN, e.getY() - MARGIN);
                if (draggingFloating && dragOffset != null) {
                    floatingRect.setLocation(p.x - dragOffset.x, p.y - dragOffset.y);
                } else if (resizingFloating) {
                    floatingRect.setSize(Math.max(10, p.x - floatingRect.x), Math.max(10, p.y - floatingRect.y));
                } else if (!tempSaved && isDrawing) {
                    g2.drawLine(prevX, prevY, p.x, p.y);
                    prevX = p.x;
                    prevY = p.y;
                }
                drawingArea.repaint();
            }
        });

        drawingArea.addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                adjustCanvasSize();
                drawingArea.repaint();
            }
        });
    }

    private void initControls() {
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        colorButton = new JButton("펜 색상 선택");
        strokeSelector = new JComboBox<>(new String[]{"1px", "3px", "6px", "9px", "12px", "15px", "18px", "21px", "24px", "27px", "30px"});
        saveButton = new JButton("저장");
        tempSaveButton = new JButton("일시 저장");
        JButton cancelButton = new JButton("취소");

        colorButton.setFont(UI_FONT);
        strokeSelector.setFont(UI_FONT);
        saveButton.setFont(UI_FONT);
        tempSaveButton.setFont(UI_FONT);
        cancelButton.setFont(UI_FONT);

        JLabel strokeLabel = new JLabel("굵기:");
        strokeLabel.setFont(UI_FONT);

        colorButton.addActionListener(e -> chooseColor());
        strokeSelector.addActionListener(e -> updateStroke());
        strokeSelector.setSelectedIndex(1);

        saveButton.addActionListener(e -> saveImage(false));

        tempSaveButton.addActionListener(e -> {
            if (!tempSaved) {
                saveImage(true);
                tempSaved = true;
                tempSaveButton.setText("복귀");
                setEnabled(false);
            } else {
                tempSaved = false;
                tempSaveButton.setText("임시 저장");
                setEnabled(true);
            }
        });

        cancelButton.addActionListener(e -> {
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) window.dispose();
        });

        bottomPanel.add(colorButton);
        bottomPanel.add(strokeLabel);
        bottomPanel.add(strokeSelector);
        bottomPanel.add(cancelButton);
        bottomPanel.add(saveButton);
        bottomPanel.add(tempSaveButton);
        bottomPanel.setBackground(Color.LIGHT_GRAY);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void applyGraphicsDefaults() {
        g2.setColor(currentColor);
        g2.setStroke(new BasicStroke(strokeWidth));
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setBackground(Color.WHITE);
        g2.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }

    private void adjustCanvasSize() {
        int desiredWidth = getWidth() - 2 * MARGIN;
        int desiredHeight = getHeight() - 2 * MARGIN;

        // 기존보다 작아지면 무시 (보호)
        if (desiredWidth < canvas.getWidth() && desiredHeight < canvas.getHeight()) {
            return;
        }

        int newWidth = Math.max(canvas.getWidth(), desiredWidth);
        int newHeight = Math.max(canvas.getHeight(), desiredHeight);

        BufferedImage newCanvas = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D gNew = newCanvas.createGraphics();
        gNew.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        gNew.setColor(Color.WHITE);
        gNew.fillRect(0, 0, newWidth, newHeight);

        // 복사는 가장 마지막에!
        gNew.drawImage(canvas, 0, 0, null);
        gNew.dispose();

        canvas = newCanvas;
        g2 = canvas.createGraphics();
        g2.setColor(currentColor);
        g2.setStroke(new BasicStroke(strokeWidth));
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    }



    
    private void chooseColor() {
        Color chosen = JColorChooser.showDialog(this, "LSJ 펜 색상 선택", currentColor);
        if (chosen != null) {
            currentColor = chosen;
            g2.setColor(currentColor);
        }
    }

    private void updateStroke() {
        String selected = (String) strokeSelector.getSelectedItem();
        switch (selected) {
            case "1px": strokeWidth = 1; break;
            case "3px": strokeWidth = 3; break;
            case "6px": strokeWidth = 6; break;
            case "9px": strokeWidth = 9; break;
            case "12px": strokeWidth = 12; break;
            case "15px": strokeWidth = 15; break;
            case "18px": strokeWidth = 18; break;
            case "21px": strokeWidth = 21; break;
            case "24px": strokeWidth = 24; break;
            case "27px": strokeWidth = 27; break;
            case "30px": strokeWidth = 30; break;
            default: strokeWidth = 3; break;
        }
        g2.setStroke(new BasicStroke(strokeWidth));
    }

    private void saveHistory() {
        BufferedImage snapshot = new BufferedImage(canvas.getWidth(), canvas.getHeight(), canvas.getType());
        Graphics g = snapshot.getGraphics();
        g.drawImage(canvas, 0, 0, null);
        g.dispose();
        history.push(snapshot);
    }

    private void undo() {
        if (!history.isEmpty()) {
            canvas = history.pop();
            g2 = canvas.createGraphics();
            g2.setStroke(new BasicStroke(strokeWidth));
            g2.setColor(currentColor);
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            floatingImage = null;
            floatingRect = null;
            drawingArea.repaint();
        }
    }

    public void saveImage(boolean isTemp) {
        try {
            String folder = isTemp ? TEMP_FOLDER : DRAW_FOLDER;
            File dir = new File(folder);
            if (!dir.exists()) dir.mkdirs();

            String title;
            if (isTemp) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
                title = "temp_" + sdf.format(new Date());
            } else {
            	 title = Designs.showInputDialog(this, "제목 입력", "저장할 제목을 입력하세요:");
                if (title == null || title.trim().isEmpty()) {
                    Designs.showMessage(this, "알림", "저장이 취소되었습니다.");
                    return;
                }
            }

            File file = new File(dir, title + ".png");
            int index = 1;
            while (file.exists()) {
                file = new File(dir, title + "_" + index + ".png");
                index++;
            }

            ImageIO.write(canvas, "png", file);

            if (!isTemp || tempSaved) {
                Designs.showMessage(this, "성공", "저장 완료: " + file.getAbsolutePath());
                Window window = SwingUtilities.getWindowAncestor(this);
                if (window != null) window.dispose();
            }
        } catch (Exception ex) {
            Designs.showMessage(this, "오류", "저장 실패: " + ex.getMessage());
        }
    }


    private void toggleTempSave() {
        tempSaved = !tempSaved;
        setEnabled(!tempSaved);
        setBackground(tempSaved ? Color.BLACK : null);
        tempSaveButton.setText(tempSaved ? "복귀" : "일시 저장");
        if (tempSaved) saveImage(true);
    }

    private void importImage() {
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                Image img = ImageIO.read(fileChooser.getSelectedFile());
                int w = img.getWidth(null);
                int h = img.getHeight(null);
                floatingImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
                Graphics2D gImg = floatingImage.createGraphics();
                gImg.drawImage(img, 0, 0, null);
                gImg.dispose();
                floatingRect = new Rectangle(50, 50, w, h);
                saveHistory();
                drawingArea.repaint();
            } catch (Exception ex) {
                Designs.showMessage(this, "오류", "이미지를 불러올 수 없습니다: " + ex.getMessage());
            }
        }
    }

    private void setupPopupMenu() {
        popupMenu = new JPopupMenu();
        addColorMenuItem("검정", Color.BLACK);
        addColorMenuItem("파랑", Color.BLUE);
        addColorMenuItem("녹색", Color.GREEN);

        JMenuItem eraser = new JMenuItem("지우개 모드");
        eraser.addActionListener(e -> g2.setColor(Color.WHITE));
        popupMenu.add(eraser);

        popupMenu.addSeparator();

        JMenuItem importImageItem = new JMenuItem("이미지 불러오기");
        importImageItem.addActionListener(e -> importImage());
        popupMenu.add(importImageItem);

        JMenuItem confirmImage = new JMenuItem("불러온 이미지 확정");
        confirmImage.addActionListener(e -> confirmFloatingImage());
        popupMenu.add(confirmImage);

        popupMenu.addSeparator();

        JMenuItem paste = new JMenuItem("버퍼 이미지 가져오기");
        paste.addActionListener(e -> pasteImageAt(lastRightClick != null ? lastRightClick : new Point(0, 0)));
        popupMenu.add(paste);

        JMenuItem confirmPaste = new JMenuItem("버퍼 이미지 붙여넣기");
        confirmPaste.addActionListener(e -> confirmFloatingImage());
        popupMenu.add(confirmPaste);

        popupMenu.addSeparator();

        JMenuItem clear = new JMenuItem("전체 지우기");
        clear.addActionListener(e -> {
            g2.setColor(Color.WHITE);
            g2.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
            g2.setColor(currentColor);
            drawingArea.repaint();
        });
        popupMenu.add(clear);

        JMenuItem undo = new JMenuItem("되돌리기");
        undo.addActionListener(e -> undo());
        popupMenu.add(undo);
    }

    private void addColorMenuItem(String name, Color color) {
        JMenuItem item = new JMenuItem(name);
        item.addActionListener(e -> {
            currentColor = color;
            g2.setColor(color);
        });
        popupMenu.add(item);
    }

    private void setupPasteHotkey() {
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("control V"), "paste");
        getActionMap().put("paste", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                pasteImageAt(new Point(0, 0));
            }
        });

        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("control Z"), "undo");
        getActionMap().put("undo", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                undo();
            }
        });

        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("control F"), "saveTemp");
        getActionMap().put("saveTemp", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                saveImage(true);
                Window window = SwingUtilities.getWindowAncestor(Weaver_Canvas.this);
                if (window != null) window.dispose();
            }
        });

        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("control C"), "copy");
        getActionMap().put("copy", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (canvas != null) {
                	 BufferedImage rgbImage = new BufferedImage(canvas.getWidth(), canvas.getHeight(), BufferedImage.TYPE_INT_RGB);
                	    Graphics2D g = rgbImage.createGraphics();
                	    g.drawImage(canvas, 0, 0, Color.WHITE, null);
                	    g.dispose();
                	    TransferableImage trans = new TransferableImage(rgbImage);
                	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(trans, null);
                	    Designs.showMessage(Weaver_Canvas.this, "에러", "캔버스 이미지가 클립보드에 복사되었습니다.");
                }
            }
        });
    }

    private static class TransferableImage implements Transferable {
        private final Image image;

        public TransferableImage(Image image) {
            this.image = image;
        }

        public Object getTransferData(DataFlavor flavor) {
            return flavor.equals(DataFlavor.imageFlavor) ? image : null;
        }

        public DataFlavor[] getTransferDataFlavors() {
            return new DataFlavor[]{DataFlavor.imageFlavor};
        }

        public boolean isDataFlavorSupported(DataFlavor flavor) {
            return flavor.equals(DataFlavor.imageFlavor);
        }
    }

    private void pasteImageAt(Point point) {
        try {
            Transferable t = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);
            if (t != null && t.isDataFlavorSupported(DataFlavor.imageFlavor)) {
                Image img = (Image) t.getTransferData(DataFlavor.imageFlavor);
                int w = img.getWidth(null);
                int h = img.getHeight(null);
                floatingImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
                Graphics2D gImg = floatingImage.createGraphics();
                gImg.drawImage(img, 0, 0, null);
                gImg.dispose();
                floatingRect = new Rectangle(point.x, point.y, w, h);
                drawingArea.repaint();
            } else {
                Designs.showMessage(this, "에러", "클립보드에 이미지가 없습니다.");
            }
        } catch (Exception ex) {
        	Designs.showMessage(this, "에러", "붙여넣기 실패: " + ex.getMessage());
        }
    }

    private void confirmFloatingImage() {
        if (floatingImage != null && floatingRect != null) {
            saveHistory();
            g2.drawImage(floatingImage, floatingRect.x, floatingRect.y,
                         floatingRect.width, floatingRect.height, null);
            floatingImage = null;
            floatingRect = null;
            drawingArea.repaint();
        }
    }
}
