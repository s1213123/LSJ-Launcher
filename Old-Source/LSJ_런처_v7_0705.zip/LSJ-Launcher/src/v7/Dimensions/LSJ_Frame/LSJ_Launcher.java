package v7.Dimensions.LSJ_Frame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.Window;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import v7.Config.Designs;
import v7.Config.LSJ_Paths;
import v7.Config.Registry;

public class LSJ_Launcher extends JPanel {
    private static final String MENU_PATH = Registry.BASE_PATH + "/menu.ini";
    private static final String APP_PATH = Registry.APP_PATH;

    private static int Height = 450;
    private static int Width = 300;
    
    private final DefaultListModel<String> pluginListModel = new DefaultListModel<>();
    private final JList<String> pluginList = new JList<>(pluginListModel);
    private final JTextField searchField = new JTextField();

    public LSJ_Launcher() {
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(1000, 600));
        reloadMenu("");

        JLabel topBanner = new JLabel("LSJ Launcher v3.0 with Canlian (www.dgmayor.com)", SwingConstants.CENTER);
        topBanner.setFont(Designs.FONT_HEADER);
        topBanner.setOpaque(true);
        topBanner.setBackground(new Color(180, 220, 250));
        topBanner.setPreferredSize(new Dimension(1000, 60));
        add(topBanner, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout());
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBorder(null);

        JPanel imageDropPanel = new JPanel(new BorderLayout());
        imageDropPanel.setPreferredSize(new Dimension(500, 400));
        imageDropPanel.setBackground(Color.WHITE);

        JLabel imageLabel = new JLabel();
        ImageIcon icon = LSJ_Paths.loadIcon("/" + Registry.IMAGE_ICON_PORTAL);
        Image img = icon.getImage().getScaledInstance(Height, Width, Image.SCALE_SMOOTH);
        imageLabel.setIcon(new ImageIcon(img));
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        imageLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        imageDropPanel.add(imageLabel, BorderLayout.CENTER);

        JLabel dropLabel = new JLabel("여기에 파일을 드래그하여 등록", SwingConstants.CENTER);
        dropLabel.setFont(Designs.FONT_TITLE);
        dropLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        imageDropPanel.add(dropLabel, BorderLayout.SOUTH);

        new DropTarget(imageDropPanel, new DropTargetAdapter() {
            public void drop(DropTargetDropEvent dtde) {
                try {
                    dtde.acceptDrop(DnDConstants.ACTION_COPY);
                    List<File> droppedFiles = (List<File>) dtde.getTransferable().getTransferData(DataFlavor.javaFileListFlavor);
                    for (File file : droppedFiles) {
                        String name = file.getName();
                        String path = APP_PATH + name;
                        if (!pluginListModel.contains(name)) {
                            Files.copy(file.toPath(), Paths.get(path), StandardCopyOption.REPLACE_EXISTING);
                            String fullPath = new File(path).getAbsolutePath().replace("\\", "/");
                            String entry = "@" + name + ", Earth_Frame, open:" + fullPath;
                            appendToMenuFile(entry);
                            reloadMenu("");
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        rightPanel.add(imageDropPanel, BorderLayout.NORTH);

        JTextArea helpArea = new JTextArea("루시퍼 사용 방법:\n- 우측 상단 영역에 파일 드래그\n- menu.ini에 자동 추가\n- 리스트 더블 클릭으로 실행\n- 하단에서 검색/삭제/종료 가능");
        helpArea.setEditable(false);
        helpArea.setBackground(new Color(240, 240, 240));
        helpArea.setFont(Designs.FONT_BODY);
        rightPanel.add(new JScrollPane(helpArea), BorderLayout.CENTER);

        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setPreferredSize(new Dimension(400, 0));
        leftPanel.setBorder(null);

        pluginList.setFont(Designs.FONT_HEADER);
        pluginList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane scrollPane = new JScrollPane(pluginList);
        leftPanel.add(scrollPane, BorderLayout.CENTER);

        pluginList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    String selected = pluginList.getSelectedValue();
                    if (selected != null) {
                        File file = new File(APP_PATH + selected);
                        if (!file.exists()) {
                            Designs.showMessage(LSJ_Launcher.this, "실행 실패", "파일이 존재하지 않습니다");
                            pluginListModel.removeElement(selected);
                            return;
                        }
                        try {
                            if (file.getName().toLowerCase().endsWith(".lnk")) {
                                Runtime.getRuntime().exec("cmd /c start \"\" \"" + file.getAbsolutePath() + "\"");
                            } else {
                                Desktop.getDesktop().open(file);
                            }
                            SwingUtilities.getWindowAncestor(pluginList).dispose();
                        } catch (IOException ex) {
                            Designs.showMessage(SwingUtilities.getWindowAncestor(pluginList), "실행 실패", "파일 실행 오류 발생");
                        }
                    }
                }
            }
        });

        centerPanel.add(leftPanel, BorderLayout.WEST);
        centerPanel.add(rightPanel, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));

        JButton searchButton = new JButton("검색");
        JButton deleteBtn = new JButton("프로그램 삭제");
        JButton openMenuBtn = new JButton("menu.ini 열기");
        JButton exitBtn = new JButton("종료");

        for (JButton btn : new JButton[]{searchButton, deleteBtn, openMenuBtn, exitBtn}) {
            btn.setFont(Designs.FONT_BODY);
        }

        searchField.setPreferredSize(new Dimension(200, 30));
        bottomPanel.add(openMenuBtn);
        bottomPanel.add(deleteBtn);
        bottomPanel.add(exitBtn);
        bottomPanel.add(searchField);
        bottomPanel.add(searchButton);
        add(bottomPanel, BorderLayout.SOUTH);

        openMenuBtn.addActionListener(ev -> Designs.showTextEditor(this, new File(MENU_PATH)));

        searchButton.addActionListener(e -> reloadMenu(searchField.getText().toLowerCase()));

        deleteBtn.addActionListener(e -> {
            List<String> selectedItems = pluginList.getSelectedValuesList();
            if (!selectedItems.isEmpty()) {
                String pw = Designs.showInputDialog(this, "삭제 인증", "비밀번호 (ghost)를 입력하세요:");
                if ("ghost".equals(pw)) {
                    try {
                        List<String> lines = Files.readAllLines(Paths.get(MENU_PATH));
                        List<String> updated = lines.stream()
                            .filter(line -> selectedItems.stream().noneMatch(line::contains))
                            .collect(Collectors.toList());
                        Files.write(Paths.get(MENU_PATH), updated);
                        for (String selected : selectedItems) {
                            Path filePath = Paths.get(APP_PATH + selected);
                            if (Files.exists(filePath)) {
                               // Desktop.getDesktop().moveToTrash(filePath.toFile());
                            	Files.deleteIfExists(filePath);

                            }
                        }
                        reloadMenu("");
                    } catch (IOException ex) {
                        Designs.showMessage(this, "삭제 실패", "파일 삭제 중 오류 발생");
                    }
                } else if (pw != null) {
                    Designs.showMessage(this, "실패", "비밀번호가 틀렸습니다.");
                }
            }
        });

        exitBtn.addActionListener(e -> {
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) window.dispose();
        });
    }

    private void appendToMenuFile(String line) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(MENU_PATH, true))) {
            writer.write(line);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void reloadMenu(String query) {
        pluginListModel.clear();
        try {
            List<String> lines = Files.readAllLines(Paths.get(MENU_PATH));
            for (String line : lines) {
                if (line.startsWith("@")) {
                    String[] parts = line.substring(1).split(",");
                    if (parts.length >= 3) {
                        String name = parts[0].toLowerCase();
                        String action = parts[2].toLowerCase();
                        if (query.isEmpty() || name.contains(query) || action.contains(query)) {
                            pluginListModel.addElement(parts[0]);
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
