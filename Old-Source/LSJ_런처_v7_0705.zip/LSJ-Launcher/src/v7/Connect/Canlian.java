
package v7.Connect;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.google.gson.Gson;

import v7.Avatars.Portal;
import v7.Config.Registry;

public class Canlian extends JPanel {

	
	
    private static final Map<String, Color> emotionColors = new HashMap<>();
    static {
        emotionColors.put("기쁨", new Color(255, 223, 0));
        emotionColors.put("슬픔", new Color(100, 149, 237));
        emotionColors.put("분노", new Color(255, 69, 0));
        emotionColors.put("놀람", new Color(144, 238, 144));
        emotionColors.put("중립", new Color(211, 211, 211));
    }

    public static class Line {
        public String emotion;
        public String text;

        public Line(String emotion, String text) {
            this.emotion = emotion;
            this.text = text;
        }
    }

    public static class Data {
        public List<Line> lines = new ArrayList<>();
    }

    private JTextArea textArea;
    private JTextField inputField;
    private JLabel imageLabel;
    private Data speechData;
    private int currentIndex = 0;
    private Point dragOffset;
    private JFrame parentFrame;

    public Canlian(JFrame frame) {
        this.parentFrame = frame;


		Registry.globalCanlian = this;
        
        int newW = 600;
        int newH = 320;
        parentFrame.setSize(newW, newH);
        setPreferredSize(new Dimension(newW, newH));
        parentFrame.revalidate();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setOpaque(true);

        textArea = new JTextArea();
        textArea.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setBackground(Color.WHITE);
        textArea.setBorder(BorderFactory.createTitledBorder("캔리안"));
        add(textArea, BorderLayout.CENTER);

        imageLabel = new JLabel();
        try {
            ImageIcon icon = new ImageIcon(getClass().getResource("/images/canlian.png"));
            Image scaledImage = icon.getImage().getScaledInstance(240, 240, Image.SCALE_SMOOTH);
            imageLabel.setIcon(new ImageIcon(scaledImage));
        } catch (Exception e) {
            imageLabel.setText("🦖");
        }
        add(imageLabel, BorderLayout.EAST);

        inputField = new JTextField();
        inputField.setFont(new Font("맑은 고딕", Font.PLAIN, 14));
        inputField.addActionListener(e -> {
            String userText = inputField.getText().trim();
            if (!userText.isEmpty()) {
                speechData.lines.add(new Line("중립", userText));
                currentIndex = speechData.lines.size() - 1;
                showCurrent();
                inputField.setText("");
            }
        });
        add(inputField, BorderLayout.SOUTH);

        speechData = load("/speech_data.json");
        showCurrent();

        javax.swing.Timer timer = new javax.swing.Timer(5000, e -> {
            currentIndex++;
            showCurrent();
        });
        timer.start();

        addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                currentIndex++;
                showCurrent();
            }

            public void mousePressed(MouseEvent e) {
                dragOffset = e.getPoint();
            }
        });

        addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                if (dragOffset != null && parentFrame != null) {
                    Point loc = parentFrame.getLocation();
                    parentFrame.setLocation(loc.x + e.getX() - dragOffset.x, loc.y + e.getY() - dragOffset.y);
                }
            }
        });
    }

    private Data load(String path) {
        try (Reader reader = new InputStreamReader(getClass().getResourceAsStream(path), "UTF-8")) {
            return new Gson().fromJson(reader, Data.class);
        } catch (Exception e) {
            e.printStackTrace();
            return new Data();
        }
    }

    private void showCurrent() {
        if (speechData == null || speechData.lines.isEmpty()) {
            textArea.setText("...");
            setBackground(emotionColors.get("중립"));
            return;
        }

        if (currentIndex >= speechData.lines.size()) {
            currentIndex = 0;
        }

        Line line = speechData.lines.get(currentIndex);
        textArea.setText(line.text);
        Color bg = emotionColors.getOrDefault(line.emotion, emotionColors.get("중립"));
        setBackground(bg);
    }
}
