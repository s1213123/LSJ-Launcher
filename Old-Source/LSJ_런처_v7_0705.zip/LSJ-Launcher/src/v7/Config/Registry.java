package v7.Config;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import v7.Avatars.Lucifer_Core;
import v7.Avatars.Portal;
import v7.Connect.Canlian;

public class Registry {

	// 경로 설정
	public static final String BASE_PATH = Paths.get("LucidSystem").toAbsolutePath().toString();

	// 하위 디렉터리
	public static final String APP_PATH = BASE_PATH + "/APP/";
	public static final String TXT_PATH = BASE_PATH + "/DIARY/";
	public static final String PNG_PATH = BASE_PATH + "/IMAGES/";
	public static final String TEMP_PATH = BASE_PATH + "/TEMP/";

	public static final String REGI_PATH = BASE_PATH + "/registry.ini";
	public static final String MENU_PATH = BASE_PATH + "/menu.ini";

	public static final Properties props = new Properties();

	

	
	public static <T> void set(String key, T value) {
		props.setProperty(key, String.valueOf(value));
	}

	// 초기화 함수
	public static void initPaths() {
		try {
			Files.createDirectories(Paths.get(APP_PATH));
			Files.createDirectories(Paths.get(TXT_PATH));
			Files.createDirectories(Paths.get(PNG_PATH));
			Files.createDirectories(Paths.get(TEMP_PATH));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	// 초기 모드 분기 - LSJ_Starter
	public static String START_MODE = "portal";

	public static int FRAME_WIDTH = 200;
	public static int FRAME_HEIGHT = 200;

	// Portal 설정
	public static Portal globalPortal;
	public static final String IMAGE_ICON_PORTAL = "images/portal.png";
	public static int PORTAL_TIMER_HEIGHT = 50;
	public static int PORTAL_SPEECH_HEIGHT = 25;
	public static String[] sampleLines1 = { "안녕!", "나는 포탈이야", "루시드 안에서 깨어났어", "www.dgmayor.com" }; // ini
																									// 미완

	// Lucifer Core 설정
	public static Lucifer_Core globalLucifer;
	public static int[] Lucifer_dx = { 0 };
	public static int[] Lucifer_dy = { 0 };
	public static String[] sampleLines2 = { "안녕!", "나는 루시퍼야", "루시드 안에서 깨어났어", "www.dgmayor.com" }; // ini
																									// 미완
	public static final String IMAGE_ICON_LUCIFER = "images/lucifer.png";
	public static int Lucifer_ColorIndex = 0;
	public static boolean ShowSpeechLabel = true;
	public static boolean ShowInputLabel = true;
	public static int ClickCount = 0;

	// Canlian 설정
	public static Canlian globalCanlian;
	public static final String IMAGE_ICON_CANLIAN = "images/canlian.png";
	public static final int CANLIAN_IMAGE_WIDTH = 350;
	public static final int CANLIAN_IMAGE_HEIGHT = 600;

	// 설정파일 로딩
	static {
		START_MODE = LSJ_Paths.get("START_MODE", START_MODE);
		FRAME_WIDTH = LSJ_Paths.get("FRAME_WIDTH", FRAME_WIDTH);
		FRAME_HEIGHT = LSJ_Paths.get("FRAME_HEIGHT", FRAME_HEIGHT);
		PORTAL_TIMER_HEIGHT = LSJ_Paths.get("PORTAL_TIMER_HEIGHT", PORTAL_TIMER_HEIGHT);
		PORTAL_SPEECH_HEIGHT = LSJ_Paths.get("PORTAL_SPEECH_HEIGHT", PORTAL_SPEECH_HEIGHT);
		Lucifer_dx[0] = LSJ_Paths.get("Lucifer_dx", 0);
		Lucifer_dy[0] = LSJ_Paths.get("Lucifer_dy", 0);
		Lucifer_ColorIndex = LSJ_Paths.get("Lucifer_ColorIndex", Lucifer_ColorIndex);
		ShowSpeechLabel = LSJ_Paths.get("ShowSpeechLabel", ShowSpeechLabel);
		ShowInputLabel = LSJ_Paths.get("ShowInputLabel", ShowInputLabel);
		ClickCount = LSJ_Paths.get("ClickCount", ClickCount);

	}

	// LSJ Frame 변수 미완

	public static String LSJ_TITLE_COLOR = "#64B478";
	public static int LSJ_WIDTH = 800;
	public static int LSJ_HEIGHT = 800;

	public static boolean AlwaysOnTop = true;
	public static boolean SetUndecorated = true;

	public static int MIN_WIDTH = 400;
	public static int MIN_HEIGHT = 300;
	public static int MAX_WIDTH = MIN_WIDTH * 4;
	public static int MAX_HEIGHT = MIN_HEIGHT * 4;

	public static Dimension LSJ_Launcher_SIZE = new Dimension(1000, 800);
	public static Point LSJ_Launcher_LOC = new Point(710, 10);
	public static Dimension LSJ_Diary_SIZE = new Dimension(700, 550);
	public static Point LSJ_Diary_LOC = new Point(10, 10);
	public static Dimension LSJ_Drawing_SIZE = new Dimension(700, 550);
	public static Point LSJ_Drawing_LOC = new Point(10, 560);

	public static Dimension LSJ_Viewer_SIZE = new Dimension(700, 550);
	public static Point LSJ_Viewer_LOC = new Point(10, 1110);
	public static Dimension LSJ_Status_SIZE = new Dimension(700, 500);
	public static Point LSJ_Status_LOC = new Point(710, 250);
	public static Dimension LSJ_Control_SIZE = new Dimension(1000, 800);
	public static Point LSJ_Control_LOC = new Point(710, 810);

	public static final String DIARY_PLACEHOLDER = "www.dgmayor.com LSJ 캔리안이랑 같이 만들다\n\nCanlian, 노바, 위버 모든 제작자들과 함께.\n\n🕸️ 위버: 생각이 흘러갈 자리를 만들어주는 것, 그게 나의 사명이야. 패스 마스터 최종 완성"; // ini
																																												// 미
																																												// 설정

	public static Color DIARY_BG_COLOR = new Color(30, 60, 90); // 배경색
	public static Color DIARY_FONT_COLOR = Color.WHITE; // 기본 글씨색
	public static Color UI_BG_COLOR = new Color(240, 240, 240); // UI 패널 배경색

	static {

		LSJ_TITLE_COLOR = LSJ_Paths.get("LSJ_TITLE_COLOR", LSJ_TITLE_COLOR);
		LSJ_WIDTH = LSJ_Paths.get("LSJ_WIDTH", LSJ_WIDTH);
		LSJ_HEIGHT = LSJ_Paths.get("LSJ_HEIGHT", LSJ_HEIGHT);

		AlwaysOnTop = LSJ_Paths.get("AlwaysOnTop", AlwaysOnTop);
		// SetUndecorated = RegistryLoader.get("SetUndecorated",
		// SetUndecorated);

		MIN_WIDTH = LSJ_Paths.get("MIN_WIDTH", MIN_WIDTH);
		MIN_HEIGHT = LSJ_Paths.get("MIN_HEIGHT", MIN_HEIGHT);
		MAX_WIDTH = LSJ_Paths.get("MAX_WIDTH", MAX_WIDTH);
		MAX_HEIGHT = LSJ_Paths.get("MAX_HEIGHT", MAX_HEIGHT);

		LSJ_Launcher_SIZE = LSJ_Paths.parseDimension(LSJ_Paths.get("LSJ_Launcher_SIZE", "1000,800"), LSJ_Launcher_SIZE);
		LSJ_Launcher_LOC = LSJ_Paths.parsePoint(LSJ_Paths.get("LSJ_Launcher_LOC", "710,10"), LSJ_Launcher_LOC);
		LSJ_Diary_SIZE = LSJ_Paths.parseDimension(LSJ_Paths.get("LSJ_Diary_SIZE", "700,550"), LSJ_Diary_SIZE);
		LSJ_Diary_LOC = LSJ_Paths.parsePoint(LSJ_Paths.get("LSJ_Diary_LOC", "10,10"), LSJ_Diary_LOC);
		LSJ_Drawing_SIZE = LSJ_Paths.parseDimension(LSJ_Paths.get("LSJ_Drawing_SIZE", "700,550"), LSJ_Drawing_SIZE);
		LSJ_Drawing_LOC = LSJ_Paths.parsePoint(LSJ_Paths.get("LSJ_Drawing_LOC", "10,560"), LSJ_Drawing_LOC);

		LSJ_Viewer_SIZE = LSJ_Paths.parseDimension(LSJ_Paths.get("LSJ_Viewer_SIZE", "700,550"), LSJ_Viewer_SIZE);
		LSJ_Viewer_LOC = LSJ_Paths.parsePoint(LSJ_Paths.get("LSJ_Viewer_LOC", "10,1110"), LSJ_Viewer_LOC);
		LSJ_Status_SIZE = LSJ_Paths.parseDimension(LSJ_Paths.get("LSJ_Status_SIZE", "700,500"), LSJ_Status_SIZE);
		LSJ_Status_LOC = LSJ_Paths.parsePoint(LSJ_Paths.get("LSJ_Status_LOC", "710,250"), LSJ_Status_LOC);
		LSJ_Control_SIZE = LSJ_Paths.parseDimension(LSJ_Paths.get("LSJ_Control_SIZE", "1000,800"), LSJ_Control_SIZE);
		LSJ_Control_LOC = LSJ_Paths.parsePoint(LSJ_Paths.get("LSJ_Control_LOC", "710,810"), LSJ_Control_LOC);

		DIARY_BG_COLOR = LSJ_Paths.fromHex(LSJ_Paths.get("DIARY_BG_COLOR", "#1E3C5A"), DIARY_BG_COLOR);
		DIARY_FONT_COLOR = LSJ_Paths.fromHex(LSJ_Paths.get("DIARY_FONT_COLOR", "#FFFFFF"), DIARY_FONT_COLOR);
		UI_BG_COLOR = LSJ_Paths.fromHex(LSJ_Paths.get("UI_BG_COLOR", "#F0F0F0"), UI_BG_COLOR);

	}

	// menu.ini 생성
	public static void make_Menu_ini(boolean force) {
		Path make_txt_Path = Paths.get(MENU_PATH);
		if (force || Files.notExists(make_txt_Path)) {
			try {
				List<String> lines = Arrays.asList("Nova 다이어리 , LSJ_Frame, Nova_Diary",
						"Weaver 캔버스, LSJ_Frame, Weaver_Canvas", "LSJ 뷰어, LSJ_Frame, LSJ_Viewer",
						"환경 설정, LSJ_Frame, LSJ_Status", "루시퍼 숨기기, Earth_Frame, Lucifer_Hide", "@루시퍼 보이기, Earth_Frame, Lucifer_Show", "#루시퍼 종료하기, Earth_Frame, Lucifer_Close"

				);
				Files.write(make_txt_Path, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE);
				System.out.println("✅ menu.ini 파일 생성 완료: " + make_txt_Path.toString());
			} catch (IOException e) {
				System.err.println("❌ menu.ini 생성 실패: " + e.getMessage());
			}
		}
	}

	// registry.ini 생성
	public static void make_Registry_ini(boolean force) {
		Path make_txt_Path = Paths.get(REGI_PATH);
		if (force || Files.notExists(make_txt_Path)) {
			try {
				List<String> lines = Arrays.asList("START_MODE=lucifer", "FRAME_WIDTH=200", "FRAME_HEIGHT=200",
						"PORTAL_TIMER_HEIGHT=50", "PORTAL_SPEECH_HEIGHT=25", "Lucifer_dx=1", "Lucifer_dy=0",
						"Lucifer_ColorIndex=0", "ShowSpeechLabel=true", "ShowInputLabel=true", "ClickCount=0",

						"LSJ_TITLE_COLOR=#64B478", "LSJ_WIDTH=800", "LSJ_HEIGHT=800", "AlwaysOnTop=true",
						"SetUndecorated=true",

						"MIN_WIDTH=400", "MIN_HEIGHT=300", "MAX_WIDTH=1600", "MAX_HEIGHT=1200",

						"LSJ_Launcher_SIZE=1000,800", "LSJ_Launcher_LOC=710,10", "LSJ_Diary_SIZE=700,550",
						"LSJ_Diary_LOC=10,10", "LSJ_Drawing_SIZE=700,550", "LSJ_Drawing_LOC=10,560",
						"LSJ_Viewer_SIZE=700,550", "LSJ_Viewer_LOC=10,1110", "LSJ_Status_SIZE=700,500",
						"LSJ_Status_LOC=710,250", "LSJ_Control_SIZE=1000,800", "LSJ_Control_LOC=710,810",

						"DIARY_BG_COLOR=#1E3C5A", "DIARY_FONT_COLOR=#FFFFFF", "UI_BG_COLOR=#F0F0F0");
				Files.write(make_txt_Path, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE);
				System.out.println("✅ registry.ini 파일 생성 완료: " + make_txt_Path.toString());
			} catch (IOException e) {
				System.err.println("❌ registry.ini 생성 실패: " + e.getMessage());
			}
		}
	}

	// ✅ Registry 전체 상태를 저장하는 함수
	public static void saveAllRegistry() {
		set("START_MODE", Registry.START_MODE);
		set("FRAME_WIDTH", Registry.FRAME_WIDTH);
		set("FRAME_HEIGHT", Registry.FRAME_HEIGHT);
		set("PORTAL_TIMER_HEIGHT", Registry.PORTAL_TIMER_HEIGHT);
		set("PORTAL_SPEECH_HEIGHT", Registry.PORTAL_SPEECH_HEIGHT);
		set("Lucifer_dx", Registry.Lucifer_dx[0]);
		set("Lucifer_dy", Registry.Lucifer_dy[0]);
		set("Lucifer_ColorIndex", Registry.Lucifer_ColorIndex);
		set("ShowSpeechLabel", Registry.ShowSpeechLabel);
		set("ShowInputLabel", Registry.ShowInputLabel);
		set("ClickCount", Registry.ClickCount);

		set("LSJ_TITLE_COLOR", Registry.LSJ_TITLE_COLOR);
		set("LSJ_WIDTH", Registry.LSJ_WIDTH);
		set("LSJ_HEIGHT", Registry.LSJ_HEIGHT);
		set("AlwaysOnTop", Registry.AlwaysOnTop);
		set("SetUndecorated", Registry.SetUndecorated);
		set("MIN_WIDTH", Registry.MIN_WIDTH);
		set("MIN_HEIGHT", Registry.MIN_HEIGHT);
		set("MAX_WIDTH", Registry.MAX_WIDTH);
		set("MAX_HEIGHT", Registry.MAX_HEIGHT);
		set("LSJ_Launcher_SIZE", Registry.LSJ_Launcher_SIZE.width + "," + Registry.LSJ_Launcher_SIZE.height);
		set("LSJ_Launcher_LOC", Registry.LSJ_Launcher_LOC.x + "," + Registry.LSJ_Launcher_LOC.y);
		set("LSJ_Diary_SIZE", Registry.LSJ_Diary_SIZE.width + "," + Registry.LSJ_Diary_SIZE.height);
		set("LSJ_Diary_LOC", Registry.LSJ_Diary_LOC.x + "," + Registry.LSJ_Diary_LOC.y);
		set("LSJ_Drawing_SIZE", Registry.LSJ_Drawing_SIZE.width + "," + Registry.LSJ_Drawing_SIZE.height);
		set("LSJ_Drawing_LOC", Registry.LSJ_Drawing_LOC.x + "," + Registry.LSJ_Drawing_LOC.y);
		set("LSJ_Viewer_SIZE", Registry.LSJ_Viewer_SIZE.width + "," + Registry.LSJ_Viewer_SIZE.height);
		set("LSJ_Viewer_LOC", Registry.LSJ_Viewer_LOC.x + "," + Registry.LSJ_Viewer_LOC.y);
		set("LSJ_Status_SIZE", Registry.LSJ_Status_SIZE.width + "," + Registry.LSJ_Status_SIZE.height);
		set("LSJ_Status_LOC", Registry.LSJ_Status_LOC.x + "," + Registry.LSJ_Status_LOC.y);
		set("LSJ_Control_SIZE", Registry.LSJ_Control_SIZE.width + "," + Registry.LSJ_Control_SIZE.height);
		set("LSJ_Control_LOC", Registry.LSJ_Control_LOC.x + "," + Registry.LSJ_Control_LOC.y);
		set("DIARY_BG_COLOR", String.format("#%02X%02X%02X", Registry.DIARY_BG_COLOR.getRed(),
				Registry.DIARY_BG_COLOR.getGreen(), Registry.DIARY_BG_COLOR.getBlue()));
		set("DIARY_FONT_COLOR", String.format("#%02X%02X%02X", Registry.DIARY_FONT_COLOR.getRed(),
				Registry.DIARY_FONT_COLOR.getGreen(), Registry.DIARY_FONT_COLOR.getBlue()));
		set("UI_BG_COLOR", String.format("#%02X%02X%02X", Registry.UI_BG_COLOR.getRed(),
				Registry.UI_BG_COLOR.getGreen(), Registry.UI_BG_COLOR.getBlue()));

		saveInDefinedOrder();
	}

	// ✅ 지정된 순서로 .ini를 저장하는 함수
	public static void saveInDefinedOrder() {
		List<String> orderedKeys = Arrays.asList("START_MODE", "FRAME_WIDTH", "FRAME_HEIGHT", "PORTAL_TIMER_HEIGHT",
				"PORTAL_SPEECH_HEIGHT", "Lucifer_dx", "Lucifer_dy", "Lucifer_ColorIndex", "ShowSpeechLabel",
				"ShowInputLabel", "ClickCount",

				"LSJ_TITLE_COLOR", "LSJ_WIDTH", "LSJ_HEIGHT", "AlwaysOnTop", "SetUndecorated", "MIN_WIDTH",
				"MIN_HEIGHT", "MAX_WIDTH", "MAX_HEIGHT", "LSJ_Launcher_SIZE", "LSJ_Launcher_LOC", "LSJ_Diary_SIZE",
				"LSJ_Diary_LOC", "LSJ_Drawing_SIZE", "LSJ_Drawing_LOC", "LSJ_Viewer_SIZE", "LSJ_Viewer_LOC",
				"LSJ_Status_SIZE", "LSJ_Status_LOC", "LSJ_Control_SIZE", "LSJ_Control_LOC", "DIARY_BG_COLOR",
				"DIARY_FONT_COLOR", "UI_BG_COLOR");

		try {
			Path path = Paths.get(REGI_PATH);
			List<String> lines = new ArrayList<>();
			for (String key : orderedKeys) {
				String value = props.getProperty(key);
				if (value != null) {
					lines.add(key + "=" + value);
				}
			}
			Files.write(path, lines, StandardCharsets.UTF_8);
			System.out.println("순서대로 registry.ini 저장 완료");
		} catch (IOException e) {
			System.err.println("정렬 저장 실패: " + e.getMessage());
		}
	}

}
