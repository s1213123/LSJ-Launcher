package v7.Config;

import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Insets;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import v7.LSJ_Starter;
import v7.Avatars.Lucifer_Core;
import v7.Avatars.Lucifer_Function;

public class Designs {

	

    public static final Font FONT_HEADER = new Font("맑은 고딕", Font.BOLD, 26);   // 상단 타이틀
    public static final Font FONT_TITLE  = new Font("맑은 고딕", Font.BOLD, 24);   // 드롭 안내 등
    public static final Font FONT_BODY   = new Font("맑은 고딕", Font.PLAIN, 22);  // 기본 텍스트


    // 프레임 투명화 함수
       public static void Transparent_Frame(JFrame frame) {
           try {
               frame.setVisible(false);
               frame.dispose();
               frame.setAlwaysOnTop(Registry.AlwaysOnTop);
               frame.setUndecorated(Registry.SetUndecorated);
               frame.setBackground(new Color(0, 0, 0, 0)); // 완전 투명
               frame.setType(JFrame.Type.UTILITY);
               frame.setVisible(true);

           } catch (Exception e) {
               System.out.println("프레임 투명화 함수" + e.getMessage());
           }
       }
       
        
       // 루시퍼 컨트롤
       
    // Designs.java 내부
       public static void controlFrame(String command) {
    	    JPanel avatar = null;

    	    if (Registry.globalPortal != null) {
    	        avatar = Registry.globalPortal;
    	    } else if (Registry.globalLucifer != null) {
    	        avatar = Registry.globalLucifer;
    	    } else if (Registry.globalCanlian != null) {
    	        avatar = Registry.globalCanlian;
    	    }

    	    else if (avatar == null) return;

    	    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(avatar);
    	    if (frame == null) return;

    	    switch (command) {
    	        case "hide":
    	            frame.setVisible(false);
    	            break;
    	        case "show":
    	            frame.setVisible(true);
    	            frame.toFront();
    	            break;
    	        case "close":
    	            System.exit(0);
    	            break;
    	    }
    	}


       
       
       
       /// 레지스터 트레이 함수
       
       private static TrayIcon currentTrayIcon = null; // Designs 내부에 static으로 유지

       public static void registerTray(JFrame frame) {
           if (!SystemTray.isSupported()) {
               System.out.println("SystemTray 미지원 환경입니다.");
               return;
           }

           // ✅ 기존 트레이 아이콘 제거
           if (currentTrayIcon != null) {
               SystemTray.getSystemTray().remove(currentTrayIcon);
               currentTrayIcon = null;
           }

           Image image = LSJ_Paths.loadImage("/" + Registry.IMAGE_ICON_PORTAL);

           PopupMenu menu = new PopupMenu();

           MenuItem showItem = new MenuItem("Restore Frame");
           showItem.addActionListener(e -> {
               frame.setVisible(true);
               frame.setState(JFrame.NORMAL);
           });

           MenuItem hideItem = new MenuItem("Minimize Frame");
           hideItem.addActionListener(e -> frame.setVisible(false));

           MenuItem portalForm = new MenuItem("Portal Form");
           portalForm.addActionListener(e -> {
               frame.dispose();
               new LSJ_Starter("portal").setVisible(true);
           });

           MenuItem luciferForm = new MenuItem("Lucifer Form");
           luciferForm.addActionListener(e -> {
               frame.dispose();
               new LSJ_Starter("lucifer").setVisible(true);
           });

           MenuItem customForm = new MenuItem("Custom Form");
           customForm.addActionListener(e -> {
               if (Registry.globalLucifer != null) {
                   Lucifer_Function.ChangeImage(Registry.globalLucifer, null);
                   Designs.showMessage(null, "루시퍼", "30초간 사용자 이미지로 변신합니다. 그 이상은 유료 버전.. www.dgmayor.com");
               } else {
                   Designs.showMessage(null, "루시퍼 없음", "루시퍼가 먼저 실행되어야 합니다.");
               }
           });


           MenuItem exitItem = new MenuItem("Exit");
           exitItem.addActionListener(e -> System.exit(0));

           menu.add(showItem);
           menu.add(hideItem);
           menu.addSeparator();
           menu.add(portalForm);
           menu.add(luciferForm);
           menu.add(customForm);
           menu.addSeparator();
           menu.add(exitItem);

           TrayIcon trayIcon = new TrayIcon(image, "루시퍼 트레이", menu);
           trayIcon.setImageAutoSize(true);

           try {
               SystemTray.getSystemTray().add(trayIcon);
               currentTrayIcon = trayIcon; // ✅ 새로 등록된 트레이 기억
               System.out.println("✅ 트레이 등록 완료");
           } catch (AWTException e) {
               e.printStackTrace();
           }
       }

       
       
       
      
    
    /// 메시지 관련 함수
    
    public static void showMessage(Component parent, String title, String message) {
        // Frame으로 안전하게 캐스팅
        Frame owner = parent != null ? (Frame) SwingUtilities.getWindowAncestor(parent) : null;
        JDialog dialog = new JDialog(owner, title, true);
        dialog.setUndecorated(true);
        dialog.setLayout(new BorderLayout());
        dialog.setBackground(new Color(255, 250, 240));

        // 아이콘 (임시 대체: ❗ / 실제 경로는 리소스로 교체 가능)
        // 아이콘 (이미지로 대체)
        ImageIcon icon = LSJ_Paths.loadIcon("/" + Registry.IMAGE_ICON_PORTAL);
        Image rawImage = icon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        //iconLabel = new JLabel(new ImageIcon(rawImage));
        JLabel iconLabel = new JLabel(new ImageIcon(rawImage));
        iconLabel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 10));

        
        
        iconLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 28));
        iconLabel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 10));

        // 메시지
        JLabel messageLabel = new JLabel(message, SwingConstants.LEFT);
        messageLabel.setFont(new Font("맑은 고딕", Font.BOLD, 16));
        messageLabel.setForeground(Color.BLACK);

        JPanel messagePanel = new JPanel(new BorderLayout());
        messagePanel.setBackground(new Color(255, 250, 240));
        messagePanel.add(iconLabel, BorderLayout.WEST);
        messagePanel.add(messageLabel, BorderLayout.CENTER);
        messagePanel.setBorder(BorderFactory.createEmptyBorder(20, 10, 10, 20));

        // 버튼
        JButton okBtn = new JButton("확인");
        okBtn.setFont(new Font("맑은 고딕", Font.PLAIN, 14));
        okBtn.setFocusPainted(false);
        okBtn.setPreferredSize(new Dimension(80, 30));
        okBtn.addActionListener(e -> dialog.dispose());

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(new Color(255, 250, 240));
        btnPanel.add(okBtn);

        dialog.add(messagePanel, BorderLayout.CENTER);
        dialog.add(btnPanel, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(parent);
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);
    }
    
    public static String showInputDialog(Component parent, String title, String guideText) {
        Frame owner = parent != null ? (Frame) SwingUtilities.getWindowAncestor(parent) : null;
        JDialog dialog = new JDialog(owner, title, true);
        dialog.setUndecorated(true);
        dialog.setLayout(new BorderLayout());
        dialog.setBackground(new Color(255, 250, 240));
        
        
        JLabel label = new JLabel(guideText);
        label.setFont(FONT_BODY);
        label.setForeground(Color.BLACK);
        label.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        JTextField inputField = new JTextField();
        inputField.setFont(FONT_BODY);
        inputField.setPreferredSize(new Dimension(250, 35));

        JPanel centerPanel = new JPanel(new BorderLayout(5, 5));
        centerPanel.setBackground(new Color(255, 250, 240));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        centerPanel.add(label, BorderLayout.NORTH);
        centerPanel.add(inputField, BorderLayout.CENTER);

        JButton okBtn = new JButton("확인");
        JButton cancelBtn = new JButton("취소");

        okBtn.setFont(FONT_BODY);
        cancelBtn.setFont(FONT_BODY);
        okBtn.setPreferredSize(new Dimension(80, 30));
        cancelBtn.setPreferredSize(new Dimension(80, 30));
        okBtn.setFocusPainted(false);
        cancelBtn.setFocusPainted(false);

        final String[] result = new String[1];

        okBtn.addActionListener(e -> {
            result[0] = inputField.getText();
            dialog.dispose();
        });

        cancelBtn.addActionListener(e -> {
            result[0] = null;
            dialog.dispose();
        });

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(new Color(255, 250, 240));
        btnPanel.add(okBtn);
        btnPanel.add(cancelBtn);

        dialog.add(centerPanel, BorderLayout.CENTER);
        dialog.add(btnPanel, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(parent);
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);

        return result[0];
    }


    
    public static String promptPassword(Component parent, String title, String guideText) {
        Frame owner = parent != null ? (Frame) SwingUtilities.getWindowAncestor(parent) : null;
        JDialog dialog = new JDialog(owner, title, true);
        dialog.setUndecorated(true);
        dialog.setLayout(new BorderLayout());
        dialog.setBackground(Color.WHITE);

        // 안내 텍스트
        JLabel guideLabel = new JLabel(guideText);
        guideLabel.setFont(new Font("맑은 고딕", Font.BOLD, 16));
        guideLabel.setForeground(Color.BLACK);
        guideLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));

        // 입력창
        JPasswordField pwd = new JPasswordField();
        pwd.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
        pwd.setPreferredSize(new Dimension(240, 35));

        // 내용 패널
        JPanel centerPanel = new JPanel(new BorderLayout(5, 5));
        centerPanel.setBackground(new Color(255, 250, 240));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        centerPanel.add(guideLabel, BorderLayout.NORTH);
        centerPanel.add(pwd, BorderLayout.CENTER);

        // 버튼
        JButton okBtn = new JButton("확인");
        JButton cancelBtn = new JButton("취소");

        Font btnFont = new Font("맑은 고딕", Font.PLAIN, 14);
        Dimension btnSize = new Dimension(80, 30);

        okBtn.setFont(btnFont);
        cancelBtn.setFont(btnFont);
        okBtn.setPreferredSize(btnSize);
        cancelBtn.setPreferredSize(btnSize);
        okBtn.setFocusPainted(false);
        cancelBtn.setFocusPainted(false);

        final String[] result = new String[1];

        okBtn.addActionListener(e -> {
            result[0] = new String(pwd.getPassword());
            dialog.dispose();
        });

        cancelBtn.addActionListener(e -> {
            result[0] = null;
            dialog.dispose();
        });

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(new Color(255, 250, 240));
        btnPanel.add(okBtn);
        btnPanel.add(cancelBtn);

        dialog.add(centerPanel, BorderLayout.CENTER);
        dialog.add(btnPanel, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(parent);
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);

        return result[0];
    }

	public static void showTextEditor(Component parent, File file) {
	    JFrame editor = new JFrame(file.getName());
	    editor.setSize(800, 550);
	    editor.setLocationRelativeTo(parent);
	    editor.setAlwaysOnTop(true);
	    editor.setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB));
	    editor.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    
	    JTextArea textArea = new JTextArea();
	    textArea.setFont(new Font("맑은 고딕", Font.PLAIN, 18));
	    textArea.setMargin(new Insets(15, 20, 15, 20));
	    textArea.setLineWrap(true);
	    textArea.setWrapStyleWord(true);

	    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
	        textArea.read(reader, null);
	    } catch (IOException e) {
	        textArea.setText("⚠️ 파일을 불러올 수 없습니다.");
	    }

	    JScrollPane scrollPane = new JScrollPane(textArea);
	    scrollPane.setBorder(BorderFactory.createEmptyBorder());

	    JButton saveBtn = new JButton("저장");
	    saveBtn.setFont(new Font("맑은 고딕", Font.PLAIN, 14));
	    saveBtn.addActionListener(e -> {
	        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
	            writer.write(textArea.getText());
	            showMessage(editor, "성공", "저장 완료되었습니다.");
	        } catch (IOException ex) {
	            showMessage(editor, "오류", "파일 저장 실패");
	        }
	    });

	    JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
	    bottomPanel.setBackground(Color.DARK_GRAY);
	    bottomPanel.add(saveBtn);

	    editor.add(scrollPane, BorderLayout.CENTER);
	    editor.add(bottomPanel, BorderLayout.SOUTH);
	    editor.setVisible(true);
	}

}
