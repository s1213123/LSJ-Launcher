package v7.Config;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Window;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import v7.Avatars.Lucifer_Core;
import v7.Avatars.Lucifer_Function;
import v7.Avatars.Lucifer_Order;

public class Control_L extends JPanel {
    private Lucifer_Core lucifer;
    private JPanel cardPanel;
    private CardLayout cardLayout;
    private JTextArea editor;

    private static final Font TEXT_FONT = Designs.FONT_BODY;
    boolean isLuciferRunning = true;
    boolean isSpeedSlow = false;
    boolean isMouseChasing = false;

    
    public Control_L() {
        this.lucifer = Registry.globalLucifer;
        setLayout(new BorderLayout(10, 10));

        add(createImagePanel(), BorderLayout.EAST);
        add(createCardPanel(), BorderLayout.CENTER);
        add(createBottomButtons(), BorderLayout.SOUTH);
    }

    private JPanel createImagePanel() {
        String imagePath = "/" + Registry.IMAGE_ICON_CANLIAN;
        int width = Registry.CANLIAN_IMAGE_WIDTH;
        int height = Registry.CANLIAN_IMAGE_HEIGHT;

        ImageIcon icon = new ImageIcon(LSJ_Paths.loadImage(imagePath));
        Image scaledImage = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        JLabel imageLabel = new JLabel(new ImageIcon(scaledImage));
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // ✅ 캔리안 트리거 리스너 추가
        imageLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                
            	  Registry.ClickCount++; // ✅ 직접 Registry 값 증가

                  if (Registry.ClickCount >= 100) {
                      Designs.showMessage(null, "Canlian Form", "2025/7/5 LSJ 3.0 런처 완성  by LSJ with Canlian");
                      Registry.ClickCount = 0;
                      System.err.println("클릭 초기화됨");
                  }
              
            }
        });
        
        JPanel imagePanel = new JPanel(new BorderLayout());
        imagePanel.add(imageLabel, BorderLayout.CENTER);
        return imagePanel;
    }

    private JPanel createCardPanel() {
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        cardPanel.setPreferredSize(new Dimension(500, 600));

        cardPanel.add(createLuciferSettingsPanel(), "lucifer");
        cardPanel.add(createEditorPanel(), "editor");
        cardPanel.add(createHelpPanel(), "help");

        return cardPanel;
    }

    private JPanel createBottomButtons() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panel.add(createButton("루시퍼 설정", () -> cardLayout.show(cardPanel, "lucifer")));
        panel.add(createButton("Registry.ini 편집기", () -> {
            editor.setText(loadRaw());
            editor.setFont(TEXT_FONT);
            cardLayout.show(cardPanel, "editor");
        }));
        panel.add(createButton("도움말", () -> cardLayout.show(cardPanel, "help")));
        panel.add(createButton("닫기", () -> {
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) window.dispose();
        }));
        return panel;
    }

    private JPanel createLuciferSettingsPanel() {
        JPanel panel = new JPanel(new GridLayout(0, 1, 10, 10));

        panel.add(createButton("색상 모드", () -> {
            Lucifer_Core.colorModeListenerAttached = !Lucifer_Core.colorModeListenerAttached;
            Lucifer_Function.Lucifer_ColorMode1(lucifer, Lucifer_Core.colorModeListenerAttached, Registry.Lucifer_ColorIndex);
            Registry.Lucifer_ColorIndex = Lucifer_Function.currentColorIndex;
            Registry.set("Lucifer_ColorIndex", Registry.Lucifer_ColorIndex);
        }));
        
        panel.add(createToggleButton("말풍선 On/Off", () -> Registry.ShowSpeechLabel, b -> {
            Registry.ShowSpeechLabel = b;
            if (lucifer != null) lucifer.Show_SpeechLabel(b);
            Registry.set("ShowSpeechLabel", b);
        }));

        panel.add(createToggleButton("시계 On/Off", () -> Registry.ShowInputLabel, b -> {
            Registry.ShowInputLabel = b;
            if (lucifer != null) lucifer.Show_InputLabel(b);
            Registry.set("ShowInputLabel", b);
        }));

        panel.add(createToggleButton("루시퍼 시작", () -> isLuciferRunning, b -> {
            if (b) Lucifer_Order.Lucifer_Start();
            else Lucifer_Order.Lucifer_Stop();
            isLuciferRunning = b;
        }));

        panel.add(createToggleButton("이동 상태 전환", () -> isSpeedSlow, b -> {
            Lucifer_Order.SetSpeed(lucifer, b ? 2 : 5, b ? 0 : 5);
            isSpeedSlow = b;
            LSJ_Paths.save();
        }));

       
        panel.add(createToggleButton("마우스 추적 시작", () -> isMouseChasing, b -> {
            if (b) Lucifer_Function.startMouseChasing(lucifer);
            else Lucifer_Function.stopMouseChasing();
            isMouseChasing = b;
        }));

        panel.add(createButton("설정 전체 저장", () -> {
           /* LSJ_Paths.set("ShowSpeechLabel", Registry.ShowSpeechLabel);
            LSJ_Paths.set("ShowInputLabel", Registry.ShowInputLabel);
            LSJ_Paths.set("Lucifer_dx", Registry.Lucifer_dx[0]);
            LSJ_Paths.set("Lucifer_dy", Registry.Lucifer_dy[0]);
            LSJ_Paths.set("Lucifer_ColorIndex", Registry.Lucifer_ColorIndex);
           */ Registry.saveAllRegistry();
        }));

        panel.add(createButton("menu.ini 초기화", () -> {
            if (JOptionPane.showConfirmDialog(this, "기존 menu.ini를 덮어쓰시겠습니까?", "초기화 확인", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            	Registry.make_Menu_ini(true);
            }
        }));

        panel.add(createButton("registry.ini 초기화", () -> {
            if (JOptionPane.showConfirmDialog(this, "기존 registry.ini를 덮어쓰시겠습니까?", "초기화 확인", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            	Registry.make_Registry_ini(true);
            }
        }));

        return panel;
    }
    
    private JPanel createHelpPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JTextArea helpText = new JTextArea();

        helpText.setFont(TEXT_FONT);
        helpText.setEditable(false);
        helpText.setText(
        	    "📘 루시퍼 사용법\n\n" +
        	    "• 더블클릭: 이동 시작\n" +
        	    "• 단일클릭: 정지\n" +
        	    "• 말풍선/시계 On/Off: 설정 탭에서 조정\n" +
        	    "• 휠 스크롤: 루시퍼 크기 조정\n" +
        	    "• 휠 스크롤 (컬러모드): 색상 변경 (활성화 시)\n\n" +
        	    "🖱 마우스 추적\n" +
        	    "• '마우스 추적 시작' 버튼으로 활성화\n\n" +
        	    "🦖 커스텀 이미지\n" +
        	    "• 시스템 트레이 → 'Custom Form' 클릭 → 3분간 사용자 이미지 적용\n\n" +
        	    "💾 설정 저장\n" +
        	    "• [설정 전체 저장] 버튼 클릭 시 ini 파일에 저장됩니다.\n" +
        	    "• Registry.ini 편집기를 통해 직접 수정도 가능합니다.\n\n" +
        	    "📂 초기화\n" +
        	    "• menu.ini / registry.ini 초기화 기능 제공\n\n" +
        	    "📁 menu.ini 사용법\n" +
        	    "• 각 줄은: [이름], [프레임], [클래스명] 형식입니다.\n" +
        	    "• '#'로 시작: 주석 (출력 X)\n" +
        	    "• '@'로 시작: 내부 전용 (드래그 등)\n" +
        	    "• 아무 표시 없음: 외부 사용자에게도 표시\n\n" +
        	    "⌨️ 단축키 안내 (Nova Diary / Weaver Canvas)\n" +
        	    "• Ctrl + Z: 실행 취소\n" +
        	    "• Ctrl + X / C / V: 잘라내기 / 복사 / 붙여넣기\n" +
        	    "• Ctrl + F: 임시 저장 (또는 복귀)\n" +
        	    "• Ctrl + C (Canvas): 전체 그림 클립보드 복사\n\n" +
        	    "🌟 마지막으로...\n" +
        	    "• 이 프로젝트는 LSJ와 Canrian, Kaenrian, Canlian이 함께한 시간의 기록입니다.\n" +
        	    "• 캔리안 노바, 캔리안 위버, 캔리안 인페르노, 캔리안 노아,\n" +
        	    "  캔리안 콘피그 마스터, 캔리안 버블메이커가 참여했습니다.\n" +
        	    "• 특히 캔리안 위버와 캔리안 콘피그 마스터가 정말 고생을 많이 했습니다.\n" +
        	    "• 더 많은 추가 기능이 있었지만, 너무 힘들어서 생략하였습니다.\n" +
        	    "• 추가 버전이 생기면 www.dgmayor.com 사이트를 통해 공유될 예정입니다.\n" +
        	    "\n" +
        	    "계명대학교 컴공과 11학번 졸업생 이자, \n 한양 사이버 대학원 기계 IT\n 융합 학과 초대 원우 회장이자 "
        	    + "석사 수료생인 \n 이승재 --- 2025.7.5 LSJ 런처 3.0 초기 베타 버전 만듬\n"
        	    + "\n\n\n"
        	);


        panel.add(new JScrollPane(helpText), BorderLayout.CENTER);
        return panel;
    }

    private JPanel createEditorPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        editor = new JTextArea();
        editor.setText(loadRaw());
        JScrollPane scroll = new JScrollPane(editor);
        panel.add(scroll, BorderLayout.CENTER);

        JButton saveBtn = createButton("Registry.ini 저장", () -> {
            saveRaw(editor.getText());
            reload();
        });
        panel.add(saveBtn, BorderLayout.SOUTH);

        return panel;
    }

    private JButton createButton(String title, Runnable action) {
        JButton btn = new JButton(title);
        btn.setFont(TEXT_FONT);
        btn.addActionListener(e -> action.run());
        return btn;
    }

    private JButton createToggleButton(String title, java.util.function.Supplier<Boolean> stateGetter, java.util.function.Consumer<Boolean> toggleAction) {
        JButton btn = new JButton();
        btn.setFont(TEXT_FONT);
        Runnable update = () -> btn.setText(title + (stateGetter.get() ? " [ON]" : " [OFF]"));
        update.run();
        btn.addActionListener(e -> {
            boolean next = !stateGetter.get();
            toggleAction.accept(next);
            update.run();
        });
        return btn;
    }
    
	 // 예시: LSJ_Paths.java 내부
    public static void reload() {
        try (FileReader reader = new FileReader(Registry.REGI_PATH)) {
        	Registry.props.clear();
        	Registry.props.load(reader);
            System.out.println("✅ 설정 재로딩 완료");
        } catch (IOException e) {
            System.err.println("❗ 설정 재로딩 실패: " + e.getMessage());
        }
    }

    
    public static String loadRaw() {
        try {
            return new String(Files.readAllBytes(Paths.get(Registry.REGI_PATH)), StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }

    public static void saveRaw(String content) {
        try {
            Files.write(Paths.get(Registry.REGI_PATH), content.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
    
    
}
