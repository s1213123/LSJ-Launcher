
package v7.Avatars;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Window;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import v7.Config.Registry;

public class Lucifer_Function {


	public static BufferedImage originalImage = null;   
	public static BufferedImage customTempImage = null;  // 임시 이미지 추가
	
	public static int currentColorIndex = 0;
	private static MouseWheelListener colorModeListener;



	// 색상 배열 정의
	public static Color[] availableColors = new Color[]{
		new Color(120, 255, 180),  // 민트
	    new Color(255, 128, 180),  // 핑크
	    new Color(140, 185, 215),  // 연하늘
	    new Color(255, 200, 120),  // 살구
	    new Color(120, 255, 180),  // 민트
	    new Color(180, 120, 255),  // 보라
	    new Color(255, 100, 100),   // 레드
	   
	};

	
   
   ///// 루시퍼 버퍼링 제거 함수
   public static BufferedImage deepCopy(BufferedImage src) {
       BufferedImage copy = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
       Graphics g = copy.getGraphics();
       g.drawImage(src, 0, 0, null);
       g.dispose();
       return copy;
   }

   //// 루시퍼 색상 유사도 및 재색칠 함수
   
   public static boolean isSimilar(Color c1, Color c2, int threshold) {
       int dr = Math.abs(c1.getRed() - c2.getRed());
       int dg = Math.abs(c1.getGreen() - c2.getGreen());
       int db = Math.abs(c1.getBlue() - c2.getBlue());
       return (dr + dg + db) < threshold;
   }

   public static BufferedImage recolorImage(BufferedImage src, Color newColor) {
       BufferedImage result = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
       Color baseColor = new Color(188, 207, 225);   // 몸통 기준색
       Color tongueColor = new Color(255, 225, 210); // 혀
       Color spikeColor = new Color(30, 40, 60);     // 뿔

       for (int y = 0; y < src.getHeight(); y++) {
           for (int x = 0; x < src.getWidth(); x++) {
               int pixel = src.getRGB(x, y);
               Color c = new Color(pixel, true);
               if (isSimilar(c, baseColor, 90)
                   && !isSimilar(c, tongueColor, 70)
                   && !isSimilar(c, spikeColor, 70)) {
                   int rgba = (newColor.getRGB() & 0x00FFFFFF) | (pixel & 0xFF000000);
                   result.setRGB(x, y, rgba);
               } else {
                   result.setRGB(x, y, pixel);
               }
           }
       }

       return result;
   }

   public static void Lucifer_ColorMode1(Lucifer_Core l, boolean enabled, int colorIndex) {
	    if (enabled) {
	    	
	        // ✅ 최초 진입 시 색상 즉시 적용
	        if (originalImage == null && l.Lucifer_Buffered_Image != null) {
	            originalImage = deepCopy(l.Lucifer_Buffered_Image);
	        }

	        if (originalImage != null) {
	            currentColorIndex = colorIndex % availableColors.length;
	            l.Lucifer_Buffered_Image = recolorImage(originalImage, availableColors[currentColorIndex]);
	            l.repaint();
	        }
	    	
	        attachColorWheelListener(l, colorIndex);  // ✅ 리팩토링된 버전
	    } else {
	        removeColorWheelListener(l);             // ✅ 정확히 같은 리스너 제거
	    }
	}

   
			// 마우스 체이싱
	
			private static Timer chasingTimer;
			
			public static void startMouseChasing(Lucifer_Core lucifer) {
				
				Lucifer_Order.Lucifer_Stop();
				lucifer.Lucifer_Flip();
				
			    if (chasingTimer != null && chasingTimer.isRunning()) {
			        chasingTimer.stop();
			    }
		
			    chasingTimer = new Timer(30, e -> {
			        Window window = SwingUtilities.getWindowAncestor(lucifer);  // 🪟 부모 프레임 추출
			        if (window == null) return;
		
			        Point mouse = MouseInfo.getPointerInfo().getLocation();
			        Point current = window.getLocation();
		
			        int dx = (mouse.x - current.x + 100) / 30;
			        int dy = (mouse.y - current.y - 250) / 30;
		
			        window.setLocation(current.x + dx, current.y + dy);
			    });
		
			    chasingTimer.start();
			}
		
			public static void stopMouseChasing() {
			    if (chasingTimer != null) chasingTimer.stop();
			}




			 // 💬 디버그 정보 출력
			   public static void Lucifer_Debug(JComponent comp) {
			       // 트레이 매니저
			   	System.err.println("루시퍼 패널");
			    comp.setBorder(BorderFactory.createLineBorder(Color.RED));
	       
			   	// 디버깅 이미지 경로 함수
					System.out.println("📂 현재 작업 디렉터리: " + System.getProperty("user.dir"));
					System.out.println("📂 이미지 상대 경로: " + Registry.IMAGE_ICON_LUCIFER);
			   }
			   
			   
				
			   
			
			   public static void restoreOriginalImage(Lucifer_Core lucifer) {
				    if (lucifer == null || originalImage == null) return;

				    // ✅ 이미지 복원
				    lucifer.Lucifer_Buffered_Image = deepCopy(originalImage);

				    // ✅ 원본 이미지 크기 계산
				    int newW = originalImage.getWidth();
				    int newH = originalImage.getHeight();
				    int speechH = Lucifer_Core.getLuciferSpeechHeight(newH);

				    // ✅ 내부 값 복원
				    lucifer.imgW = newW;
				    lucifer.imgH = newH;
				    lucifer.speechHeight = speechH;

				    // ✅ 프레임 및 패널 크기 조정
				    lucifer.parentFrame.setSize(newW, newH + speechH);
				    lucifer.setPreferredSize(new Dimension(newW, newH + speechH));
				    lucifer.parentFrame.revalidate();
				    lucifer.revalidate();
				    lucifer.repaint();
				}


			   
			  
			   public static void ChangeImage(Lucifer_Core lucifer, Component parent) {
				    JFileChooser fileChooser = new JFileChooser();
				    fileChooser.setDialogTitle("루시퍼 이미지 선택");

				    int result = fileChooser.showOpenDialog(parent);
				    if (result == JFileChooser.APPROVE_OPTION) {
				        File selectedFile = fileChooser.getSelectedFile();
				        try {
				            BufferedImage newImage = ImageIO.read(selectedFile);

				            // ✅ 원본 백업
				            if (originalImage == null && lucifer.Lucifer_Buffered_Image != null) {
				                originalImage = deepCopy(lucifer.Lucifer_Buffered_Image);
				            }

				            // ✅ 리스너 및 이동 제거
				            lucifer.detachResizeWheel();
				            removeColorWheelListener(lucifer);
				            Lucifer_Order.detachMouseControl(lucifer);
				            Lucifer_Order.Lucifer_Stop();

				            // ✅ 이미지 적용
				            lucifer.Lucifer_Buffered_Image = newImage;
				         // ✅ 프레임/패널 크기 조정
				            int newW = newImage.getWidth();
				            int newH = newImage.getHeight();
				            int speechH = Lucifer_Core.getLuciferSpeechHeight(newH);

				            lucifer.imgW = newW;
				            lucifer.imgH = newH;
				            lucifer.speechHeight = speechH;

				            lucifer.parentFrame.setSize(newW, newH + speechH);
				            lucifer.setPreferredSize(new Dimension(newW, newH + speechH));
				            lucifer.parentFrame.revalidate();
				            lucifer.revalidate();
				            lucifer.repaint();


				            // ⏱ 3분 타이머 후 복원
				            new Thread(() -> {
				                try {
				                    Thread.sleep(1 * 30 * 1000);
				                    restoreOriginalImage(lucifer);

				                    lucifer.attachResizeWheel();
				                    attachColorWheelListener(lucifer, Registry.Lucifer_ColorIndex);
				                    Lucifer_Order.attachMouseControl(lucifer);
				                    Lucifer_Order.Lucifer_Start();

				                } catch (InterruptedException ignored) {}
				            }).start();

				        } catch (IOException e) {
				            JOptionPane.showMessageDialog(null, "이미지 로딩 실패: " + e.getMessage());
				        }
				    }
				}



	
			   public static void attachColorWheelListener(Lucifer_Core l, int colorIndex) {
			       removeColorWheelListener(l); // 먼저 제거

			       currentColorIndex = colorIndex % availableColors.length;

			       colorModeListener = e -> {
			           int notches = e.getWheelRotation();
			           currentColorIndex = (notches < 0)
			               ? (currentColorIndex + 1) % availableColors.length
			               : (currentColorIndex - 1 + availableColors.length) % availableColors.length;

			               Registry.Lucifer_ColorIndex = currentColorIndex;  // ✅ 현재 인덱스 저장
			               
			               //System.out.println(Registry.Lucifer_ColorIndex); // 디버깅용
			               
			           if (Lucifer_Function.originalImage != null) {
			               l.Lucifer_Buffered_Image = recolorImage(originalImage, availableColors[currentColorIndex]);
			               l.repaint();
			           }
			       };
			       l.addMouseWheelListener(colorModeListener);
			   }

			   public static void removeColorWheelListener(Lucifer_Core l) {
			       if (colorModeListener != null) {
			           l.removeMouseWheelListener(colorModeListener);
			           colorModeListener = null;
			       }
			   }

			
			
			   
			   
			   
	}
