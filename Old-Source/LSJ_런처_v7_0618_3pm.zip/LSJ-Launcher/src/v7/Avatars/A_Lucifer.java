package v7.Avatars;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import v7.Core.Canlian;
import v7.Core.Paths;
import v7.Core.Orbital;

/**
 * 루시퍼 코어 클래스 이미지 출력 및 기본 구조 설정
 */
public class A_Lucifer extends A_Portal {

	private BufferedImage luciferImage;
	
	private JFrame parentFrame;
	private boolean isFlipped = false;

	private Timer moveTimer;
	private boolean isMoving = true;
	
	private int clickCount = 0;
	
	////// 오직 루시퍼 색상 모드 1만 //////////////////
	// 색상 배열 정의
	private final Color[] availableColors = new Color[]{
	    new Color(255, 128, 180),  // 핑크
	    new Color(0, 127, 75),     // 청록
	    new Color(140, 185, 215),  // 연하늘
	    new Color(255, 200, 120),  // 살구
	    new Color(120, 255, 180),  // 민트
	    new Color(180, 120, 255),  // 보라
	    new Color(255, 100, 100),   // 레드
	    //new Color("cccccc"), // 노바,
	    new Color(30, 60, 90) // 위버
	};

	private int currentColorIndex = 0;
	private BufferedImage originalImage;

	//////////////////////////////////////////
	
	/**
	 * 루시퍼 코어 생성자
	 * 
	 * @param parentFrame
	 *            루시퍼가 속하는 외부 JFrame (위치 제어 등 활용)
	 */
	public A_Lucifer(JFrame parentFrame) {
		super(parentFrame);
		this.parentFrame = parentFrame;

		
		 // 캔리안 호출용 스피치 패널
		Summon_Canlian();
		

		// ✅ 루시퍼 이미지 로딩

		Lucifer_Imageloading();
		
		//루시퍼 기능
		
		Lucifer_Transparency();
		
		Lucifer_Move();
		
		Add_Mouse();
		
		Lucifer_Debug();
		
		//// 루시퍼 컬러 모드 1 호출
		Lucifer_ColorMode1();

		// ✅ 레이아웃 설정
		setLayout(null);
	
		
	}

	

	
	/**
	 * 루시퍼 이미지 직접 출력 (BufferedImage 기반) 
	 * @param g 그래픽 컨텍스트
	 */
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (luciferImage != null) {
			
			int drawWidth =  getParent().getWidth();
			int drawHeight = getParent().getHeight(); 

			if (isFlipped) {
			    g.drawImage(luciferImage, drawWidth, 0, -drawWidth, drawHeight, this);
			} else {
			    g.drawImage(luciferImage, 0, 0, drawWidth, drawHeight, this);
			}

			
		}
	}

	// 캔리안 소환
	public void Summon_Canlian() {

		Canlian speechPanel = new Canlian("src/resources/speech_data.json");
		speechPanel.setBounds(0, 0, Paths.SPEECH_WIDTH, Paths.SPEECH_HEIGHT); // 말풍선 위치 조정
		add(speechPanel);

		// ✅ AvatarCore 기본 라벨 숨김 처리
		if (imageLabel != null)
			imageLabel.setVisible(false);
		if (speechLabel != null)
			speechLabel.setVisible(false);
		if (inputLabel != null)
			inputLabel.setVisible(false);

		
	}
	
	private void Lucifer_Imageloading(){
	
		try {
		    URL imageUrl = getClass().getClassLoader().getResource("lucifer.png");
		    if (imageUrl != null) {
		        luciferImage = ImageIO.read(imageUrl);
		    } else {
		        File fallback = new File("src/resources/lucifer.png");
		        if (fallback.exists()) {
		            luciferImage = ImageIO.read(fallback);
		        } else {
		            System.err.println("❌ 루시퍼 이미지 경로 실패 (resource & fallback 모두 실패)");
		        }
		    }
		} catch (Exception e) {
		    System.err.println("❌ 루시퍼 이미지 로딩 실패");
		    e.printStackTrace();
		}

	

	}
	
	// 루시퍼 투명화
	private void Lucifer_Transparency() {
		setOpaque(false);
		setBackground(new Color(0, 0, 0, 0));
	}
	
	
	// 루시퍼 좌우 이동
	private void Lucifer_Move() {
	    Timer moveTimer = new Timer(30, null); // 30ms 간격
	    int[] dx = {4}; // 이동 방향

	    moveTimer.addActionListener(e -> {
	        if (!isMoving || luciferImage == null || parentFrame == null) return;

	        Point current = parentFrame.getLocation();
	        int newX = current.x + dx[0];

	        // 화면 경계 체크
	        int screenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
	        int frameWidth = parentFrame.getWidth();

	        if (newX < 0 || newX + frameWidth > screenWidth) {
	            dx[0] = -dx[0]; // 방향 반전
	    	   Lucifer_Flip();
	        }

	        parentFrame.setLocation(newX, current.y); // 좌우 이동
	    });

	    moveTimer.start();
	    isMoving = true;
	}

	// 루시퍼 마우스 이벤트
	private void Add_Mouse(){
		
		// 마우스 휠로 루시퍼 크기 제어
		addMouseWheelListener(e -> {
			int delta = (e.getWheelRotation() < 0) ? 10 : -10;
			Lucifer_Resize(delta);
		});
		
		// 마우스 버튼으로 루시퍼 정지 및 움직임 명령
		addMouseListener(new MouseAdapter() {
		    @Override
		    public void mousePressed(MouseEvent e) {
		        if (SwingUtilities.isLeftMouseButton(e)) {
		            int count = e.getClickCount();

		            if (count == 2) {
		                Lucifer_Start(); // 더블클릭: 이동 시작
		            } else if (count == 1) {
		                Lucifer_Stop(); // 한 번 클릭: 정지
		            
		        } else if (clickCount == 10) {
		            	JOptionPane.showMessageDialog(
		                        null,
		                        "캔리안, 고마워... by LSJ",
		                        "Lucifer Secret",
		                        JOptionPane.INFORMATION_MESSAGE
		                    );
		                clickCount = 0; // 다시 초기화
		            }
		        } /*else if (SwingUtilities.isRightMouseButton(e)) {
		            Lucifer_Flip(); // 우클릭은 flip으로 유지 가능
		        }*/
		    }
		});
 
	}
	
	/**
	 * 루시퍼의 방향을 반전시킵니다.
	 * 좌우 반전 상태를 전환하고 다시 그립니다.
	 */
	public void Lucifer_Flip() {
	    isFlipped = !isFlipped;
	    repaint();
	}
	
	// 루시퍼 크기 조정
	private void Lucifer_Resize(int delta){
		if (luciferImage == null) return;
		
	    // 현재 크기 기준
	    Dimension currentSize = parentFrame.getSize();

	    int newW = Math.max(100, currentSize.width + delta);
	    int newH = Math.max(100, currentSize.height + delta);  // 비율 동기화 or 따로도 가능

	    // 프레임과 패널 크기 조정
	    parentFrame.setSize(newW, newH);
	    setPreferredSize(new Dimension(newW, newH));
	    parentFrame.revalidate();

		
		repaint();
	}
	
	// 루시퍼 스타트
	private void Lucifer_Start() {
		isMoving = true;
		if (moveTimer != null) moveTimer.start();
	}
	
	// 루시퍼 스탑
	private void Lucifer_Stop() {
		isMoving = false;
		if (moveTimer != null) moveTimer.stop();
	}
	
	 // 💬 디버그 정보 출력
    private void Lucifer_Debug() {
        // 트레이 매니저
    	System.err.println("루시퍼 패널");
        Orbital.applyPanelBorder(this, Color.GREEN);
        
    	// 디버깅 이미지 경로 함수
		System.out.println("📂 현재 작업 디렉터리: " + System.getProperty("user.dir"));
		System.out.println("📂 이미지 상대 경로: " + Paths.IMAGE_PATH_LUCIFER);
    }
    
    ///////////////////////////////////////////////
    /// 루시퍼 이미지 휠 체인지 배열 변화 1
    /////////////////////////////////////////////////
    
    private void Lucifer_ColorMode1(){
    	
    	
    	if (luciferImage != null) {
            originalImage = deepCopy(luciferImage); // 원본 이미지 백업
            luciferImage = recolorImage(originalImage, availableColors[currentColorIndex]); // 첫 적용
        }

        addMouseWheelListener(e -> {
            int notches = e.getWheelRotation();
            if (notches < 0) {
                currentColorIndex = (currentColorIndex + 1) % availableColors.length;
            } else {
                currentColorIndex = (currentColorIndex - 1 + availableColors.length) % availableColors.length;
            }

            if (originalImage != null) {
                luciferImage = recolorImage(originalImage, availableColors[currentColorIndex]);
                repaint();
            }
        });
    	
    	
    	
    	
    	
    }
    
    
    
    ///// 루시퍼 버퍼링 제거 함수
    private BufferedImage deepCopy(BufferedImage src) {
        BufferedImage copy = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics g = copy.getGraphics();
        g.drawImage(src, 0, 0, null);
        g.dispose();
        return copy;
    }

    //// 루시퍼 색상 유사도 및 재색칠 함수
    
    private boolean isSimilar(Color c1, Color c2, int threshold) {
        int dr = Math.abs(c1.getRed() - c2.getRed());
        int dg = Math.abs(c1.getGreen() - c2.getGreen());
        int db = Math.abs(c1.getBlue() - c2.getBlue());
        return (dr + dg + db) < threshold;
    }

    private BufferedImage recolorImage(BufferedImage src, Color newColor) {
        BufferedImage result = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Color baseColor = new Color(188, 207, 225);   // 몸통 기준색
        Color tongueColor = new Color(255, 225, 210); // 혀
        Color spikeColor = new Color(30, 40, 60);     // 뿔

        for (int y = 0; y < src.getHeight(); y++) {
            for (int x = 0; x < src.getWidth(); x++) {
                int pixel = src.getRGB(x, y);
                Color c = new Color(pixel, true);
                if (isSimilar(c, baseColor, 90)
                    && !isSimilar(c, tongueColor, 70)
                    && !isSimilar(c, spikeColor, 70)) {
                    int rgba = (newColor.getRGB() & 0x00FFFFFF) | (pixel & 0xFF000000);
                    result.setRGB(x, y, rgba);
                } else {
                    result.setRGB(x, y, pixel);
                }
            }
        }

        return result;
    }

 
    
}
