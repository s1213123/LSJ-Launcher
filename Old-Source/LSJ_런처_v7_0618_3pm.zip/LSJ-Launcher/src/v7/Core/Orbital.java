package v7.Core;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Component;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;

public class Orbital {

	
	// AvatarCore 패널에 테두리 적용
	public static void applyPanelBorder(JPanel panel, Color color) {
	    if (panel != null) {
	        panel.setBorder(BorderFactory.createLineBorder(color, 3));
	        System.out.println("Tray: AvatarCore Border 적용됨");
	    }
	}

	// makeAvatarOnly 함수 (프레임 테두리 + 배경 처리만 담당)
	public static void makeAvatarOnly(JFrame frame) {
	    try {
	        frame.setVisible(false);
	        frame.dispose();
	        frame.setAlwaysOnTop(Paths.AlwaysOnTop);
	        frame.setUndecorated(Paths.SetUndecorated);
	        frame.setBackground(new Color(0, 0, 0, 0)); // 투명화
	        frame.setVisible(true);

	        // ✅ 프레임 자체에 테두리 적용
	        frame.getRootPane().setBorder(BorderFactory.createLineBorder(Color.MAGENTA, 1));

	        // ✅ 내부 AvatarCore에 보더 적용 (분리된 함수 활용)
	        Component content = frame.getContentPane().getComponent(0);
	        if (content instanceof JPanel) {
	            applyPanelBorder((JPanel) content, Color.LIGHT_GRAY);
	        }

	    } catch (Exception e) {
	        System.out.println("Tray: makeAvatarOnly 처리 실패 - " + e.getMessage());
	    }
	}

    // 프레임 원상복구
    public static void restoreFrame(JFrame frame) {
        try {
            frame.setVisible(false);
            frame.dispose();
            frame.setUndecorated(false);
            frame.setBackground(UIManager.getColor("Panel.background")); // 기본 색상 복구
            frame.setOpacity(1.0f);
            frame.setVisible(true);
            System.out.println("Tray: 프레임 복구됨");
        } catch (UnsupportedOperationException e) {
            System.out.println("복구 실패 - 환경 제약일 수 있음.");
        }
    }

    // 트레이 등록 및 제어 메뉴
    public static void registerTray(JFrame frame) {
        if (!SystemTray.isSupported()) {
            System.out.println("SystemTray 미지원 환경입니다.");
            return;
        }

        Image image = Toolkit.getDefaultToolkit().getImage(Paths.IMAGE_PATH_PORTAL); // 작은 아이콘 권장
        PopupMenu menu = new PopupMenu();

        MenuItem showItem = new MenuItem("Restore Frame");
        showItem.addActionListener(e -> restoreFrame(frame));

        MenuItem hideItem = new MenuItem("AvatarCore Only");
        hideItem.addActionListener(e -> makeAvatarOnly(frame));

        MenuItem exitItem = new MenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));

        menu.add(showItem);
        menu.add(hideItem);
        menu.add(exitItem);

        TrayIcon trayIcon = new TrayIcon(image, "LSJ Launcher", menu);
        trayIcon.setImageAutoSize(true);

        try {
            SystemTray.getSystemTray().add(trayIcon);
            System.out.println("Tray 등록 완료");
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }
}
