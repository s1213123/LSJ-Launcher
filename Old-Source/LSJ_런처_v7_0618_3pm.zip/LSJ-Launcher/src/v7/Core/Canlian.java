// ☁️ 캔리안 통합 말풍선 시스템 - Canlian_Speech_Core.java
// 이 파일은 EmotionColorMap_C, SpeechData_C, SpeechLine_C,
// SpeechLoader_C, SpeechPanel_C의 기능을 하나로 통합한 구조입니다.
// 승재가 말한 "한 줄로 부를 수 있는 구조"를 위해
// 기능은 그대로 두되 구조는 간결하고 의미 있게 구성합니다.

package v7.Core;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import com.google.gson.Gson;

public class Canlian extends JPanel {

    // 🎨 감정별 색상 맵 (EmotionColorMap)
	private static final Map<String, Color> emotionColors = new HashMap<>();
	static {
	    emotionColors.put("기쁨", new Color(255, 223, 0));
	    emotionColors.put("슬픔", new Color(100, 149, 237));
	    emotionColors.put("분노", new Color(255, 69, 0));
	    emotionColors.put("놀람", new Color(144, 238, 144));
	    emotionColors.put("중립", new Color(211, 211, 211));
	}


    // 📚 대사 한 줄 (SpeechLine)
    public static class Line {
        public String emotion;
        public String text;
    }

    // 📦 대사 전체 데이터 (SpeechData)
    public static class Data {
        public List<Line> lines = new ArrayList<>();
    }

    // 🧠 말풍선 내부 컴포넌트
    private JTextArea textArea;
    private Data speechData;
    private int currentIndex = 0;

    // 🗣️ 생성자: JSON 경로로부터 대사 로딩 및 초기화
    public Canlian(String jsonPath) {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createTitledBorder("캔리안 말풍선"));
        setOpaque(true);

        textArea = new JTextArea();
        textArea.setFont(new Font("맑은 고딕", Font.PLAIN, 13));
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        add(textArea, BorderLayout.CENTER);

        speechData = load(jsonPath);
        showCurrent();

        // 클릭 시 다음 대사
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                currentIndex++;
                showCurrent();
            }
        });
    }

    // 📥 JSON 파일로부터 대사 데이터 로딩
    private Data load(String path) {
        try (Reader reader = new FileReader(path)) {
            Gson gson = new Gson();
            return gson.fromJson(reader, Data.class);
        } catch (Exception e) {
            System.err.println("❌ 대사 파일 로딩 실패: " + e.getMessage());
            return new Data();
        }
    }

    // 🧾 현재 대사 출력
    private void showCurrent() {
        if (speechData.lines == null || speechData.lines.isEmpty()) {
            textArea.setText("(대사가 없습니다)");
            setBackground(Color.LIGHT_GRAY);
            return;
        }

        if (currentIndex >= speechData.lines.size()) currentIndex = 0;

        Line line = speechData.lines.get(currentIndex);
        textArea.setText(line.text);
        setBackground(emotionColors.getOrDefault(line.emotion, Color.LIGHT_GRAY));
    }
}
