package v7.Core;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Paths {
	
	public static final String TEMP_FOLDER_PATH = "C:/LSJ";
	
	
    public static String getTempFolderPath() {
		return TEMP_FOLDER_PATH;
	}


	public static final String WINDOW_TITLE = "LSJ Launcher";
    public static final int WINDOW_WIDTH = 500;
    public static final int WINDOW_HEIGHT = 500;
    
    public static final String EARTH_TITLE = "Earth Frame - by LSJ";
    public static final int EARTH_WIDTH = 1200;
    public static final int EARTH_HEIGHT = 1000;
    
    public static final String LSJ_TITLE = "LSJ Frame - by LSJ";
    public static final String LSJ_TITLE_COLOR = "0x1e354d";
    //public static final String LSJ_TITLE_COLOR = "#78FFB4";
    
    //"0x3a333a"
    public static final int LSJ_WIDTH = 1200;
    public static final int LSJ_HEIGHT = 1000;
    
    
    // 프레임 설정
    public static final boolean AlwaysOnTop = true;
    public static final boolean SetUndecorated = true;
    
    
    // 이미지 경로
    public static final String IMAGE_PATH_LUCIFER = "src/resources/images/lucifer.png";
    public static final String IMAGE_PATH_PORTAL = "src/resources/images/portal.png";
    public static final String IMAGE_PATH_CANLIAN = "src/resources/images/canlian.png";

    // 👉 추가 상수
    public static final int MIN_WIDTH = 150;
    public static final int MIN_HEIGHT = 150;
//    public static final int BORDER_THICKNESS = 2;
    
    
    // txt 파일 경로
    public static final String MENU_PATH = "src/resources/settings/menu.txt";
    public static final String PANEL_PATH = "src/resources/settings/panel.txt";
    
    // 어스 프레임 타이틀 높이
    public static final int TITLE_HEIGHT = 35;
    public static final int TITLE_WIDTH = 0;
    
    
    // 캔리안 말풍선 크기
    public static final int SPEECH_HEIGHT = 40;
    public static final int SPEECH_WIDTH = 300;
    
    
    //기본 대화 목록
    
    public static String[] sampleLines = { "안녕!", "나는 포탈이야", "루시드 안에서 깨어났어", "www.dgmayor.com" };
    
    /// LSJ 다이어리 경로
    public static final String dir_Path = "src/resources";
    
    
   
    
    
    
    
    
    
    
    
    // 공통 파서    
    public static class Parser {

    	
    	public List<String[]> loadList(String path) {
    	    List<String[]> list = new ArrayList<>();

    	    try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
    	        String line;
    	        while ((line = reader.readLine()) != null) {
    	            line = line.trim();
    	            if (line.isEmpty() || line.startsWith("#") || line.startsWith("//")) continue;

    	            String[] parts = line.split("[,.=]", 3);
    	            if (parts.length == 3) {
    	                list.add(new String[] {
    	                    parts[0].trim(), // name
    	                    parts[1].trim(), // type
    	                    parts[2].trim()  // action
    	                    
    	                });
    	                
    	            }
    	        }
    	    } catch (IOException e) {
    	        System.err.println("❌ 파일 읽기 실패: " + e.getMessage());
    	    }
    	   
    	    return list;
    	}   
    	
    	
    }


    //// 메뉴 DTO
    
    public static class M {


        public String name;
        public String type;
        public String action;

        public M(String name, String type, String action) {
            this.name = name;
            this.type = type;
            this.action = action;
        }
      
        // 메뉴 파싱, 네임, 타입, 액션 순
        
        public static List<M> Menu_Parser() {
            List<M> items = new ArrayList<>();
         
            Parser parser = new Parser();  // 공통 파서 사용

            List<String[]> raw = parser.loadList(MENU_PATH);

            for (String[] entry : raw) {
                if (entry.length == 3) {
                    items.add(new M(entry[0], entry[1], entry[2]));
                }
            }

            return items;
        }
      
    }

}
    
    
    
    
    
    
    
    
    
    
    
    
   
    

