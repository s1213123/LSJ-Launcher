package v7;

import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import v7.Avatars.A_Lucifer;
import v7.Avatars.A_Portal;
import v7.Core.Orbital;
import v7.Core.Paths;
import v7.Dimensions.Lucid_Frame.Lucifer_Control;

public class LSJ_Starter extends JFrame {

    // ✍️ 기본 상수
    private static final String TITLE = Paths.WINDOW_TITLE;
    private static final int WIDTH = Paths.WINDOW_WIDTH;
    private static final int HEIGHT = Paths.WINDOW_HEIGHT;

    // ✍️ UI 구성 요소
    private JButton launchAvatarCore;
    private JButton launchLucifer;
    private JButton lucifer_control;

    public LSJ_Starter() {
        setTitle(TITLE);
        setSize(WIDTH, HEIGHT);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // ✅ 버튼 패널 구성
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(Color.DARK_GRAY);

    
        // ✅ AvatarCore_C 실행 버튼
        launchAvatarCore = new JButton("Launch AvatarCore");
        launchAvatarCore.addActionListener(e -> {
            A_Portal avatarPanel_C = new A_Portal(this);
            getContentPane().removeAll();
            getContentPane().add(avatarPanel_C);
            revalidate();
            repaint();
        });

        // ✅ Lucifer1 실행 버튼
        launchLucifer = new JButton("Launch Lucifer1");
        launchLucifer.addActionListener(e -> {
            A_Lucifer luciferPanel = new A_Lucifer(this);
            getContentPane().removeAll();
            getContentPane().add(luciferPanel);
            revalidate();
            repaint();
        });

        // ✅ Lucifer1 실행 버튼
        lucifer_control = new JButton("Lucifer Control");
        lucifer_control.addActionListener(e -> {
            Lucifer_Control lucifer_control = new Lucifer_Control();
            getContentPane().removeAll();
            getContentPane().add(lucifer_control);
            revalidate();
            repaint();
        });

        
        // ✅ 버튼 패널에 버튼 한 번만 추가
        buttonPanel.add(launchAvatarCore);
        buttonPanel.add(launchLucifer);
        buttonPanel.add(lucifer_control);

        // ✅ 패널 프레임에 한 번만 추가
        add(buttonPanel); // 기본은 CENTER이지만 레이아웃 미지정 시 사용 가능

        // ✅ 트레이 등록
        Orbital.makeAvatarOnly(this);
        Orbital.registerTray(this);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LSJ_Starter().setVisible(true);
        });
    }
}
