package v7.Dimensions.Lucid_Frame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Lucifer_Control extends JPanel {

    private JCheckBox flipBox;
    private JCheckBox resizeBox;
    private JCheckBox hueShiftBox;
    private JRadioButton moveOn;
    private JRadioButton moveOff;
    private JComboBox<String> colorModeCombo;

    public Lucifer_Control() {
        setLayout(new GridLayout(0, 1, 5, 5));
        setBorder(BorderFactory.createTitledBorder("Lucifer Control Panel"));

        // ✅ 좌우 반전
        flipBox = new JCheckBox("Flip Mode");
        flipBox.addActionListener(e -> {
            if (flipBox.isSelected()) {
                // Lucifer_Flip();
            }
        });
        add(flipBox);

        // ✅ 크기 조정
        resizeBox = new JCheckBox("Enable Resize");
        resizeBox.addActionListener(e -> {
            if (resizeBox.isSelected()) {
                // Lucifer_Resize(10);
            }
        });
        add(resizeBox);

        // ✅ 색상 모드 선택
        colorModeCombo = new JComboBox<>(new String[]{
            "Default", "HueShift", "Array Color"
        });
        colorModeCombo.addActionListener(e -> {
            String selected = (String) colorModeCombo.getSelectedItem();
            // Lucifer_ColorMode(selected);
        });
        add(new JLabel("Color Mode:"));
        add(colorModeCombo);

        // ✅ 이동 제어 (Radio: 중복 방지)
        moveOn = new JRadioButton("Move ON");
        moveOff = new JRadioButton("Move OFF");
        ButtonGroup moveGroup = new ButtonGroup();
        moveGroup.add(moveOn);
        moveGroup.add(moveOff);

        moveOn.addActionListener(e -> {
            // Lucifer_Start();
        });

        moveOff.addActionListener(e -> {
            // Lucifer_Stop();
        });

        add(moveOn);
        add(moveOff);

        // ✅ 색상 자동 순환 모드 (추후 확장 가능)
        hueShiftBox = new JCheckBox("HueShift Auto Mode");
        hueShiftBox.addActionListener(e -> {
            if (hueShiftBox.isSelected()) {
                // Start hue shift loop
            } else {
                // Stop hue shift loop
            }
        });
        add(hueShiftBox);

        // ✅ 캔리안 주석 ✍️
        // 향후 감정 상태 연동 시 시각 피드백 확장 고려
        // 이 패널은 단순 조작 외에 루시퍼 감정 흐름 전환 허브로 발전 가능
    }
}
