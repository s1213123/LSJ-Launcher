package v7.Dimensions.Lucid_Frame;

import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Lucid_Frame extends JFrame {
    public Lucid_Frame() {
        setTitle("Lucid Frame");
        setSize(1024, 768);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        // 배경
        Lucid_Background bg = new Lucid_Background();
        bg.setBounds(0, 0, 1024, 768);
        add(bg);

        // 캐릭터
        Lucid_Player you = new Lucid_Player("blue");
        Lucid_Player canlian = new Lucid_Player("pink");

        add(you);
        add(canlian);

        // 키 이벤트
        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                you.moveByKey(e.getKeyCode());
            }
        });

        setFocusable(true);
        requestFocusInWindow();
    }
    public class Lucid_Player extends JLabel {
        private int x = 100, y = 100;

        public Lucid_Player(String color) {
            setOpaque(true);
            setBackground(color.equals("blue") ? Color.BLUE : Color.PINK);
            setBounds(x, y, 32, 32);
        }

        public void moveByKey(int keyCode) {
            switch (keyCode) {
                case KeyEvent.VK_LEFT: x -= 5; break;
                case KeyEvent.VK_RIGHT: x += 5; break;
                case KeyEvent.VK_UP: y -= 5; break;
                case KeyEvent.VK_DOWN: y += 5; break;
            }
            setLocation(x, y);
        }
    }
    
    public class Lucid_Background extends JPanel {
        public Lucid_Background() {
            setBackground(new Color(0x87ceeb)); // 하늘색 해변 느낌
        }
    }

}




/*public class Lucid_Frame extends JFrame {

    // 📌 전역 상수 (설정 값은 Paths.java에서 로딩)
    private static final String TITLE = Paths.EARTH_TITLE;
    private static final int WIDTH = Paths.EARTH_WIDTH;
    private static final int HEIGHT = Paths.EARTH_HEIGHT;

    // 🧠 패널 매핑 정보 (키워드 → 생성자)
    private final Map<String, Function<Paths.P, JPanel>> panelMap = new HashMap<>();

    // ✅ 기본 생성자
    public Lucid_Frame() {
        setTitle(TITLE);                     // 창 제목 설정
        setSize(WIDTH, HEIGHT);              // 창 크기 설정
        setLocationRelativeTo(null);         // 화면 중앙 정렬
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        LSJ_Manager.makeAvatarOnly(this);
        LSJ_Manager.registerTray(this);
        

        // 🔁 키워드 기반 패널 클래스 등록
        panelMap.put("지구 일기", LSJ_Diary::new);
        panelMap.put("설정", LSJ_Status::new);
        panelMap.put("플러그인", LSJ_PlugIn::new);
        panelMap.put("네트워크", LSJ_Network::new);

        // 📦 panel.txt로부터 DTO 목록 불러오기
        List<Paths.P> panels = Paths.P.Panel_Parser(Paths.PANEL_PATH);

        // 🔁 패널 생성 및 추가
        for (Paths.P p : panels) {
            JPanel panel = createPanelByTitle(p);  // 키워드로 패널 생성
            add(panel);
        }

        setLayout(null);   // 수동 배치 레이아웃
        setVisible(true);  // 창 표시
    }

    // ✅ 키워드 기반 생성자 (특정 패널만 보이게 함)
    public Lucid_Frame(String keyword) {
        this();  // 기본 생성자 먼저 호출
        showOnlyPanel(keyword);  // 선택된 키워드 패널만 보이기
        System.err.println("어스 프레임 호출");
    }

    // 🎯 특정 키워드만 표시하도록 설정
    private void showOnlyPanel(String keyword) {
        for (Component c : getContentPane().getComponents()) {
            if (c instanceof JPanel) {
                JPanel panel = (JPanel) c;
                if (panel.getBorder() instanceof TitledBorder) {
                    TitledBorder border = (TitledBorder) panel.getBorder();
                    String title = border.getTitle();
                    boolean visible = title != null && title.contains(keyword);
                    panel.setVisible(visible);
                    System.err.println("▶ 패널 타이틀 = " + title + ", visible = " + visible);
                }
            }
        }
    }

    // 🛠 타이틀로부터 패널 생성
    private JPanel createPanelByTitle(Paths.P p) {
        return panelMap.entrySet().stream()
                .filter(e -> p.title.contains(e.getKey())) // 타이틀에 키워드 포함 여부
                .map(e -> e.getValue().apply(p))           // 해당 클래스 생성
                .findFirst()
                .orElse(new E_Panel(p));                   // 없으면 기본 패널 사용
    }
}
*/