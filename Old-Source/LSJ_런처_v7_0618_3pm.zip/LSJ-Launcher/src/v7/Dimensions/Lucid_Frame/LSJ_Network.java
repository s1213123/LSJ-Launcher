package v7.Dimensions.Lucid_Frame;

import v7.Core.Paths;
import v7.Dimensions.Earth_Frame.E_Panel;

public class LSJ_Network extends E_Panel {
    public LSJ_Network(Paths.P p) {
        super(p);
        // 네트워크용 요소 추가 예정
        
    	System.out.println("더미 네트워크 생성");
        
    }
}