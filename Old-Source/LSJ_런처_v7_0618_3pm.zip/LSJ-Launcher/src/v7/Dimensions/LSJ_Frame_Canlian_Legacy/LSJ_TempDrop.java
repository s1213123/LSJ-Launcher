package v7.Dimensions.LSJ_Frame_Canlian_Legacy;

import v7.Core.Paths;

import javax.swing.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.*;
import java.io.File;
import java.util.List;

public class LSJ_TempDrop extends E_Panel {

    private JTextArea dropArea;

    public LSJ_TempDrop(Paths.P p) {
        super(p);
        setLayout(null);

        dropArea = new JTextArea("여기로 파일을 드래그하세요");
        dropArea.setEditable(false);
        dropArea.setBounds(20, 30, p.w - 40, p.h - 60);
        dropArea.setLineWrap(true);
        add(new JScrollPane(dropArea));

        new DropTarget(dropArea, new DropTargetAdapter() {
            @Override
            public void drop(DropTargetDropEvent dtde) {
                try {
                    dtde.acceptDrop(DnDConstants.ACTION_COPY);
                    List<File> droppedFiles = (List<File>) dtde.getTransferable().getTransferData(DataFlavor.javaFileListFlavor);

                    dropArea.setText("");
                    for (File file : droppedFiles) {
                        dropArea.append(file.getAbsolutePath() + "\n");
                    }
                } catch (Exception ex) {
                    dropArea.setText("드롭 실패: " + ex.getMessage());
                }
            }
        });
    }
}  
