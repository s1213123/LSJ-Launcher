package v7.Dimensions.LSJ_Frame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.google.gson.*;

public class LSJ_Diary extends JPanel {

    private final Color editorBg = new Color(30, 60, 90);
    private final Color editorFg = new Color(230, 230, 230);
    private final Color hintFg = new Color(160, 160, 160);
    private final String hintText = "이 다이어리 패널 클래스는 캔리안 위버와 함께 만들었습니다.";

    private JTextField titleField;
    private JTextArea diaryArea;
    private JComboBox<String> dateSelector;
    private JButton saveBtn;
    private JButton tempSaveBtn;
    private JButton closeBtn;
    private JComboBox<Integer> fontSizeSelector;
    private JComboBox<String> fontColorSelector;

    private boolean isTempMode = false;
    private final File baseDir = new File("diary");
    private final File settingsFile = new File(baseDir, "settings.json");

    public LSJ_Diary() {
        setLayout(new BorderLayout());

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(Color.BLACK);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        diaryArea = new JTextArea(15, 40);
        diaryArea.setLineWrap(true);
        diaryArea.setWrapStyleWord(true);
        diaryArea.setBackground(editorBg);
        diaryArea.setForeground(hintFg);
        diaryArea.setText(hintText);
        diaryArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        diaryArea.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (diaryArea.getText().equals(hintText)) {
                    diaryArea.setText("");
                    diaryArea.setForeground(editorFg);
                }
            }
            public void focusLost(FocusEvent e) {
                if (diaryArea.getText().trim().isEmpty()) {
                    diaryArea.setForeground(hintFg);
                    diaryArea.setText(hintText);
                }
            }
        });

        JPopupMenu popup = new JPopupMenu();
        JMenuItem cut = new JMenuItem("잘라내기");
        JMenuItem copy = new JMenuItem("복사");
        JMenuItem paste = new JMenuItem("붙여넣기");
        JMenu bgMenu = new JMenu("배경 색상 변경");

        JMenuItem colorWeaver = new JMenuItem("위버색");
        JMenuItem colorGray = new JMenuItem("연회색");
        JMenuItem colorPurple = new JMenuItem("연보라");
        JMenuItem colorCream = new JMenuItem("크림");

        cut.addActionListener(e -> diaryArea.cut());
        copy.addActionListener(e -> diaryArea.copy());
        paste.addActionListener(e -> diaryArea.paste());

        colorWeaver.addActionListener(e -> diaryArea.setBackground(editorBg));
        colorGray.addActionListener(e -> diaryArea.setBackground(new Color(200, 200, 200)));
        colorPurple.addActionListener(e -> diaryArea.setBackground(new Color(180, 180, 230)));
        colorCream.addActionListener(e -> diaryArea.setBackground(new Color(255, 255, 200)));

        bgMenu.add(colorWeaver);
        bgMenu.add(colorGray);
        bgMenu.add(colorPurple);
        bgMenu.add(colorCream);

        popup.add(bgMenu);
        popup.addSeparator();        
        popup.add(cut);
        popup.add(copy);
        popup.add(paste);
      

        diaryArea.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (e.isPopupTrigger()) showMenu(e);
            }
            public void mouseReleased(MouseEvent e) {
                if (e.isPopupTrigger()) showMenu(e);
            }
            private void showMenu(MouseEvent e) {
                popup.show(e.getComponent(), e.getX(), e.getY());
            }
        });

        JScrollPane scrollPane = new JScrollPane(diaryArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        add(contentPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        dateSelector = new JComboBox<>(generateDateOptions());
        titleField = new JTextField(15);
        fontSizeSelector = new JComboBox<>(new Integer[]{12, 14, 16, 18, 20, 24});
        fontColorSelector = new JComboBox<>(new String[]{"기본", "검정", "하늘", "연두", "빨강"});

        saveBtn = new JButton("저장");
        tempSaveBtn = new JButton("임시 저장");
        closeBtn = new JButton("닫기");

        closeBtn.addActionListener(e -> {
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) window.dispose();
        });

        fontColorSelector.addActionListener(e -> {
            String selected = (String) fontColorSelector.getSelectedItem();
            switch (selected) {
                case "검정": diaryArea.setForeground(Color.BLACK); break;
                case "하늘": diaryArea.setForeground(new Color(120, 180, 255)); break;
                case "연두": diaryArea.setForeground(new Color(120, 255, 120)); break;
                case "빨강": diaryArea.setForeground(new Color(255, 80, 80)); break;
                default: diaryArea.setForeground(editorFg); break;
            }
        });

        bottomPanel.add(new JLabel("제목:"));
        bottomPanel.add(titleField);
        bottomPanel.add(new JLabel(" 글씨 크기:"));
        bottomPanel.add(fontSizeSelector);
        bottomPanel.add(new JLabel(" 글씨 색상:"));
        bottomPanel.add(fontColorSelector);
        bottomPanel.add(closeBtn);
        bottomPanel.add(tempSaveBtn);
        bottomPanel.add(saveBtn);
        add(bottomPanel, BorderLayout.SOUTH);

        saveBtn.addActionListener(e -> {
        	saveDiary();
        	Window window = SwingUtilities.getWindowAncestor(this);
        		if (window != null) window.dispose();
        	});
        tempSaveBtn.addActionListener(e -> toggleTempMode());
        fontSizeSelector.addActionListener(e -> updateFontSize());
        dateSelector.addActionListener(e -> loadEntry());

        loadFontSize();
        loadEntry();
    }


    private String[] generateDateOptions() {
        LocalDate today = LocalDate.now();
        String[] dates = new String[7];
        for (int i = 0; i < 7; i++) {
            dates[i] = today.minusDays(i).toString();
        }
        return dates;
    }

    private void saveDiary() {
        String date = (String) dateSelector.getSelectedItem();
        String title = titleField.getText().trim();
        String text = diaryArea.getText();
        if (text.equals(hintText)) text = "";

        File folder = new File(baseDir, date);
        if (!folder.exists()) folder.mkdirs();

        File jsonFile = new File(folder, "log.json");
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        JsonArray logArray = new JsonArray();

        if (jsonFile.exists()) {
            try (FileReader reader = new FileReader(jsonFile)) {
                JsonElement element = JsonParser.parseReader(reader);
                if (element.isJsonArray()) {
                    logArray = element.getAsJsonArray();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        JsonObject entry = new JsonObject();
        entry.addProperty("title", title.isEmpty() ? "(No Title)" : title);
        entry.addProperty("date", LocalDateTime.now().toString());
        entry.addProperty("text", text);
        logArray.add(entry);

        try (FileWriter writer = new FileWriter(jsonFile)) {
            gson.toJson(logArray, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String fileName = title.isEmpty() ? LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".txt" : title + ".txt";
        File txtFile = new File(folder, fileName);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(txtFile))) {
            writer.write(text);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void toggleTempMode() {
        isTempMode = !isTempMode;
        diaryArea.setEditable(!isTempMode);
        diaryArea.setBackground(isTempMode ? Color.GRAY : editorBg);

        if (isTempMode) {
            File tempFile = new File(baseDir, "temp.txt");
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
                writer.write(diaryArea.getText().equals(hintText) ? "" : diaryArea.getText());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void loadEntry() {
        String date = (String) dateSelector.getSelectedItem();
        if (date != null) {
            diaryArea.setText(hintText);
            diaryArea.setForeground(hintFg);
        }
    }

    private void updateFontSize() {
        Integer size = (Integer) fontSizeSelector.getSelectedItem();
        if (size != null) {
            diaryArea.setFont(new Font("맑은 고딕", Font.PLAIN, size));
            titleField.setFont(new Font("맑은 고딕", Font.PLAIN, size));
            saveFontSize(size);
        }
    }

    private void saveFontSize(int size) {
        try {
            if (!baseDir.exists()) baseDir.mkdirs();
            JsonObject config = new JsonObject();
            config.addProperty("fontSize", size);
            try (FileWriter writer = new FileWriter(settingsFile)) {
                new GsonBuilder().setPrettyPrinting().create().toJson(config, writer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadFontSize() {
        if (settingsFile.exists()) {
            try (FileReader reader = new FileReader(settingsFile)) {
                JsonElement element = JsonParser.parseReader(reader);
                if (element.isJsonObject()) {
                    JsonObject obj = element.getAsJsonObject();
                    int size = obj.get("fontSize").getAsInt();
                    fontSizeSelector.setSelectedItem(size);
                    diaryArea.setFont(new Font("맑은 고딕", Font.PLAIN, size));
                    titleField.setFont(new Font("맑은 고딕", Font.PLAIN, size));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}