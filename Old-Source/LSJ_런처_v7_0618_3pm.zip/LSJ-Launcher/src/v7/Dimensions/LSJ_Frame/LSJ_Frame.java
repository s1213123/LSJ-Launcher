package v7.Dimensions.LSJ_Frame;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import v7.Core.Paths;
import v7.Core.Orbital;

public class LSJ_Frame extends JFrame {

    // 📌 기본 속성 설정
    private final String LSJ_TITLE = Paths.LSJ_TITLE;
    private final int LSJ_WIDTH = Paths.LSJ_WIDTH;
    private final int LSJ_HEIGHT = Paths.LSJ_HEIGHT;
    private final String LSJ_TITLE_COLOR = Paths.LSJ_TITLE_COLOR;

    // 📌 최소/최대 프레임 크기
    private final int MIN_WIDTH = 400;
    private final int MIN_HEIGHT = 400;
    private final int MAX_WIDTH = 1600;
    private final int MAX_HEIGHT = 1200;

    // 📌 프레임 모드 설정
    private final boolean AlwaysOnTop = Paths.AlwaysOnTop;
    private final boolean SetUndecorated = Paths.SetUndecorated;

    // ✅ 생성자: 액션 명에 따라 타이틀과 패널 구성
    public LSJ_Frame(String action) {
        setTitle(LSJ_TITLE + action);
        LSJ_Frame_UI(); // 프레임 기본 UI 세팅

        // 🔹 커스텀 타이틀 바 생성 및 추가
        JPanel titleBar = new LSJ_TitleBar(this, LSJ_TITLE + "     " + action);
        add(titleBar, BorderLayout.NORTH);

        // 🔹 본문 패널 생성 및 적용
        JPanel panel = createPanelByAction(action);
        if (panel != null) {
            panel.setBackground(Color.decode(LSJ_TITLE_COLOR));
            add(panel, BorderLayout.CENTER);

            // 🔹 Ctrl + 휠로 프레임 크기 조절 지원 (본문에서도)
            panel.addMouseWheelListener(e -> {
                if (e.isControlDown()) {
                    int delta = e.getWheelRotation() * 20;
                    int newWidth = Math.max(MIN_WIDTH, Math.min(getWidth() - delta, MAX_WIDTH));
                    int newHeight = Math.max(MIN_HEIGHT, Math.min(getHeight() - delta * getHeight() / getWidth(), MAX_HEIGHT));
                    setSize(newWidth, newHeight);
                }
            });
        }

        revalidate();
        repaint();
        LSJ_Frame_Debug(); // 디버깅 유틸 호출
    }

    // 🛠️ 프레임의 기본 UI 속성 구성
    private void LSJ_Frame_UI() {
        setSize(LSJ_WIDTH, LSJ_HEIGHT);
        setLocationRelativeTo(null); // 화면 중앙 정렬
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setAlwaysOnTop(AlwaysOnTop);
        setUndecorated(SetUndecorated); // 시스템 타이틀 바 제거

        setLayout(new BorderLayout());
    }

    // 🧱 커스텀 타이틀 바 구성 클래스
    public class LSJ_TitleBar extends JPanel {
        private Point initialClick;

        public LSJ_TitleBar(JFrame frame, String title) {
            setLayout(new BorderLayout());
            setPreferredSize(new Dimension(0, 40));
            setBackground(Color.decode(LSJ_TITLE_COLOR));

            // 🔹 타이틀 라벨 좌측 정렬
            JLabel titleLabel = new JLabel("  " + title);
            titleLabel.setForeground(Color.WHITE);
            titleLabel.setFont(new Font("맑은 고딕", Font.BOLD, 15));
            add(titleLabel, BorderLayout.WEST);
/*
            // 🔹 종료 버튼 우측 정렬
            JButton closeButton = new JButton("X");
            closeButton.setFont(new Font("맑은 고딕", Font.BOLD, 12));
            closeButton.setFocusPainted(false);
            closeButton.setContentAreaFilled(false);
            closeButton.setBorderPainted(false);
            closeButton.setForeground(Color.WHITE);
            closeButton.setOpaque(false);
            closeButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            closeButton.addActionListener(e -> frame.dispose());
*/
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 2));
            buttonPanel.setOpaque(false);
//            buttonPanel.add(closeButton);
            add(buttonPanel, BorderLayout.EAST);

            // 🔹 드래그 이동 기능
            addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    initialClick = e.getPoint();
                }
            });

            addMouseMotionListener(new MouseMotionAdapter() {
                public void mouseDragged(MouseEvent e) {
                    int xMoved = e.getX() - initialClick.x;
                    int yMoved = e.getY() - initialClick.y;
                    frame.setLocation(frame.getX() + xMoved, frame.getY() + yMoved);
                }
            });

            // 🔹 Ctrl + 마우스 휠로 크기 조절 (타이틀 바에서도)
            addMouseWheelListener(e -> {
                if (e.isControlDown()) {
                    int delta = e.getWheelRotation() * 20;
                    int newWidth = Math.max(MIN_WIDTH, Math.min(frame.getWidth() - delta, MAX_WIDTH));
                    int newHeight = Math.max(MIN_HEIGHT, Math.min(frame.getHeight() - delta * frame.getHeight() / frame.getWidth(), MAX_HEIGHT));
                    frame.setSize(newWidth, newHeight);
                }
            });
        }
    }

    // 🧩 액션 명에 따라 대응하는 JPanel 생성
    private JPanel createPanelByAction(String action) {
        switch (action) {
            case "LSJ_Diary": return new LSJ_Diary();
            case "LSJ_Status": return new LSJ_Status();
            case "LSJ_Drawing": return new LSJ_Drawing();
          //  case "LSJ_TempDrop": return new LSJ_TempDrop();
            case "LSJ_Launcher": return new LSJ_Launcher();
            case "LSJ_PlugIn": return new LSJ_PlugIn();
            default: return null;
        }
    }

    // 🧪 디버그/공통 초기화 작업
    private void LSJ_Frame_Debug() {
        //Orbital.makeAvatarOnly(this); // 예: 드래그 제한 해제 등
    }
}
