// 리팩토링된 LSJ_Drawing.java - 주요 기능별로 주석 및 가독성 개선

package v7.Dimensions.LSJ_Frame;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayDeque;
import java.util.Deque;

import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;

public class LSJ_Drawing extends JPanel {
	 // === 기본 상수 설정 ===
    private static final int MARGIN = 10;
    private static final int HANDLE_SIZE = 8;

    // === 캔버스 및 그래픽 ===
    private BufferedImage canvas;
    private Graphics2D g2;
    private int prevX, prevY;

    // === 상태 및 설정 ===
    private Color currentColor = Color.BLACK;
    private int strokeWidth = 2;
    private boolean tempSaved = false;
    private boolean isDrawing = false;

    // === UI 컴포넌트 ===
    private JTextField titleField;
    private JButton saveButton, tempSaveButton, colorButton, confirmButton;
    private JComboBox<String> strokeSelector;
    private JPanel drawingArea;
    private JPopupMenu popupMenu;

    // === 선택 및 우클릭 위치 ===
    private Rectangle selectionArea = null;
    private Point selectionStart = null;
    private Point lastRightClick = null;

    // === 붙여넣기 이미지 관련 ===
    private BufferedImage floatingImage = null;
    private Rectangle floatingRect = null;
    private boolean draggingFloating = false;
    private boolean resizingFloating = false;
    private Point dragOffset = null;

    // === 히스토리 스택 ===
    private final Deque<BufferedImage> history = new ArrayDeque<>();


    public LSJ_Drawing() {
        setLayout(new BorderLayout());
        setBackground(Color.decode("#F4F4F4"));

        initCanvas();
        initDrawingArea();
        initControls();
        setupPopupMenu();
        setupPasteHotkey();
    }


    // === 캔버스 초기화 ===
    private void initCanvas() {
        canvas = new BufferedImage(800, 500, BufferedImage.TYPE_INT_ARGB);
        g2 = canvas.createGraphics();
        applyGraphicsDefaults();
    }

    // === 드로잉 영역 구성 및 마우스 이벤트 처리 ===
    private void initDrawingArea() {
        drawingArea = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(Color.DARK_GRAY);
                g.fillRect(0, 0, getWidth(), getHeight());
                g.drawImage(canvas, MARGIN, MARGIN, null);

                if (floatingImage != null && floatingRect != null) {
                    g.drawImage(floatingImage, floatingRect.x + MARGIN, floatingRect.y + MARGIN, floatingRect.width, floatingRect.height, null);
                    g.setColor(Color.RED);
                    g.drawRect(floatingRect.x + MARGIN, floatingRect.y + MARGIN, floatingRect.width , floatingRect.height);
                    g.fillRect(floatingRect.x + MARGIN + floatingRect.width - HANDLE_SIZE, floatingRect.y + MARGIN + floatingRect.height - HANDLE_SIZE, HANDLE_SIZE, HANDLE_SIZE);
                }
            }
        };

        drawingArea.setBackground(Color.LIGHT_GRAY);
        add(drawingArea, BorderLayout.CENTER);

        drawingArea.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                Point p = new Point(e.getX() - MARGIN, e.getY() - MARGIN);
                if (floatingRect != null && floatingRect.contains(p)) {
                    Rectangle handle = new Rectangle(floatingRect.x + floatingRect.width - HANDLE_SIZE, floatingRect.y + floatingRect.height - HANDLE_SIZE, HANDLE_SIZE, HANDLE_SIZE);
                    if (handle.contains(p)) {
                        resizingFloating = true;
                    } else {
                        draggingFloating = true;
                        dragOffset = new Point(p.x - floatingRect.x, p.y - floatingRect.y);
                    }
                } else if (!tempSaved && SwingUtilities.isLeftMouseButton(e)) {
                    isDrawing = true;
                    saveHistory();
                    prevX = p.x;
                    prevY = p.y;
                    selectionArea = null;
                } else if (SwingUtilities.isRightMouseButton(e)) {
                    lastRightClick = p;
                    popupMenu.show(e.getComponent(), e.getX(), e.getY());
                }
            }

            public void mouseReleased(MouseEvent e) {
                draggingFloating = false;
                resizingFloating = false;
                isDrawing = false;
            }
        });

        drawingArea.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                Point p = new Point(e.getX() - MARGIN, e.getY() - MARGIN);
                if (draggingFloating && dragOffset != null) {
                    floatingRect.setLocation(p.x - dragOffset.x, p.y - dragOffset.y);
                } else if (resizingFloating) {
                    floatingRect.setSize(Math.max(10, p.x - floatingRect.x), Math.max(10, p.y - floatingRect.y));
                } else if (!tempSaved && isDrawing) {
                    g2.drawLine(prevX, prevY, p.x, p.y);
                    prevX = p.x;
                    prevY = p.y;
                }
                drawingArea.repaint();
            }
        });

        // 추가된 resize 전용 listener
        drawingArea.addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                adjustCanvasSize();
                drawingArea.repaint();
            }
        });
    }


 

    
    private void initControls() {
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        titleField = new JTextField(15);
        colorButton = new JButton("펜 색상 선택");
        strokeSelector = new JComboBox<>(new String[]{"1px", "3px", "6px", "9px", "12px", "15px", "18px", "21px"});
        saveButton = new JButton("저장");
        tempSaveButton = new JButton("일시 저장");
     
        JButton cancelButton = new JButton("취소");

        colorButton.addActionListener(e -> chooseColor());
        strokeSelector.addActionListener(e -> updateStroke());
        strokeSelector.setSelectedIndex(1);

        saveButton.addActionListener(e -> saveImage(false));
        tempSaveButton.addActionListener(e -> toggleTempSave());
      
        cancelButton.addActionListener(e -> {
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) window.dispose();
        });

     

        bottomPanel.add(colorButton);
        bottomPanel.add(new JLabel("굵기:"));
        bottomPanel.add(strokeSelector);
        
        bottomPanel.add(new JLabel("제목:"));
        bottomPanel.add(titleField);
  
        bottomPanel.add(cancelButton);
        bottomPanel.add(saveButton);
        bottomPanel.add(tempSaveButton);

        bottomPanel.setBackground(Color.DARK_GRAY);
        
        add(bottomPanel, BorderLayout.SOUTH);
    }


    private void applyGraphicsDefaults() {
        g2.setColor(currentColor);
        g2.setStroke(new BasicStroke(strokeWidth));
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setBackground(Color.WHITE);
        g2.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }

    private void adjustCanvasSize() {
        int newWidth = getWidth() - 2 * MARGIN;
        int newHeight = getHeight() - 2 * MARGIN;
        if (canvas.getWidth() != newWidth || canvas.getHeight() != newHeight) {
            BufferedImage newCanvas = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);
            Graphics2D gNew = newCanvas.createGraphics();
            gNew.setColor(Color.WHITE);
            gNew.fillRect(0, 0, newWidth, newHeight);
            gNew.drawImage(canvas, 0, 0, null);
            gNew.dispose();
            canvas = newCanvas;
            g2 = canvas.createGraphics();
            applyGraphicsDefaults();
        }
    }

    private void chooseColor() {
        Color chosen = JColorChooser.showDialog(this, "LSJ 펜 색상 선택", currentColor);
        if (chosen != null) {
            currentColor = chosen;
            g2.setColor(currentColor);
        }
    }

    private void updateStroke() {
        String selected = (String) strokeSelector.getSelectedItem();
        switch (selected) {
            case "1px": strokeWidth = 1; break;
            case "3px": strokeWidth = 3; break;
            case "6px": strokeWidth = 6; break;
            case "9px": strokeWidth = 9; break;
            case "12px": strokeWidth = 12; break;
            case "15px": strokeWidth = 15; break;
            case "18px": strokeWidth = 18; break;
            case "21px": strokeWidth = 21; break;
            
            default: strokeWidth = 3; break;
        }
        g2.setStroke(new BasicStroke(strokeWidth));
    }

    // 히스토리 저장
    private void saveHistory() {
        BufferedImage snapshot = new BufferedImage(canvas.getWidth(), canvas.getHeight(), canvas.getType());
        Graphics g = snapshot.getGraphics();
        g.drawImage(canvas, 0, 0, null);
        g.dispose();
        history.push(snapshot);
    }
    
    // 되돌리기
    private void undo() {
    	if (!history.isEmpty()) {
            canvas = history.pop();
            g2 = canvas.createGraphics();
            g2.setStroke(new BasicStroke(strokeWidth)); // 현재 굵기 유지
            g2.setColor(currentColor);                  // 현재 색상 유지
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            floatingImage = null;
            floatingRect = null;
            drawingArea.repaint();
        }
    }


    public void saveImage(boolean isTemp) {
        try {
            String title = titleField.getText().trim();
            if (title.isEmpty() && !isTemp) {
                JOptionPane.showMessageDialog(this, "제목을 입력해주세요.");
                return;
            }
            if (title.isEmpty()) title = "temp";
            String folder = isTemp ? "C:/LSJ_Draws/temp" : "C:/LSJ_Draws";
            File dir = new File(folder);
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, title + ".png");
            ImageIO.write(canvas, "png", file);
            if (!isTemp) {
                JOptionPane.showMessageDialog(this, "저장 완료: " + file.getAbsolutePath());
                Window window = SwingUtilities.getWindowAncestor(this);
                if (window != null) window.dispose();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "저장 실패: " + ex.getMessage());
        }
    }

    private void toggleTempSave() {
        tempSaved = !tempSaved;
        setEnabled(!tempSaved);
        setBackground(tempSaved ? Color.LIGHT_GRAY : null);
        tempSaveButton.setText(tempSaved ? "복귀" : "일시 저장");
        if (tempSaved) saveImage(true);
    }

    private void importImage() {
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                Image img = ImageIO.read(fileChooser.getSelectedFile());
                int w = img.getWidth(null);
                int h = img.getHeight(null);
                floatingImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
                Graphics2D gImg = floatingImage.createGraphics();
                gImg.drawImage(img, 0, 0, null);
                gImg.dispose();
                floatingRect = new Rectangle(50, 50, w, h);
                saveHistory();
                drawingArea.repaint();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "이미지를 불러올 수 없습니다: " + ex.getMessage());
            }
        }
    }



    private void setupPopupMenu() {
        popupMenu = new JPopupMenu();
        addColorMenuItem("검정", Color.BLACK);
        addColorMenuItem("빨강", Color.RED);
        addColorMenuItem("파랑", Color.BLUE);

        JMenuItem eraser = new JMenuItem("지우개 모드");
        eraser.addActionListener(e -> g2.setColor(Color.WHITE));
        popupMenu.add(eraser);


        popupMenu.addSeparator();

        JMenuItem importImageItem = new JMenuItem("이미지 불러오기");
        importImageItem.addActionListener(e -> importImage());
        popupMenu.add(importImageItem);

        JMenuItem confirmImage = new JMenuItem("불러온 이미지 확정");
        confirmImage.addActionListener(e -> confirmFloatingImage());
        popupMenu.add(confirmImage);


        popupMenu.addSeparator();

        JMenuItem paste = new JMenuItem("버퍼 이미지 가져오기");
        paste.addActionListener(e -> pasteImageAt(lastRightClick != null ? lastRightClick : new Point(0, 0)));
        popupMenu.add(paste);

        JMenuItem confirmPaste = new JMenuItem("버퍼 이미지 붙여넣기");
        confirmPaste.addActionListener(e -> confirmFloatingImage());
        popupMenu.add(confirmPaste);

        popupMenu.addSeparator();

        JMenuItem clear = new JMenuItem("전체 지우기");
        clear.addActionListener(e -> {
            g2.setColor(Color.WHITE);
            g2.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
            g2.setColor(currentColor);
            drawingArea.repaint();
        });
        popupMenu.add(clear);
        
        JMenuItem undo = new JMenuItem("되돌리기");
        undo.addActionListener(e -> undo());
        popupMenu.add(undo);
        

    }
    
    private void addColorMenuItem(String name, Color color) {
        JMenuItem item = new JMenuItem(name);
        item.addActionListener(e -> {
            currentColor = color;
            g2.setColor(color);
        });
        popupMenu.add(item);
    }

    private void setupPasteHotkey() {
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("control V"), "paste");
        getActionMap().put("paste", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                pasteImageAt(new Point(0, 0));
            }
        });
    }
    // === 붙여넣기 처리 ===
    private void pasteImageAt(Point point) {
        try {
            Transferable t = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);
            if (t != null && t.isDataFlavorSupported(DataFlavor.imageFlavor)) {
                Image img = (Image) t.getTransferData(DataFlavor.imageFlavor);
                int w = img.getWidth(null);
                int h = img.getHeight(null);
                floatingImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
                Graphics2D gImg = floatingImage.createGraphics();
                gImg.drawImage(img, 0, 0, null);
                gImg.dispose();
                floatingRect = new Rectangle(point.x, point.y, w, h);
                drawingArea.repaint();
            } else {
                JOptionPane.showMessageDialog(this, "클립보드에 이미지가 없습니다.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "붙여넣기 실패: " + ex.getMessage());
        }
    }

    private void confirmFloatingImage() {
        if (floatingImage != null && floatingRect != null) {
            saveHistory();
            g2.drawImage(floatingImage, floatingRect.x, floatingRect.y, floatingRect.width, floatingRect.height, null);
            floatingImage = null;
            floatingRect = null;
            drawingArea.repaint();
        }
    }

} // end of class
