package v7.Dimensions.LSJ_Frame;

import javax.swing.JPanel;
import javax.swing.JTextArea;

public class LSJ_PlugIn extends JPanel {
    public LSJ_PlugIn() {
        setLayout(null);
        JTextArea area = new JTextArea("일기 내용을 여기에 작성하세요.");
        area.setBounds(10, 10, 500, 300);
        add(area);
    }
}
