package v7.Dimensions.LSJ_Frame;

import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.net.InetAddress;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class LSJ_Status extends JPanel {

    private JLabel cpuLabel, memoryLabel, timeLabel, localIpLabel, externalIpLabel, osInfoLabel;
    private JButton refreshBtn, shutdownBtn;
   // private JComboBox<String> timeComboBox;
  //  private String[] times = { "10분", "30분", "1시간", "2시간" };
  
    
    public LSJ_Status() {
        setLayout(null);
        setBackground(Color.decode("#1e354d"));

        cpuLabel = createLabel("CPU 사용률: ", 20);
        memoryLabel = createLabel("메모리 사용량: ", 60);
        timeLabel = createLabel("현재 시간: ", 100);
        localIpLabel = createLabel("로컬 IP: ", 140);
        externalIpLabel = createLabel("외부 IP: 불러오는 중...", 180);
        osInfoLabel = createLabel("운영체제 정보: ", 220);

        refreshBtn = createButton("🔄 수동 새로고침", 30, 270, e -> updateAll());
        shutdownBtn = createButton("⏳ 종료 예약 (30분)", 300, 270, e -> reserveShutdown());
        
        
       // timeComboBox = new JComboBox<>(times);
      
       // timeComboBox.setBounds(400, 270, 100, 30);
       // add(timeComboBox);
        
        add(osInfoLabel);
        add(cpuLabel);
        add(memoryLabel);
        add(timeLabel);
        add(localIpLabel);
        add(externalIpLabel);
        
        
        add(refreshBtn);
        add(shutdownBtn);

        updateAll();
        startAutoRefresh();
        fetchExternalIP();
    }

    private JLabel createLabel(String text, int y) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("맑은 고딕", Font.PLAIN, 13));
        label.setBounds(30, y, 450, 30);
        return label;
    }

    private JButton createButton(String text, int x, int y, java.awt.event.ActionListener action) {
        JButton btn = new JButton(text);
        btn.setBounds(x, y, 170, 30);
        return btn;
    }

    private void updateAll() {
        try {
            OperatingSystemMXBean osBean = ManagementFactory.getOperatingSystemMXBean();
            double cpuLoad = getProcessCpuLoad(osBean);
            cpuLabel.setText("CPU 사용률: " + String.format("%.1f", cpuLoad * 100) + " %");

            long used = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
            long total = Runtime.getRuntime().totalMemory();
            memoryLabel.setText("메모리 사용량: " + (used / 1024 / 1024) + "MB / " + (total / 1024 / 1024) + "MB");

            timeLabel.setText("현재 시간: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
            localIpLabel.setText("로컬 IP: " + InetAddress.getLocalHost().getHostAddress());

            String osInfo = System.getProperty("os.name") + " / " + System.getProperty("os.arch");
            osInfoLabel.setText("운영체제 정보: " + osInfo);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void startAutoRefresh() {
        Timer timer = new Timer(true);
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                SwingUtilities.invokeLater(() -> updateAll());
            }
        }, 0, 2000);
    }

    private void fetchExternalIP() {
        new Thread(() -> {
            try {
                URL url = new URL("https://api.ipify.org");
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                String ip = in.readLine();
                SwingUtilities.invokeLater(() -> externalIpLabel.setText("외부 IP: " + ip));
            } catch (Exception e) {
                SwingUtilities.invokeLater(() -> externalIpLabel.setText("외부 IP: 불러오기 실패"));
            }
        }).start();
    }

    private double getProcessCpuLoad(OperatingSystemMXBean osBean) {
        try {
            java.lang.reflect.Method method = osBean.getClass().getMethod("getSystemCpuLoad");
            method.setAccessible(true);
            Object value = method.invoke(osBean);
            if (value instanceof Double) return (Double) value;
        } catch (Exception ignored) {}
        return 0.0;
    }
/*
    private void reserveShutdown() {
        String selected = (String) timeComboBox.getSelectedItem();
        int seconds = switch (selected) {
            case "10분" -> 600;
            case "30분" -> 1800;
            case "1시간" -> 3600;
            case "2시간" -> 7200;
            default -> 1800;
        };

        try {
            String cmd = "shutdown -s -t " + seconds;
            Runtime.getRuntime().exec(cmd);
            JOptionPane.showMessageDialog(this, selected + " 후 시스템 종료 예약됨");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "종료 예약 실패");
        }
    }

*/
    
    private void reserveShutdown() {
        try {
            String cmd = "shutdown -s -t 1800"; // 30분 후 종료
            Runtime.getRuntime().exec(cmd);
            JOptionPane.showMessageDialog(this, "30분 후 시스템 종료가 예약되었습니다.");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "종료 예약 실패");
        }
    }
}
