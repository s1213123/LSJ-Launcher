package v7.Avatars;

import java.awt.Color;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import v7.Core.Paths;
import v7.Core.Orbital;

public class A_Portal extends JPanel {

    // 경로 변수
    private static final int WIDTH = Paths.MIN_WIDTH;
    private static final int HEIGHT = Paths.MIN_HEIGHT;
   // private static final String IMAGE_PATH = "src/resources/images/portal.png"; // 포탈 이미지 경로
    //private static final String PORTAL_RESOURCE_PATH = "/images/portal.png";       // 포탈 이미지 경로
  
    private static final String IMAGE_PATH = Paths.IMAGE_PATH_PORTAL; // 포탈 이미지 경로
    //private static final String PORTAL_RESOURCE_PATH = Paths.IMAGE_PATH_PORTAL;       // 포탈 이미지 경로
    
    private static final int Speech_Height = Paths.SPEECH_HEIGHT;

    // UI 구성

//    String[] sampleLines = { "안녕!", "나는 포탈이야", "루시드 안에서 깨어났어", "www.dgmayor.com" };
    String[] sampleLines = Paths.sampleLines;
    
    protected JLabel speechLabel;
    protected JLabel imageLabel;
    protected JLabel inputLabel;

    private JFrame parentFrame;
    private Whisper avatarCall;
    
    
    public A_Portal(JFrame parentFrame) {
        this.parentFrame = parentFrame;
        this.avatarCall = new Whisper();

        setLayout(null);
        setOpaque(true);

        // 💬 기본 UI 라벨 구성
        
        // 더미 스피치 라벨
        Random rand = new Random();
        int randomIndex = rand.nextInt(sampleLines.length);
        
        speechLabel = new JLabel(sampleLines[randomIndex]);
        speechLabel.setHorizontalAlignment(SwingConstants.CENTER);
        speechLabel.setBounds(0, 0, WIDTH, Speech_Height);
        add(speechLabel);

        // 기본 이미지 설정
        imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        imageLabel.setBounds(0, Speech_Height, WIDTH, HEIGHT - Speech_Height * 2);
        ImageIcon icon = new ImageIcon(IMAGE_PATH);
        Image scaled = icon.getImage().getScaledInstance(WIDTH, HEIGHT, Image.SCALE_SMOOTH);
        imageLabel.setIcon(new ImageIcon(scaled));
        add(imageLabel);

        // 기본 입력 안내 라벨
        inputLabel = new JLabel("Click or drag here");
        inputLabel.setHorizontalAlignment(SwingConstants.CENTER);
        inputLabel.setBounds(0, HEIGHT - Speech_Height, WIDTH, Speech_Height);
        add(inputLabel);

        // 디버그 이미지
        debugImage();

        // 마우스 이벤트 등록
        addMouseEvents();
    }

    // 💬 디버그 정보 출력
    private void debugImage() {
        // 트레이 매니저
    	Orbital.applyPanelBorder(this, Color.BLUE);
/*
        System.err.println("코어 패널");
        System.out.println("IMAGE_PATH = " + IMAGE_PATH);
        ImageIcon icon = new ImageIcon(IMAGE_PATH);
        System.out.println("icon width: " + icon.getIconWidth());
        System.out.println("icon height: " + icon.getIconHeight());

        try {
            java.net.URL url = getClass().getResource(PORTAL_RESOURCE_PATH);
            if (url == null) {
                System.out.println(" getResource() 포탈 리소스 경로: " + PORTAL_RESOURCE_PATH);
            } else {
                System.out.println(" getResource 경로: " + url.getPath());
                ImageIcon icon2 = new ImageIcon(url);
                System.out.println("icon2 width: " + icon2.getIconWidth());
                System.out.println("icon2 height: " + icon2.getIconHeight());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }*/
    }

    // 💬 마우스 이벤트 등록
    private void addMouseEvents() {
        MouseAdapter dragListener = new MouseAdapter() {
            Point dragOffset;

            public void mousePressed(MouseEvent e) {
             
                if (SwingUtilities.isRightMouseButton(e)) {
                	
                    avatarCall.function(e.getComponent(), e.getX(), e.getY());

                }
            	dragOffset = e.getPoint();
                   
            }

            public void mouseDragged(MouseEvent e) {
                if (dragOffset != null && parentFrame != null) {
                    Point loc = parentFrame.getLocation();
                    parentFrame.setLocation(loc.x + e.getX() - dragOffset.x, loc.y + e.getY() - dragOffset.y);
                }
            }

       };

        addMouseListener(dragListener);
        addMouseMotionListener(dragListener);
    }
}
