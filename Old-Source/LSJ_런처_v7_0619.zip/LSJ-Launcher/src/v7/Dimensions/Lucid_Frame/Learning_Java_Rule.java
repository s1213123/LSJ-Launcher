package v7.Dimensions.Lucid_Frame;

import javax.swing.*;

import v7.Core.Paths;
import v7.Dimensions.Earth_Frame.E_Panel;
import v7.Dimensions.Earth_Frame.Earth_Frame;
import v7.Dimensions.Earth_Frame.LSJ_Diary_Weaver;
import v7.Dimensions.Earth_Frame.LSJ_Plugin;
import v7.Dimensions.Earth_Frame.LSJ_Viewer;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

public class Learning_Java_Rule extends JFrame {

    private JLabel imageLabel;
    private JPanel imagePanel;
    private BufferedImage bufferedImage;

    public Learning_Java_Rule() {
        setTitle("루시퍼 이미지 테스트");
        setSize(500, 500);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 1️⃣ JLabel에 setIcon으로 이미지 출력
        imageLabel = new JLabel(new ImageIcon("src/resources/lucifer.png"));
        imageLabel.setBounds(10, 10, 150, 150);
        add(imageLabel);

        // 2️⃣ 새로운 JPanel 내부에서 이미지 출력
        imagePanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon("src/resources/canlian.png");
                g.drawImage(icon.getImage(), 0, 0, 150, 150, this);
            }
        };
        imagePanel.setBounds(170, 10, 150, 150);
        imagePanel.setOpaque(false);
        add(imagePanel);

        
        
        
        // 3️⃣ 현재 패널(JFrame)에서 직접 이미지 그리기
        try {
            bufferedImage = ImageIO.read(new File("src/resources/portal.png"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        
        
        
        
        
        /*
		try {
		    URL imageUrl = getClass().getClassLoader().getResource("lucifer.png");
		    if (imageUrl != null) {
		        luciferImage = ImageIO.read(imageUrl);
		    } else {
		        System.err.println("❌ 루시퍼 이미지 경로 찾기 실패 (classpath)");
		    }
		} catch (Exception e) {
		    System.err.println("❌ 루시퍼 이미지 로딩 실패");
		    e.printStackTrace();
		}
*/
/*		
		try {
		    File file = new File(Paths.IMAGE_PATH_LUCIFER);
		    if (!file.exists()) {
		        // 상대 경로 기준으로 다시 재시도
		        file = new File("src/resources/lucifer.png");
		    }

		    if (file.exists()) {
		        luciferImage = ImageIO.read(file);
		    } else {
		        System.err.println("❌ 루시퍼 이미지 파일 없음: " + file.getAbsolutePath());
		    }
		} catch (Exception e) {
		    System.err.println("❌ 루시퍼 이미지 로딩 실패");
		    e.printStackTrace();
		}
		
		
    
    // 로드 패널
    public static JPanel loadPanel(String className, Paths.P p) {
        try {
            Class<?> clazz = Class.forName("v7.Dimensions.earth." + className);
            Constructor<?> constructor = clazz.getConstructor(Paths.P.class);
            return (JPanel) constructor.newInstance(p);
        } catch (Exception e) {
        	System.err.println("❌ 패널 로딩 실패: " + className);
            e.printStackTrace();
            return new E_Panel(p); // 실패 시 기본 패널
        }
    }

    
    // 패널 팩토리 6.11 추가
    public static class PanelFactory {
        public static JPanel create(Paths.P p) {
        
        	
        	switch (p.title) {
            case "LSJ_Diary":
                if (LSJ_Diary.isOpen()) {
                    System.err.println("⛔ 중복 diary 차단됨");
                    return null;
                }
                LSJ_Diary d = new LSJ_Diary(p);
                return d;
                
                
                case "LSJ_Viewer": return new LSJ_Viewer(p);
                case "LSJ_PlugIn": return new LSJ_Plugin(p);
                default: return new E_Panel(p);
            }
        }
    }

// 프레임 레지스트리 6.11 추가
public static class FrameRegistry {
    private static final Map<String, JFrame> registry = new HashMap<>();

    public static void register(String key, JFrame frame) {
        registry.put(key, frame);
    }

    public static JFrame get(String key) {
        return registry.get(key);
    }

    public static boolean isAlive(String key) {
        JFrame f = get(key);
        return f != null && f.isDisplayable();
    }

    public static void showOrAdd(String key, String panelKeyword) {
        if (isAlive(key)) {
            ((Earth_Frame) get(key)).addPanelByKeyword(panelKeyword);
            get(key).toFront();
        } else {
            JFrame f = new Earth_Frame(panelKeyword);
            register(key, f);
        }
    }
		
*/		
		
        
        /*
         * 
    /*
 // 패널 DTO// 🧱 패널 DTO 및 파서
    public static class P {
        public String n, title, bgColor;
        public int x, y, w, h;

        
        p1.title=Earth_Frame
          p1.bgColor=#FF0000
          p1.x=10
          p1.y=10
          p1.w=300
          p1.h=200
        
        // ✅ panel.txt 파싱 → 패널 정보 객체 리스트 반환
        public static List<P> Panel_Parser(String path) {
            List<P> list = new ArrayList<>();
            Map<String, P> map = new LinkedHashMap<>(); // 패널 ID(p1, p2...)별 DTO 누적

            Parser parser = new Parser(); // 공통 파서 사용
            List<String[]> entries = parser.loadList(PANEL_PATH); // [id, field, value] 구조

            for (String[] e : entries) {
                String id = e[0];       // ex) "p1"
                String field = e[1];    // ex) "title" "bgColor" "x"
                String value = e[2];    // ex) "메인"

                // 해당 ID(p1 등)에 대한 P 객체 생성 또는 조회
                P p = map.computeIfAbsent(id, k -> {
                    P temp = new P();
                    temp.n = k;
                    return temp;
                });

                // 필드 값 할당
                switch (field) {
                    case "title":    p.title = value; break;
                    case "bgColor":  p.bgColor = value; break;
                    case "x":        p.x = tryParse(value); break;
                    case "y":        p.y = tryParse(value); break;
                    case "w":        p.w = tryParse(value); break;
                    case "h":        p.h = tryParse(value); break;
                }
            }

            list.addAll(map.values()); // Map → List로 변환 후 반환
            return list;
        }

        // ✅ 문자열을 안전하게 int로 변환하는 보조 함수
        private static int tryParse(String s) {
            try {
                return Integer.parseInt(s);
            } catch (NumberFormatException e) {
                return 0;
            }
        }*/
    
    
    /*
    
    
    //////// 프레임 레지스트리
    public static class FrameRegistry {
        private static final Map<String, JFrame> registry = new HashMap<>();

        
        
        public static void register(JFrame frame, String type, String action) {
            registry.put(type, frame);

            if (frame instanceof ActionReceivable) {
                JPanel panel = CreatePanel(action);
                if (panel != null) {
                    ((ActionReceivable) frame).applyPanel(panel);
                }
            }
        }


        public static JFrame get(String key) {
        
        	return registry.get(key);
        }

    
    }

    // 패널 생성
    public static JPanel CreatePanel(String title) {
    	
        for (Paths.P p : Paths.P.Panel_Parser(Paths.PANEL_PATH)) {
            if (title.equals(p.title)) {
                JPanel panel = new LSJ_Diary(p);
                panel.setBounds(p.x, p.y, p.w, p.h);
                panel.setBackground(Color.decode(p.bgColor));
                System.out.println("✅ 패널 생성: " + panel.getClass().getSimpleName());

                return panel;
            }
        }
        return null;
    }
// 패널 구현
    public interface ActionReceivable {
        void applyPanel(JPanel panel);
    }


    
    
    }

    
    
         */
        
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        if (bufferedImage != null) {
            g.drawImage(bufferedImage, 330, 40, 150, 150, this);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Learning_Java_Rule().setVisible(true);
        });
    }
}
