package v7.Dimensions.Lucid_Frame;

import javax.swing.*;

import v7.Core.Paths;
import v7.Dimensions.Earth_Frame.E_Panel;

import java.awt.*;

public class LSJ_Status extends E_Panel {

    public LSJ_Status(Paths.P p) {
        //setLayout(null);
        //setBounds(p.x, p.y, p.w, p.h);

    	super(p);
    	
    	System.out.println("더미 상태 생성");

        // 📝 일기 전용 UI 구성
        JTextArea diaryArea = new JTextArea();
        diaryArea.setLineWrap(true);
        diaryArea.setWrapStyleWord(true);
        diaryArea.setBounds(10, 25, p.w - 20, p.h - 35);
        add(diaryArea);
    }
}
