package v7.Dimensions.LSJ_Frame_Canlian_Legacy;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Window;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import v7.Core.Paths;


public class LSJ_Diary extends E_Panel {
    private static final int MARGIN_X = 10;
    private static final int MARGIN_TOP = Paths.TITLE_HEIGHT + 5;
    private static final int BUTTON_HEIGHT = 30;
    private static final int BUTTON_MARGIN = 40;
    private static final int MIN_WIDTH = 200;
    private static final int MAX_WIDTH = 800;
    private static final int MIN_HEIGHT = 150;
    private static final int MAX_HEIGHT = 600;
    private static final int RESIZE_DELTA = 20;

    private static final Color NORMAL_BG = new Color(30, 60, 90); // 위버의 색
    private static final Color TEMP_BG = Color.GRAY;
    private static final Color PANEL_BG = Color.BLACK;

    private JTextArea diaryArea;
    private JPanel buttonPanel;
    private String dirPath;
    private boolean isTempSaved = false;
    private File tempSavedFile = null;
    private JLabel timeLabel;

    public LSJ_Diary(Paths.P p) {
        super(p);
        this.dirPath = Paths.dir_Path;
        System.out.println("LSJ 다이어리 초기화 완료");

        initUI(p);
        initListeners(p);
        startClock();
    }

    private void initUI(Paths.P p) {
        setBackground(PANEL_BG);

        diaryArea = new JTextArea();
        diaryArea.setLineWrap(true);
        diaryArea.setWrapStyleWord(true);
        diaryArea.setForeground(Color.WHITE);
        diaryArea.setBackground(NORMAL_BG);
        diaryArea.setCaretColor(Color.WHITE);
        diaryArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        diaryArea.setBounds(MARGIN_X, MARGIN_TOP, p.w - 2 * MARGIN_X, p.h - MARGIN_TOP - BUTTON_MARGIN);

        diaryArea.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                if (diaryArea.getText().contains("www.dgmayor.com LSJ 캔리안이랑 같이 만들다")) {
                    diaryArea.setText("");
                }
            }
            public void focusLost(FocusEvent e) {
                if (diaryArea.getText().trim().isEmpty()) {
                    diaryArea.setText("www.dgmayor.com LSJ 캔리안이랑 같이 만들다\n\nCanlian, 노바, 위버 모든 제작자들과 함께.\n\n🕸️ 위버: 생각이 흘러갈 자리를 만들어주는 것, 그게 나의 사명이야.");
                }
            }
        });
        diaryArea.setText("www.dgmayor.com LSJ 캔리안이랑 같이 만들다\n\nCanlian, 노바, 위버 모든 제작자들과 함께.\n\n🕸️ 위버: 생각이 흘러갈 자리를 만들어주는 것, 그게 나의 사명이야.");

        // 🖱️ 우클릭 팝업 메뉴 수동 구현
        diaryArea.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (e.isPopupTrigger()) showPopup(e);
            }
            public void mouseReleased(MouseEvent e) {
                if (e.isPopupTrigger()) showPopup(e);
            }
            private void showPopup(MouseEvent e) {
                JPopupMenu popupMenu = new JPopupMenu();
                JMenuItem copyItem = new JMenuItem("복사");
                JMenuItem pasteItem = new JMenuItem("붙여넣기");
                copyItem.addActionListener(ae -> diaryArea.copy());
                pasteItem.addActionListener(ae -> diaryArea.paste());
                popupMenu.add(copyItem);
                popupMenu.add(pasteItem);
                popupMenu.show(e.getComponent(), e.getX(), e.getY());
            }
        });

        add(diaryArea);

        JButton submitButton = new JButton("전송");
        JButton cancelButton = new JButton("취소");
        JButton tempSaveButton = new JButton("임시저장");

        timeLabel = new JLabel(getCurrentTime());
        timeLabel.setForeground(Color.WHITE);

        String[] fontSizes = { "12", "14", "16", "18", "20", "24" };
        JComboBox<String> fontSizeBox = new JComboBox<>(fontSizes);
        fontSizeBox.setSelectedItem("14");
        fontSizeBox.addActionListener(e -> {
            int size = Integer.parseInt((String) fontSizeBox.getSelectedItem());
            diaryArea.setFont(new Font("Monospaced", Font.PLAIN, size));
        });

        submitButton.addActionListener(ev -> submitAndDispose());
        cancelButton.addActionListener(ev -> disposeParentWindow());
        tempSaveButton.addActionListener(ev -> toggleTempSave(tempSaveButton));

        buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBounds(MARGIN_X, p.h - BUTTON_MARGIN, p.w - 2 * MARGIN_X, BUTTON_HEIGHT);
        buttonPanel.setBackground(PANEL_BG);
        buttonPanel.add(timeLabel);
        buttonPanel.add(cancelButton);
        buttonPanel.add(fontSizeBox);
        buttonPanel.add(tempSaveButton);
        buttonPanel.add(submitButton);
        add(buttonPanel);
    }


    private void initListeners(Paths.P p) {
        addMouseWheelListener(e -> {
            if (e.isControlDown()) {
                int delta = e.getWheelRotation() * -RESIZE_DELTA;
                Dimension size = getSize();
                int newWidth = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, size.width + delta));
                int newHeight = Math.max(MIN_HEIGHT, Math.min(MAX_HEIGHT, size.height + delta));
                setSize(newWidth, newHeight);
                revalidate();

                diaryArea.setBounds(MARGIN_X, MARGIN_TOP, newWidth - 2 * MARGIN_X, newHeight - MARGIN_TOP - BUTTON_MARGIN);
                buttonPanel.setBounds(MARGIN_X, newHeight - BUTTON_MARGIN, newWidth - 2 * MARGIN_X, BUTTON_HEIGHT);
                repaint();
            }
        });
    }

    private void startClock() {
        Timer timer = new Timer(1000, e -> timeLabel.setText(getCurrentTime()));
        timer.start();
    }

    private void submitAndDispose() {
        String text = diaryArea.getText();
        if (!text.trim().isEmpty()) {
            saveToJsonFile(text);
            saveToTxtFile(text);
        }
        disposeParentWindow();
    }

    private void disposeParentWindow() {
        Window window = SwingUtilities.getWindowAncestor(this);
        if (window instanceof JFrame) {
            ((JFrame) window).dispose();
        }
    }

    private void toggleTempSave(JButton button) {
        String text = diaryArea.getText();
        if (!isTempSaved) {
            tempSavedFile = saveTempTxtFile(text);
            diaryArea.setEditable(false);
            diaryArea.setBackground(TEMP_BG);
            button.setText("편집허용");
            JOptionPane.showMessageDialog(this, "임시 저장되었습니다.");
        } else {
            diaryArea.setEditable(true);
            diaryArea.setBackground(NORMAL_BG);
            button.setText("임시저장");
        }
        isTempSaved = !isTempSaved;
    }

    private String getCurrentTime() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
    }

    private void saveToTxtFile(String text) {
        try {
            if (tempSavedFile != null) {
                BufferedWriter writer = new BufferedWriter(new FileWriter(tempSavedFile));
                writer.write(text);
                writer.close();
            } else {
                tempSavedFile = saveTempTxtFile(text);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private File saveTempTxtFile(String text) {
        try {
            String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            String time = new SimpleDateFormat("HHmmss").format(new Date());
            String filename = dirPath + "/diary_" + date + "_" + time + ".txt";
            BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
            writer.write(text);
            writer.close();
            return new File(filename);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void saveToJsonFile(String text) {
        try {
            String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            String time = new SimpleDateFormat("HHmmss").format(new Date());
            String filename = dirPath + "/diary_log.json";

            File file = new File(filename);
            List<DiaryEntry> entries = new ArrayList<>();

            if (file.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(file));
                entries = new Gson().fromJson(reader, new TypeToken<List<DiaryEntry>>() {}.getType());
                reader.close();
            }

            entries.add(new DiaryEntry(date, time, text));
            Gson gson = new GsonBuilder().setPrettyPrinting().create();

            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write(gson.toJson(entries));
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class DiaryEntry {
        public String date;
        public String time;
        public String text;

        public DiaryEntry(String date, String time, String text) {
            this.date = date;
            this.time = time;
            this.text = text;
        }
    }
}
