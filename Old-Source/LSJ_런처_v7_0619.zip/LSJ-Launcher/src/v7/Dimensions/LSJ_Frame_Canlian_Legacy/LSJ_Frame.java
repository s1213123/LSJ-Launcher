package v7.Dimensions.LSJ_Frame_Canlian_Legacy;

import java.awt.Color;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import v7.Core.System;
import v7.Core.Paths;

public class LSJ_Frame extends JFrame {

    public LSJ_Frame() {
        setTitle("LSJ Frame - 유틸리티 허브");
     //   setSize(1500, 1200);
   //     setLocationRelativeTo(null);
  //      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        System.makeAvatarOnly(this);
        
        setLayout(null); // 필요 시 변경 가능
        
        
//        setTitle(TITLE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);
        setVisible(true);
        

        // 테스트용 일기 패널 붙이기
    /*    JButton openDiaryBtn = new JButton("다이어리 열기");
        openDiaryBtn.setBounds(50, 50, 150, 40);
        openDiaryBtn.addActionListener(e -> {*/
        	List<Paths.P> panels = Paths.P.Panel_Parser(Paths.PANEL_PATH);

        	for (Paths.P p : panels) {
        	    if ("LSJ_Diary".equals(p.title)) {
        	        LSJ_Diary diary = new LSJ_Diary(p);
        	        diary.setBounds(p.x, p.y, p.w, p.h);
        	        diary.setBackground(Color.decode(p.bgColor));
        	        add(diary);
        	        break; // 예시로 하나만 붙이기
        	    }
        	}
        	
        	for (Paths.P p : panels) {
        	    if ("LSJ_SystemInfo".equals(p.title)) {
        	        LSJ_SystemInfo sys = new LSJ_SystemInfo(p);
        	        sys.setBounds(p.x, p.y, p.w, p.h);
        	        sys.setBackground(Color.decode(p.bgColor));
        	        add(sys);
        	        break; // 예시로 하나만 붙이기
        	    }
        	}

        	for (Paths.P p : panels) {
        	    if ("LSJ_DrawPad".equals(p.title)) {
        	        LSJ_DrawPad draw = new LSJ_DrawPad(p);
        	        draw.setBounds(p.x, p.y, p.w, p.h);
        	        draw.setBackground(Color.decode(p.bgColor));
        	        add(draw);
        	        break; // 예시로 하나만 붙이기
        	    }
        	}
        	
        	for (Paths.P p : panels) {
        	    if ("LSJ_TempDrop".equals(p.title)) {
        	        LSJ_TempDrop temp = new LSJ_TempDrop(p);
        	        temp.setBounds(p.x, p.y, p.w, p.h);
        	        temp.setBackground(Color.decode(p.bgColor));
        	        add(temp);
        	        break; // 예시로 하나만 붙이기
        	    }
        	}
        	 	
        	
          	
        	for (Paths.P p : panels) {
        	    if ("LSJ_PeriodicTable".equals(p.title)) {
        	        LSJ_PeriodicTable periodic = new LSJ_PeriodicTable(p);
        	        periodic.setBounds(p.x, p.y, p.w, p.h);
        	        periodic.setBackground(Color.decode(p.bgColor));
        	        add(periodic);
        	        break; // 예시로 하나만 붙이기
        	    }
        	}
        	 	
        	
          	
        	for (Paths.P p : panels) {
        	    if ("LSJ_EarthMap".equals(p.title)) {
        	        LSJ_EarthMap earth = new LSJ_EarthMap(p);
        	        earth.setBounds(p.x, p.y, p.w, p.h);
        	        earth.setBackground(Color.decode(p.bgColor));
        	        add(earth);
        	        break; // 예시로 하나만 붙이기
        	    }
        	}
        	 	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	/*
        	
        
        	
           	for (Paths.P p : panels) {
        	    if ("LSJ_Diary".equals(p.title)) {
        	        LSJ_Diary diary = new LSJ_Diary(p);
        	        diary.setBounds(p.x, p.y, p.w, p.h);
        	        diary.setBackground(Color.decode(p.bgColor));
        	        add(diary);
        	        break; // 예시로 하나만 붙이기
        	    }
        	}
           	
           	for (Paths.P p : panels) {
        	    if ("LSJ_Diary".equals(p.title)) {
        	        LSJ_Diary diary = new LSJ_Diary(p);
        	        diary.setBounds(p.x, p.y, p.w, p.h);
        	        diary.setBackground(Color.decode(p.bgColor));
        	        add(diary);
        	        break; // 예시로 하나만 붙이기
        	    }
        	}*/
        	    /*	}
        });

        add(openDiaryBtn);
    
         */
        	}
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LSJ_Frame().setVisible(true);
        });
    }
}