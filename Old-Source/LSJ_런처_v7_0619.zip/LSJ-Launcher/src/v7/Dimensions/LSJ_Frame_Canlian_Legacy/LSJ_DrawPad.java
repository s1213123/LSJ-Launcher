package v7.Dimensions.LSJ_Frame_Canlian_Legacy;

import v7.Core.Paths;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LSJ_DrawPad extends E_Panel {

    private BufferedImage canvas;
    private Graphics2D g2;
    private int prevX, prevY;
    private JTextField titleField;
    private JButton saveButton, tempSaveButton, undoButton, colorButton;
    private JComboBox<String> strokeSelector;
    private Color currentColor = Color.BLACK;
    private int strokeWidth = 2;
    private BufferedImage lastCanvas;
    private JPopupMenu popupMenu;
    private boolean tempSaved = false;
    private Insets canvasMargin = new Insets(10, 10, 10, 10);

    public LSJ_DrawPad(Paths.P p) {
        super(p);
        setLayout(null);

        int canvasWidth = p.w - 20;
        int canvasHeight = p.h - 70;

        canvas = new BufferedImage(canvasWidth, canvasHeight, BufferedImage.TYPE_INT_ARGB);
        g2 = canvas.createGraphics();
        applyGraphicsDefaults();

        titleField = new JTextField();
        titleField.setBounds(10, p.h - 50, 200, 30);
        add(titleField);

        colorButton = new JButton("색상 선택");
        colorButton.setBounds(220, p.h - 50, 100, 30);
        colorButton.addActionListener(e -> {
            Color chosen = JColorChooser.showDialog(this, "색상 선택", currentColor);
            if (chosen != null) {
                currentColor = chosen;
                g2.setColor(currentColor);
            }
        });
        add(colorButton);

        strokeSelector = new JComboBox<>(new String[]{"1px", "3px", "6px"});
        strokeSelector.setBounds(325, p.h - 50, 80, 30);
        strokeSelector.addActionListener(e -> {
            String selected = (String) strokeSelector.getSelectedItem();
            strokeWidth = selected.equals("1px") ? 1 : selected.equals("3px") ? 3 : 6;
            g2.setStroke(new BasicStroke(strokeWidth));
        });
        strokeSelector.setSelectedIndex(1);
        add(strokeSelector);

        saveButton = new JButton("저장");
        saveButton.setBounds(410, p.h - 50, 80, 30);
        saveButton.addActionListener(e -> saveImage(false));
        add(saveButton);

        tempSaveButton = new JButton("일시 저장");
        tempSaveButton.setBounds(495, p.h - 50, 100, 30);
        tempSaveButton.addActionListener(e -> toggleTempSave());
        add(tempSaveButton);

        undoButton = new JButton("취소");
        undoButton.setBounds(600, p.h - 50, 80, 30);
        undoButton.addActionListener(e -> undo());
        add(undoButton);

        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (!tempSaved && SwingUtilities.isRightMouseButton(e)) {
                    popupMenu.show(e.getComponent(), e.getX(), e.getY());
                } else if (!tempSaved) {
                    saveHistory();
                    prevX = e.getX() - canvasMargin.left;
                    prevY = e.getY() - canvasMargin.top;
                }
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                if (!tempSaved) {
                    int x = e.getX() - canvasMargin.left;
                    int y = e.getY() - canvasMargin.top;
                    g2.drawLine(prevX, prevY, x, y);
                    prevX = x;
                    prevY = y;
                    repaint();
                }
            }
        });

        setupPopupMenu();
    }

    private void applyGraphicsDefaults() {
        g2.setColor(currentColor);
        g2.setStroke(new BasicStroke(strokeWidth));
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setBackground(Color.WHITE);
        g2.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }

    private void changeColor(Color color) {
        currentColor = color;
        g2.setColor(currentColor);
    }

    private void saveHistory() {
        lastCanvas = new BufferedImage(canvas.getWidth(), canvas.getHeight(), canvas.getType());
        Graphics2D g = lastCanvas.createGraphics();
        g.drawImage(canvas, 0, 0, null);
        g.dispose();
    }

    private void undo() {
        if (lastCanvas != null) {
            canvas = lastCanvas;
            g2 = canvas.createGraphics();
            applyGraphicsDefaults();
            repaint();
        }
    }

    private void saveImage(boolean isTemp) {
        try {
            String title = titleField.getText().trim();
            if (title.isEmpty()) {
                String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
                title = "draw_" + timestamp;
            }

            String folder = isTemp ? "C:/LSJ_Draws/temp" : "C:/LSJ_Draws";
            File dir = new File(folder);
            if (!dir.exists()) dir.mkdirs();

            File file = new File(dir, title + ".png");
            ImageIO.write(canvas, "png", file);
            if (!isTemp) {
                JOptionPane.showMessageDialog(this, "저장 완료: " + file.getAbsolutePath());
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "저장 실패: " + ex.getMessage());
        }
    }

    private void toggleTempSave() {
        if (!tempSaved) {
            saveImage(true);
            tempSaved = true;
            setEnabled(false);
            setBackground(Color.LIGHT_GRAY);
            tempSaveButton.setText("복귀");
        } else {
            tempSaved = false;
            setEnabled(true);
            setBackground(Color.BLUE);
            tempSaveButton.setText("일시 저장");
        }
    }

    private void setupPopupMenu() {
        popupMenu = new JPopupMenu();

        JMenuItem blackItem = new JMenuItem("검정");
        blackItem.addActionListener(e -> changeColor(Color.BLACK));
        popupMenu.add(blackItem);

        JMenuItem redItem = new JMenuItem("빨강");
        redItem.addActionListener(e -> changeColor(Color.RED));
        popupMenu.add(redItem);

        JMenuItem blueItem = new JMenuItem("파랑");
        blueItem.addActionListener(e -> changeColor(Color.BLUE));
        popupMenu.add(blueItem);

        JMenuItem eraserItem = new JMenuItem("지우개 모드");
        eraserItem.addActionListener(e -> g2.setColor(Color.WHITE));
        popupMenu.add(eraserItem);

        JMenuItem clearItem = new JMenuItem("전체 지우기");
        clearItem.addActionListener(e -> {
            g2.setColor(Color.WHITE);
            g2.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
            g2.setColor(currentColor);
            repaint();
        });
        popupMenu.add(clearItem);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.GRAY);
        g.drawRect(canvasMargin.left - 1, canvasMargin.top - 1, canvas.getWidth() + 1, canvas.getHeight() + 1);
        g.drawImage(canvas, canvasMargin.left, canvasMargin.top, this);
    }
}  


