package v7.Dimensions.LSJ_Frame_Canlian_Legacy;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import v7.Core.Paths;

public class E_Panel extends JPanel {
    private Point dragOffset;

    public E_Panel(Paths.P p) {
        setLayout(null);

        // 🧱 위치 및 크기: panel.txt에서 직접 불러옴
        setBounds(p.x, p.y, p.w, p.h);

        // 🎨 배경색 설정
        String colorHex = (p.bgColor != null) ? p.bgColor : "#cccccc";
        // setBackground(Color.BLACK);

        // 🏷️ 제목 설정
        setBorder(BorderFactory.createTitledBorder(p.title));

        // 🟩 상단 드래그 바 추가 (항상 고정)
        JPanel dragBar = new JPanel();
        dragBar.setLayout(null);
        dragBar.setBounds(0, 0, p.w, Paths.TITLE_HEIGHT);
        dragBar.setBackground(Color.decode(colorHex));
        dragBar.setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));

        // 📝 타이틀: 고정 출력 (조건 없음, 단순 텍스트)
        JLabel label = new JLabel("    " + p.title);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("맑은 고딕", Font.BOLD, 12));
        label.setBounds(0, 0, 200, Paths.TITLE_HEIGHT);
        dragBar.add(label);

        // 📌 더미 아이콘들 (패널 제어용)
        JLabel dummySwitch = new JLabel("📌");
        dummySwitch.setBounds(p.w - 90, 0, 24, Paths.TITLE_HEIGHT);
        dummySwitch.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        dragBar.add(dummySwitch);

        JLabel dummyMin = new JLabel("🗕");
        dummyMin.setBounds(p.w - 65, 0, 24, Paths.TITLE_HEIGHT);
        dummyMin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        dragBar.add(dummyMin);

        JLabel dummyMid = new JLabel("🗗");
        dummyMid.setBounds(p.w - 45, 0, 24, Paths.TITLE_HEIGHT);
        dummyMid.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        dragBar.add(dummyMid);

        JLabel dummyMax = new JLabel("🗖");
        dummyMax.setBounds(p.w - 25, 0, 24, Paths.TITLE_HEIGHT);
        dummyMax.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        dragBar.add(dummyMax);

        // 🧲 드래그 동작
        dragBar.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                dragOffset = e.getPoint();

                
                
                Container parent = getParent();
                if (parent != null) {
                    parent.setComponentZOrder(E_Panel.this, 0);  // 가장 앞으로
                    parent.repaint();
                }
               
                requestFocusInWindow();  // 포커스 확보
            
            
            
            }
        });

        dragBar.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                Point current = SwingUtilities.convertPoint(dragBar, e.getPoint(), getParent());
                setLocation(current.x - dragOffset.x, current.y - dragOffset.y);
            }
        });

        // 패널에 드래그 바 추가
        add(dragBar);
    }
} 
