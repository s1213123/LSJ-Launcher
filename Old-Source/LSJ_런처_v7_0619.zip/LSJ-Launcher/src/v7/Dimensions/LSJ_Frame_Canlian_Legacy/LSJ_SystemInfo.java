package v7.Dimensions.LSJ_Frame_Canlian_Legacy;

import java.awt.Color;
import java.io.File;
import java.net.InetAddress;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JLabel;
import javax.swing.SwingUtilities;

import v7.Core.Paths;
public class LSJ_SystemInfo extends E_Panel {

    JLabel ipLabel;
    JLabel extIpLabel;
    JLabel cpuLabel;
    JLabel osLabel;
    JLabel memLabel;
    JLabel diskLabel;
    JLabel netLabel;
    JLabel timeLabel;

    public LSJ_SystemInfo(Paths.P p) {
        super(p); // panel.txt 기반 DTO 전달
        setLayout(null);

        ipLabel = new JLabel("내부 IP: 확인 중...");
        ipLabel.setBounds(20, 30, 400, 25);
        add(ipLabel);

        extIpLabel = new JLabel("외부 IP: 확인 중...");
        extIpLabel.setBounds(20, 60, 400, 25);
        add(extIpLabel);

        cpuLabel = new JLabel("CPU: 확인 중...");
        cpuLabel.setBounds(20, 90, 400, 25);
        add(cpuLabel);

        osLabel = new JLabel("OS: 확인 중...");
        osLabel.setBounds(20, 120, 400, 25);
        add(osLabel);

        memLabel = new JLabel("메모리: 확인 중...");
        memLabel.setBounds(20, 150, 400, 25);
        add(memLabel);

        diskLabel = new JLabel("디스크: 확인 중...");
        diskLabel.setBounds(20, 180, 400, 25);
        add(diskLabel);

        netLabel = new JLabel("인터넷: 확인 중...");
        netLabel.setBounds(20, 210, 400, 25);
        add(netLabel);

        timeLabel = new JLabel("시간: 확인 중...");
        timeLabel.setBounds(20, 240, 400, 25);
        add(timeLabel);

        updateInfo();

        // 자동 업데이트 타이머 (3초마다)
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> updateInfo());
            }
        }, 0, 3000);
    }

    private void updateInfo() {
        try {
            String ip = InetAddress.getLocalHost().getHostAddress();
            ipLabel.setText("내부 IP: " + ip);
        } catch (Exception e) {
            ipLabel.setText("내부 IP: 오류 발생");
        }

        try {
            URL url = new URL("https://api.ipify.org");
            Scanner sc = new Scanner(url.openStream());
            String extIp = sc.nextLine();
            extIpLabel.setText("외부 IP: " + extIp);
            sc.close();
        } catch (Exception e) {
            extIpLabel.setText("외부 IP: 확인 실패");
        }

        Runtime rt = Runtime.getRuntime();
        long used = rt.totalMemory() - rt.freeMemory();
        long max = rt.maxMemory();
        int percent = (int) ((used * 100) / max);
        cpuLabel.setText("CPU 메모리 사용률: " + percent + "%");

        if (percent >= 80) {
            cpuLabel.setForeground(Color.RED);
        } else {
            cpuLabel.setForeground(Color.WHITE);
        }

        String os = System.getProperty("os.name");
        osLabel.setText("OS: " + os);

        long usedMB = used / (1024 * 1024);
        long maxMB = max / (1024 * 1024);
        memLabel.setText("메모리: " + usedMB + "MB / " + maxMB + "MB");

        File root = new File("C:\\");
        long free = root.getFreeSpace() / (1024 * 1024 * 1024);
        long total = root.getTotalSpace() / (1024 * 1024 * 1024);
        diskLabel.setText("디스크: " + free + "GB / " + total + "GB 남음");

        try {
            boolean reachable = InetAddress.getByName("8.8.8.8").isReachable(1000);
            netLabel.setText("인터넷: " + (reachable ? "연결됨" : "연결 안 됨"));
        } catch (Exception e) {
            netLabel.setText("인터넷: 확인 불가");
        }

        String now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        timeLabel.setText("시간: " + now);
    }
}  
