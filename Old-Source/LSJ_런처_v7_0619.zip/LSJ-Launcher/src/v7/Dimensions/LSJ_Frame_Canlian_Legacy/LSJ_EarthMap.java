package v7.Dimensions.LSJ_Frame_Canlian_Legacy;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JLabel;

import v7.Core.Paths;

public class LSJ_EarthMap extends E_Panel {

    private BufferedImage earthImage;

    public LSJ_EarthMap(Paths.P p) {
        super(p);
        setLayout(null);

        JLabel title = new JLabel("[ 지구 지도 보기 ]");
        title.setBounds(20, 10, 200, 25);
        add(title);

        try {
            // 예시로 'earth.png' 파일을 프로젝트 내에 위치시켜야 함
            earthImage = ImageIO.read(new File(Paths.IMAGE_PATH_PORTAL));
        } catch (Exception e) {
            System.err.println("지구 이미지 로딩 실패: " + e.getMessage());
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (earthImage != null) {
            g.drawImage(earthImage, 20, 40, getWidth() - 40, getHeight() - 80, this);
        } else {
            g.setColor(Color.GRAY);
            g.drawString("지구 이미지를 불러올 수 없습니다.", 20, 60);
        }
    }
}  
