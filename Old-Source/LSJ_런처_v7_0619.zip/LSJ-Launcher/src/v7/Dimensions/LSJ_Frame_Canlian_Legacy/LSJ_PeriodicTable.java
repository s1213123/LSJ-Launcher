package v7.Dimensions.LSJ_Frame_Canlian_Legacy;

import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import v7.Core.Paths;

public class LSJ_PeriodicTable extends E_Panel {

    public LSJ_PeriodicTable(Paths.P p) {
        super(p);
        setLayout(null);

        JLabel title = new JLabel("[ 간단한 주기율표 (표시용) ]");
        title.setBounds(20, 10, 300, 25);
        add(title);

        JTextArea table = new JTextArea();
        table.setEditable(false);
        table.setFont(new Font("Monospaced", Font.PLAIN, 12));
        table.setText(
            "H                                                             He\n" +
            "Li Be                                          B  C  N  O  F  Ne\n" +
            "Na Mg                                          Al Si P  S  Cl Ar\n" +
            "K  Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr\n" +
            "Rb Sr Y  Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I  Xe\n" +
            "Cs Ba La Hf Ta W  Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn\n"
        );

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBounds(20, 40, p.w - 40, p.h - 80);
        add(scroll);
    }
}  
