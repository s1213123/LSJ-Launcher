
package v7.Dimensions.LSJ_Frame;

import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.dnd.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.Timer;
import java.util.List;

public class LSJ_Viewer extends JPanel {

    private static final String TEMP_FOLDER_PATH = "C:/LSJ";
    private static final int AUTO_REFRESH_INTERVAL = 3000;
    private int fontSize = 14;
    private boolean isListVisible = true;
    private String currentFilter = "ALL"; // "ALL", "TXT", "PNG"

    private final DefaultListModel<String> fileListModel = new DefaultListModel<>();
    private final JList<String> fileList = new JList<>(fileListModel);
    private final Timer autoRefreshTimer = new Timer(true);

    private JScrollPane fileListScrollPane;
    private JPanel viewerPanel;
    private JTextArea textArea;
    private JLabel imageView;

    public LSJ_Viewer() {
        setLayout(new BorderLayout());
        setBackground(Color.decode("#1e354d"));

        ensureTempFolder();
        add(createFileListPanel(), BorderLayout.WEST);
        viewerPanel = createDragViewPanel();
        add(viewerPanel, BorderLayout.CENTER);
        add(createButtonPanel(), BorderLayout.SOUTH);

        startAutoRefresh();
    }

    private void ensureTempFolder() {
        File folder = new File(TEMP_FOLDER_PATH);
        if (!folder.exists()) folder.mkdirs();
    }

    private JScrollPane createFileListPanel() {
        fileList.setBackground(Color.WHITE);
        fileList.setForeground(Color.BLACK);
        fileList.setFont(new Font("맑은 고딕", Font.PLAIN, fontSize));
        fileList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String selected = fileList.getSelectedValue();
                if (selected != null) {
                    File file = new File(TEMP_FOLDER_PATH, selected);
                    openFileInViewer(file);
                }
            }
        });

        refreshFileList();
        fileListScrollPane = new JScrollPane(fileList);
        fileListScrollPane.setPreferredSize(new Dimension(240, 0));
        return fileListScrollPane;
    }

    private JPanel createDragViewPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(0x2a2a3a));
        JLabel dragLabel = new JLabel("📂 여기에 파일을 드래그하세요", SwingConstants.CENTER);
        dragLabel.setForeground(Color.WHITE);
        dragLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        dragLabel.setOpaque(true);
        dragLabel.setBackground(new Color(0x2a2a3a));
        panel.add(dragLabel, BorderLayout.CENTER);

        new DropTarget(dragLabel, DnDConstants.ACTION_COPY, new DropTargetAdapter() {
            public void drop(DropTargetDropEvent dtde) {
                dtde.acceptDrop(DnDConstants.ACTION_COPY);
                try {
                    Transferable t = dtde.getTransferable();
                    List<File> droppedFiles = (List<File>) t.getTransferData(DataFlavor.javaFileListFlavor);
                    for (File file : droppedFiles) {
                        File dest = new File(TEMP_FOLDER_PATH, file.getName());
                        Files.copy(file.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
                        System.out.println("📥 복사됨: " + dest.getName());
                    }
                    refreshFileList();
                } catch (Exception e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(panel, "파일 복사 중 오류 발생");
                }
            }
        }, true);

        return panel;
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setBackground(new Color(0x1e354d));

        JButton openBtn = new JButton("폴더 열기");
        openBtn.addActionListener(e -> openTempFolder());

        JButton resetBtn = new JButton("📂 다시 드래그 모드로");
        resetBtn.addActionListener(e -> switchToDragView());

        JButton toggleViewBtn = new JButton("☰ 리스트 토글");
        toggleViewBtn.addActionListener(e -> toggleFileListVisibility());

        JLabel fontLabel = new JLabel("글자 크기:");
        fontLabel.setForeground(Color.WHITE);
        JComboBox<Integer> fontSelector = new JComboBox<>(new Integer[]{12, 14, 16, 18, 20});
        fontSelector.setSelectedItem(fontSize);
        fontSelector.addActionListener(e -> {
            fontSize = (int) fontSelector.getSelectedItem();
            fileList.setFont(new Font("맑은 고딕", Font.PLAIN, fontSize));
            if (textArea != null) textArea.setFont(new Font("맑은 고딕", Font.PLAIN, fontSize));
        });

        JButton filterAll = new JButton("전체");
        filterAll.addActionListener(e -> { currentFilter = "ALL"; refreshFileList(); });

        JButton filterTxt = new JButton("TXT");
        filterTxt.addActionListener(e -> { currentFilter = "TXT"; refreshFileList(); });

        JButton filterPng = new JButton("PNG");
        filterPng.addActionListener(e -> { currentFilter = "PNG"; refreshFileList(); });

 
        panel.add(openBtn);
        panel.add(fontLabel);
        panel.add(fontSelector);
        panel.add(toggleViewBtn);
        panel.add(filterAll);
        panel.add(filterTxt);
        panel.add(filterPng);
        panel.add(resetBtn);

        return panel;
    }

    private void toggleFileListVisibility() {
        if (fileListScrollPane != null) {
            isListVisible = !isListVisible;
            fileListScrollPane.setVisible(isListVisible);
            revalidate();
            repaint();
        }
    }

    private void switchToDragView() {
        remove(viewerPanel);
        viewerPanel = createDragViewPanel();
        add(viewerPanel, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    private void openFileInViewer(File file) {
        remove(viewerPanel);
        viewerPanel = new JPanel(new BorderLayout());
        viewerPanel.setBackground(new Color(0x1e1e2e));

        try {
            if (file.getName().toLowerCase().endsWith(".txt")) {
                textArea = new JTextArea();
                textArea.setText(new String(Files.readAllBytes(file.toPath()), "UTF-8"));
                textArea.setEditable(false);
                textArea.setBackground(new Color(0x1e1e2e));
                textArea.setForeground(Color.WHITE);
                textArea.setFont(new Font("맑은 고딕", Font.PLAIN, fontSize));
                viewerPanel.add(new JScrollPane(textArea), BorderLayout.CENTER);
            } else if (isImage(file)) {
                ImageIcon icon = new ImageIcon(file.getAbsolutePath());
                Image scaled = icon.getImage().getScaledInstance(-1, 600, Image.SCALE_SMOOTH);
                imageView = new JLabel(new ImageIcon(scaled));
                imageView.setHorizontalAlignment(SwingConstants.CENTER);
                viewerPanel.add(imageView, BorderLayout.CENTER);
            } else {
                viewerPanel.add(new JLabel("미지원 파일 형식입니다."), BorderLayout.CENTER);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        add(viewerPanel, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    private boolean isImage(File file) {
        String name = file.getName().toLowerCase();
        return name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".bmp");
    }


private void refreshFileList() {
    fileListModel.clear();
    File[] files = new File(TEMP_FOLDER_PATH).listFiles();
    if (files != null) {
        for (File file : files) {
            String name = file.getName().toLowerCase();
            boolean show = false;
            if ("TXT".equals(currentFilter)) {
                show = name.endsWith(".txt");
            } else if ("PNG".equals(currentFilter)) {
                show = isImage(file);
            } else { // "ALL"
                show = name.endsWith(".txt") || isImage(file);
            }
            if (show) {
                fileListModel.addElement(file.getName());
            }
        }
    }
}


    private void openTempFolder() {
        try {
            Runtime.getRuntime().exec("cmd /c start \"\" \"" + TEMP_FOLDER_PATH + "\"");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void startAutoRefresh() {
        autoRefreshTimer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                SwingUtilities.invokeLater(() -> refreshFileList());
            }
        }, 0, AUTO_REFRESH_INTERVAL);
    }
}



/*package v7.Dimensions.LSJ_Frame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public class LSJ_TempDrop extends JPanel {

    // 📌 기본 경로 설정
    private static final String TEMP_FOLDER_PATH = "C:/LSJ";
    private static final String DRAG_IMAGE_PATH = "C:/LSJ/dino.png";
    private static final int AUTO_REFRESH_INTERVAL = 3000; // 3초

    // 📌 UI 요소
    private final DefaultListModel<String> fileListModel = new DefaultListModel<>();
    private final JList<String> fileList = new JList<>(fileListModel);
    private final Timer autoRefreshTimer = new Timer(true); // 데몬 타이머

    public LSJ_TempDrop() {
        setLayout(null);
        setBackground(Color.decode("#1e354d"));

        ensureTempFolder();
        initDragImagePanel();
        initFileListPanel();
        initButtons();
        startAutoRefresh();
        setupZoomWithCtrlWheel();  // 🔍 Ctrl + 휠 줌 기능

    }

    // 📂 폴더 없으면 생성
    private void ensureTempFolder() {
        File folder = new File(TEMP_FOLDER_PATH);
        if (!folder.exists()) folder.mkdirs();
    }

    // 🖼 상단 드래그 이미지 영역
    private void initDragImagePanel() {
        JLabel imageLabel;
        File imageFile = new File(DRAG_IMAGE_PATH);

        if (imageFile.exists()) {
            ImageIcon icon = new ImageIcon(DRAG_IMAGE_PATH);
            Image scaled = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            imageLabel = new JLabel(new ImageIcon(scaled), SwingConstants.CENTER);
        } else {
            imageLabel = new JLabel("📂 여기에 드래그하세요", SwingConstants.CENTER);
        }

        imageLabel.setBounds(20, 20, 540, 120);
        imageLabel.setBackground(new Color(0x2a2a3a));
        imageLabel.setForeground(Color.WHITE);
        imageLabel.setOpaque(true);
        imageLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        add(imageLabel);

        // ⬇ 드래그 앤 드롭 연결
        new DropTarget(imageLabel, DnDConstants.ACTION_COPY, new DropTargetAdapter() {
            public void drop(DropTargetDropEvent dtde) {
                dtde.acceptDrop(DnDConstants.ACTION_COPY);
                try {
                    Transferable t = dtde.getTransferable();
                    @SuppressWarnings("unchecked")
                    List<File> droppedFiles = (List<File>) t.getTransferData(DataFlavor.javaFileListFlavor);

                    for (File file : droppedFiles) {
                        File destFile = new File(TEMP_FOLDER_PATH, file.getName());
                        Files.copy(file.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                        System.out.println("📥 복사됨: " + destFile.getName());
                    }

                    refreshFileList();
                } catch (Exception e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(LSJ_TempDrop.this, "파일 복사 중 오류 발생");
                }
            }
        }, true);
    }

    // 📋 하단 리스트 영역
    private void initFileListPanel() {
        fileList.setBackground(new Color(0x1e1e2e));
        fileList.setForeground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(fileList);
        scrollPane.setBounds(20, 160, 540, 200);
        add(scrollPane);

        refreshFileList(); // 초기 로딩
    }

    // 🔘 하단 버튼 영역
    private void initButtons() {
        JButton openBtn = createButton("폴더 열기", 20, e -> openTempFolder());
        JButton refreshBtn = createButton("🔄 새로고침", 140, e -> refreshFileList());
        JButton deleteBtn = createButton("🗑 선택 삭제", 280, e -> deleteSelectedFile());

        add(openBtn);
        add(refreshBtn);
        add(deleteBtn);
    }
    
    

    // 🔘 버튼 생성 유틸
    private JButton createButton(String label, int x, ActionListener listener) {
        JButton btn = new JButton(label);
        btn.setBounds(x, 380, 100, 30);
        btn.addActionListener(listener);
        return btn;
    }


    // 🔁 파일 리스트 새로고침
    private void refreshFileList() {
        fileListModel.clear();
        File[] files = new File(TEMP_FOLDER_PATH).listFiles();
        if (files != null) {
            for (File file : files) {
                fileListModel.addElement(file.getName());
            }
        }
    }

    // ❌ 파일 삭제
    private void deleteSelectedFile() {
        String fileName = fileList.getSelectedValue();
        if (fileName != null) {
            try {
                Files.deleteIfExists(Paths.get(TEMP_FOLDER_PATH, fileName));
                System.out.println("🗑 삭제됨: " + fileName);
                refreshFileList();
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "삭제에 실패했습니다.");
            }
        }
    }

    // 📂 폴더 열기
    private void openTempFolder() {
        try {
            Runtime.getRuntime().exec("cmd /c start \"\" \"" + TEMP_FOLDER_PATH + "\"");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "폴더 열기에 실패했습니다.");
        }
    }

    // ⏱ 자동 새로고침 타이머
    private void startAutoRefresh() {
        autoRefreshTimer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                SwingUtilities.invokeLater(() -> refreshFileList());
            }
        }, 0, AUTO_REFRESH_INTERVAL);
    }
    
    private void setupZoomWithCtrlWheel() {
        addMouseWheelListener(e -> {
            if ((e.getModifiersEx() & MouseEvent.CTRL_DOWN_MASK) != 0) {
                int notches = e.getWheelRotation();
                int delta = notches * 20;

                Dimension size = getPreferredSize();
                int newWidth = size.width - delta;
                int newHeight = size.height - delta;

                // 최소/최대 크기 제한
                newWidth = Math.max(400, Math.min(1000, newWidth));
                newHeight = Math.max(400, Math.min(800, newHeight));

                setPreferredSize(new Dimension(newWidth, newHeight));
                revalidate();
                repaint();
            }
        });
    }

}
*/