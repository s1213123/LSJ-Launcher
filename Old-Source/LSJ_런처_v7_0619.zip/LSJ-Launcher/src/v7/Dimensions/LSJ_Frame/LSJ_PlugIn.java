package v7.Dimensions.LSJ_Frame;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class LSJ_PlugIn extends JPanel {

    public LSJ_PlugIn() {
        setLayout(new BorderLayout());
        add(loadThinkingPanel(), BorderLayout.CENTER);
    }

    private JPanel loadThinkingPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JTextArea thoughtBox = new JTextArea();

        File ideaFile = new File("plugin.thinking.txt");
        if (ideaFile.exists()) {
            try {
                String text = new String(Files.readAllBytes(ideaFile.toPath()), "UTF-8");
                thoughtBox.setText(text);
            } catch (IOException e) {
                thoughtBox.setText("생각을 불러올 수 없습니다.");
            }
        } else {
            thoughtBox.setText("plugin.thinking.txt 파일이 없습니다.");
        }

        thoughtBox.setLineWrap(true);
        thoughtBox.setWrapStyleWord(true);
        thoughtBox.setEditable(false);
        thoughtBox.setFont(new Font("맑은 고딕", Font.PLAIN, 14));

        JButton confirmBtn = new JButton("🧠 OK, 이걸 플러그인으로.");
        confirmBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "생각이 플러그인으로 전환되었습니다.");
        });

        panel.add(new JScrollPane(thoughtBox), BorderLayout.CENTER);
        panel.add(confirmBtn, BorderLayout.SOUTH);
        return panel;
    }
}
