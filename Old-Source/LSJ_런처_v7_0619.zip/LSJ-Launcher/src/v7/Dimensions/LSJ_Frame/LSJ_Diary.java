package v7.Dimensions.LSJ_Frame;

import javax.swing.*;
import javax.swing.undo.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import com.google.gson.*;

public class LSJ_Diary extends JPanel {

    private final int DEFAULT_FONT_SIZE = 14;
    private final Color DEFAULT_FONT_COLOR = Color.WHITE;
    private final Color DEFAULT_BG_COLOR = new Color(30, 60, 90);
    private final Color UI_BG_COLOR = new Color(240, 240, 240);
    private final File SAVE_DIR = new File("diary");
    private final File LOG_FILE = new File(SAVE_DIR, "diary.json");
    private final String TEMP_FILE = "temp.txt";
    private final DateTimeFormatter FILE_TIMESTAMP = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");

    private JTextArea diaryArea;
    private JComboBox<Integer> fontSizeSelector;
    private JComboBox<String> fontColorSelector;
    private JButton cancelButton, saveButton, tempSaveButton;

    private UndoManager undoManager = new UndoManager();

    public LSJ_Diary() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        diaryArea = new JTextArea();
        diaryArea.setLineWrap(true);
        diaryArea.setWrapStyleWord(true);
        diaryArea.setFont(new Font("맑은 고딕", Font.PLAIN, DEFAULT_FONT_SIZE));
        diaryArea.setBackground(DEFAULT_BG_COLOR);
        diaryArea.setForeground(DEFAULT_FONT_COLOR);
        diaryArea.setMargin(new Insets(10, 10, 10, 10));
        diaryArea.getDocument().addUndoableEditListener(undoManager);

        JScrollPane scrollPane = new JScrollPane(diaryArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(UI_BG_COLOR);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        add(contentPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.setBackground(UI_BG_COLOR);

        fontSizeSelector = new JComboBox<>(new Integer[]{12, 14, 16, 18, 20, 24});
        fontColorSelector = new JComboBox<>(new String[]{"기본", "검정", "하늘", "연두", "빨강"});

        cancelButton = new JButton("취소");
        saveButton = new JButton("저장");
        tempSaveButton = new JButton("임시 저장");

        fontSizeSelector.setSelectedItem(DEFAULT_FONT_SIZE);
        fontSizeSelector.addActionListener(e -> updateFontSize());

        fontColorSelector.setSelectedItem("기본");
        fontColorSelector.addActionListener(e -> updateFontColor());

        cancelButton.addActionListener(e -> {
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) window.dispose();
        });

        saveButton.addActionListener(e -> saveAction());
        tempSaveButton.addActionListener(e -> handleTempSave());

        bottomPanel.add(new JLabel(" 글씨 크기:"));
        bottomPanel.add(fontSizeSelector);
        bottomPanel.add(new JLabel(" 글씨 색상:"));
        bottomPanel.add(fontColorSelector);
        bottomPanel.add(cancelButton);
        bottomPanel.add(saveButton);
        bottomPanel.add(tempSaveButton);

        add(bottomPanel, BorderLayout.SOUTH);

        JPopupMenu popup = new JPopupMenu();
        JMenuItem cut = new JMenuItem("잘라내기");
        JMenuItem copy = new JMenuItem("복사");
        JMenuItem paste = new JMenuItem("붙여넣기");
        JMenu bgMenu = new JMenu("배경 색상");

        JMenuItem bgWeaver = new JMenuItem("위버 블루");
        JMenuItem bgWhite = new JMenuItem("화이트");
        JMenuItem bgIvory = new JMenuItem("아이보리");
        JMenuItem bgLavender = new JMenuItem("라벤더");

        cut.addActionListener(e -> diaryArea.cut());
        copy.addActionListener(e -> diaryArea.copy());
        paste.addActionListener(e -> diaryArea.paste());

        bgWeaver.addActionListener(e -> diaryArea.setBackground(DEFAULT_BG_COLOR));
        bgWhite.addActionListener(e -> diaryArea.setBackground(Color.WHITE));
        bgIvory.addActionListener(e -> diaryArea.setBackground(new Color(255, 255, 224)));
        bgLavender.addActionListener(e -> diaryArea.setBackground(new Color(230, 230, 250)));

        bgMenu.add(bgWeaver);
        bgMenu.add(bgWhite);
        bgMenu.add(bgIvory);
        bgMenu.add(bgLavender);

        popup.add(bgMenu);
        popup.addSeparator();
        popup.add(cut);
        popup.add(copy);
        popup.add(paste);

        diaryArea.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) { if (e.isPopupTrigger()) popup.show(e.getComponent(), e.getX(), e.getY()); }
            public void mouseReleased(MouseEvent e) { if (e.isPopupTrigger()) popup.show(e.getComponent(), e.getX(), e.getY()); }
        });

        InputMap im = diaryArea.getInputMap(JComponent.WHEN_FOCUSED);
        ActionMap am = diaryArea.getActionMap();

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_DOWN_MASK), "Undo");
        am.put("Undo", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (undoManager.canUndo()) undoManager.undo();
            }
        });

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_DOWN_MASK), "QuickSave");
        am.put("QuickSave", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                quickSave();
            }
        });
    }

    private void updateFontSize() {
        Integer size = (Integer) fontSizeSelector.getSelectedItem();
        if (size != null) diaryArea.setFont(new Font("맑은 고딕", Font.PLAIN, size));
    }

    private void updateFontColor() {
        String selected = (String) fontColorSelector.getSelectedItem();
        switch (selected) {
            case "검정": diaryArea.setForeground(Color.BLACK); break;
            case "하늘": diaryArea.setForeground(new Color(120, 180, 255)); break;
            case "연두": diaryArea.setForeground(new Color(100, 200, 100)); break;
            case "빨강": diaryArea.setForeground(new Color(230, 80, 80)); break;
            default: diaryArea.setForeground(DEFAULT_FONT_COLOR); break;
        }
    }

    private void saveAction() {
        String title = JOptionPane.showInputDialog(this, "다이어리 제목을 입력하세요:", "제목 입력", JOptionPane.PLAIN_MESSAGE);
        if (title == null || title.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "제목이 없으면 저장할 수 없습니다.");
            return;
        }
        if (!SAVE_DIR.exists()) SAVE_DIR.mkdirs();
        File file = new File(SAVE_DIR, title.trim() + ".txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write(diaryArea.getText());
            appendToJsonLog(title.trim());
            JOptionPane.showMessageDialog(this, "저장되었습니다: " + file.getName());
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) window.dispose();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "저장 실패: " + e.getMessage());
        }
    }

    private void appendToJsonLog(String title) {
        JsonArray logArray = new JsonArray();
        if (LOG_FILE.exists()) {
            try (FileReader reader = new FileReader(LOG_FILE)) {
                JsonElement element = JsonParser.parseReader(reader);
                if (element.isJsonArray()) {
                    logArray = element.getAsJsonArray();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        JsonObject entry = new JsonObject();
        entry.addProperty("title", title);
        entry.addProperty("timestamp", LocalDateTime.now().format(FILE_TIMESTAMP));
        logArray.add(entry);

        try (FileWriter writer = new FileWriter(LOG_FILE)) {
            new GsonBuilder().setPrettyPrinting().create().toJson(logArray, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleTempSave() {
        if (!SAVE_DIR.exists()) SAVE_DIR.mkdirs();
        File file = new File(SAVE_DIR, TEMP_FILE);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write(diaryArea.getText());
            tempSaveButton.setText("복귀");
            diaryArea.setEditable(false);
            tempSaveButton.removeActionListener(tempSaveButton.getActionListeners()[0]);
            tempSaveButton.addActionListener(e -> handleTempRestore());
            JOptionPane.showMessageDialog(this, "임시 저장이 완료되었습니다.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "저장 실패: " + e.getMessage());
        }
    }

    private void handleTempRestore() {
        File file = new File(SAVE_DIR, TEMP_FILE);
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                StringBuilder content = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    content.append(line).append("\n");
                }
                diaryArea.setText(content.toString());
                diaryArea.setEditable(true);
                tempSaveButton.setText("임시 저장");
                tempSaveButton.removeActionListener(tempSaveButton.getActionListeners()[0]);
                tempSaveButton.addActionListener(e -> handleTempSave());
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "복귀 실패: " + e.getMessage());
            }
        }
    }

    private void quickSave() {
        String timestamp = LocalDateTime.now().format(FILE_TIMESTAMP);
        if (!SAVE_DIR.exists()) SAVE_DIR.mkdirs();
        File file = new File(SAVE_DIR, timestamp + ".txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write(diaryArea.getText());
            JOptionPane.showMessageDialog(this, "빠른 저장 완료: " + file.getName());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "빠른 저장 실패: " + e.getMessage());
        }
    }
}
